<?php

namespace App\Services;

use Exception;
use PhpOffice\PhpWord\TemplateProcessor;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class LaporanAkhirDocxService
{
    public function generate($laporan, $proposal, $members, $logbooks, $settings)
    {
        try {

            $templatePath = storage_path('app/templates/laporan-akhir-template.docx');

            /*
            |--------------------------------------------------------------------------
            | Check Template Exists
            |--------------------------------------------------------------------------
            */

            if (!file_exists($templatePath)) {
                throw new Exception("Template DOCX not found at: {$templatePath}");
            }

            ini_set('pcre.backtrack_limit', '100000000');

            $template = new TemplateProcessor($templatePath);

            $tanggalRilis = Carbon::now()
                ->locale('id')
                ->translatedFormat('d F Y');

            /*
            |--------------------------------------------------------------------------
            | Header
            |--------------------------------------------------------------------------
            */

            $template->setValue(
                'jenis_penelitian',
                strtoupper($proposal->jenis_penelitian ?? '-')
            );

            $template->setValue(
                'semester',
                strtoupper($laporan->semester ?? '-')
            );

            $template->setValue(
                'skema_nama',
                $proposal->periode?->skema?->nama_skema ?? '-'
            );

            $template->setValue(
                'tahun_ajaran',
                $proposal->periode?->skema?->tahun_ajaran ?? '-'
            );

            $template->setValue(
                'judul_penelitian',
                $laporan->judul_penelitian ?? '-'
            );

            /*
            |--------------------------------------------------------------------------
            | Ketua
            |--------------------------------------------------------------------------
            */

            $template->setValue(
                'nama_ketua',
                $proposal->user?->nama ?? '-'
            );

            $template->setValue(
                'nidn_ketua',
                $proposal->user?->nidn ?? '-'
            );

            $template->setValue(
                'prodi_ketua',
                $proposal->user?->prodi?->nama_prodi ?? '-'
            );

            /*
            |--------------------------------------------------------------------------
            | Anggota (exclude ketua, semester of this laporan)
            |--------------------------------------------------------------------------
            */

            $anggota = $members
                ->filter(function ($member) use ($proposal) {

                    return !(
                        $member->role === 'Dosen'
                        && $member->member_id == $proposal->user_id
                    );
                })
                ->filter(function ($member) use ($laporan) {

                    return $member->semester === $laporan->semester;
                })
                ->values();

            if ($anggota->count() > 0) {

                $template->cloneRow(
                    'la_no',
                    $anggota->count()
                );

                foreach ($anggota as $index => $member) {

                    $number = $index + 1;

                    if ($member->role === 'Dosen') {
                        $nama = $member?->user?->nama;
                        $institusi = $settings->nama_kampus;
                    } elseif ($member->role === 'Mahasiswa') {
                        $nama = $member?->mahasiswa?->nama;
                        $institusi = $settings->nama_kampus;
                    } else {
                        $nama = $member?->kolaborator?->nama;
                        $institusi = $member?->kolaborator?->institusi;
                    }

                    $template->setValue("la_no#{$number}", $number);
                    $template->setValue("la_nama#{$number}", $nama ?? '-');
                    $template->setValue("la_ttjp#{$number}", $member?->ttjp ?? '-');
                    $template->setValue("la_institusi#{$number}", $institusi ?? '-');
                }

            } else {

                $template->deleteRow('la_no');
            }

            /*
            |--------------------------------------------------------------------------
            | Informasi Penelitian
            |--------------------------------------------------------------------------
            */

            $template->setValue(
                'metode_penelitian',
                $laporan->metode_penelitian ?? '-'
            );

            $template->setValue(
                'unit_analisis',
                $laporan->unit_analisis ?? '-'
            );

            $template->setValue(
                'target_publikasi',
                $laporan->target_publikasi ?? '-'
            );

            $template->setValue(
                'institusi_mitra',
                $laporan->institusi_mitra ?? '-'
            );

            $template->setValue(
                'link_publikasi',
                $laporan->link_publikasi ?? '-'
            );

            /*
            |--------------------------------------------------------------------------
            | Realisasi Anggaran
            |--------------------------------------------------------------------------
            */

            $totalRealisasi =
                ($laporan->realisasi_data_collection ?? 0) +
                ($laporan->realisasi_biaya_publikasi ?? 0) +
                ($laporan->realisasi_insentif ?? 0);

            $template->setValue(
                'realisasi_data_collection',
                number_format($laporan->realisasi_data_collection ?? 0, 0, ',', '.')
            );

            $template->setValue(
                'realisasi_biaya_publikasi',
                number_format($laporan->realisasi_biaya_publikasi ?? 0, 0, ',', '.')
            );

            $template->setValue(
                'realisasi_insentif',
                number_format($laporan->realisasi_insentif ?? 0, 0, ',', '.')
            );

            $template->setValue(
                'total_realisasi',
                number_format($totalRealisasi, 0, ',', '.')
            );

            /*
            |--------------------------------------------------------------------------
            | Logbook
            |--------------------------------------------------------------------------
            */

            if ($logbooks->count() > 0) {

                $template->cloneRow(
                    'lb_no',
                    $logbooks->count()
                );

                foreach ($logbooks as $index => $logbook) {

                    $number = $index + 1;

                    $template->setValue(
                        "lb_no#{$number}",
                        $number
                    );

                    $template->setValue(
                        "lb_tanggal#{$number}",
                        $logbook->tgl_kegiatan
                            ? Carbon::parse($logbook->tgl_kegiatan)
                                ->locale('id')
                                ->translatedFormat('d F Y')
                            : '-'
                    );

                    $template->setValue(
                        "lb_judul#{$number}",
                        $logbook->judul ?? '-'
                    );

                    $template->setValue(
                        "lb_deskripsi#{$number}",
                        $logbook->deskripsi ?? '-'
                    );
                }

            } else {

                $template->deleteRow('lb_no');
            }

            /*
            |--------------------------------------------------------------------------
            | Others
            |--------------------------------------------------------------------------
            */

            $template->setValue(
                'tanggal_rilis',
                $tanggalRilis
            );

            /*
            |--------------------------------------------------------------------------
            | Save File
            |--------------------------------------------------------------------------
            */

            $directory = storage_path('app/public/generated');

            if (!file_exists($directory)) {
                mkdir($directory, 0777, true);
            }

            $filename =
                'laporan-akhir-'
                . $laporan->laporan_id
                . '-'
                . now()->format('YmdHis')
                . '.docx';

            $relativePath = 'generated/' . $filename;

            $savePath = storage_path(
                'app/public/' . $relativePath
            );

            $template->saveAs($savePath);

            Log::info('Laporan Akhir generated successfully', [
                'path' => $savePath
            ]);

            return $relativePath;

        } catch (\Throwable $e) {

            Log::error('LaporanAkhirDocxService Error', [
                'message' => $e->getMessage(),
                'line'    => $e->getLine(),
                'file'    => $e->getFile(),
                'trace'   => $e->getTraceAsString()
            ]);

            throw new Exception(
                'Laporan Akhir generation failed: '
                . $e->getMessage()
                . ' at line '
                . $e->getLine()
            );
        }
    }
}
