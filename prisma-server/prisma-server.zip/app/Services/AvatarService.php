<?php

namespace App\Services;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class AvatarService
{
    protected ImageManager $manager;

    public function __construct()
    {
        $this->manager = ImageManager::usingDriver(Driver::class);
    }

    /**
     * Process uploaded avatar
     */
    public function processUpload($file): string
    {
        $filename = 'avatars/' . Str::uuid() . '.webp';

        $image = $this->manager->decode($file)->cover(256, 256);
        $encoded = $image->encodeUsingFileExtension('webp', 70);

        Storage::disk('public')->put($filename, (string) $encoded);
        return Storage::url($filename);
    }

    /**
     * Generate initials avatar (returns binary)
     */
    public function generateInitials(string $name): string
    {
        $initials = collect(explode(' ', trim($name)))
            ->map(fn($word) => strtoupper(substr($word, 0, 1)))
            ->take(2)
            ->implode('');

        $colors = ['#0D8ABC', '#6A1B9A', '#00897B', '#F4511E', '#3949AB'];
        $colorIndex = crc32($name) % count($colors);
        $bgColor = $colors[$colorIndex];

        // Create blank canvas
        $image = $this->manager->createImage(256, 256);

        // Fill background
        $image->fill($bgColor);

        // Draw text
        $image->text($initials, 128, 128, function ($font) {
            $font->filename(public_path('fonts/inter-variable.ttf'));
            $font->size(100);
            $font->color('#ffffff');
            $font->align('center', 'center');
        });

        return $image->encodeUsingFileExtension('webp', 70);
    }

    /**
     * Delete avatar (safe)
     */
    public function delete(?string $avatarUrl): void
    {
        if (!$avatarUrl) return;

        $path = str_replace('/storage/', '', parse_url($avatarUrl, PHP_URL_PATH));

        if (!$path) return;
        if (str_contains($path, 'default_')) return;
        if (!str_starts_with($path, 'avatars/')) return;

        if (Storage::disk('public')->exists($path)) {
            Storage::disk('public')->delete($path);
        }
    }

    /**
     * Replace avatar (clean swap)
     */
    public function replace(?string $oldAvatar, $file): string
    {
        $this->delete($oldAvatar);
        return $this->processUpload($file);
    }

    /**
     * Generate + store initials avatar (cached)
     */
    public function generateAndStore(string $name, int $userId): string
    {
        $filename = "avatars/default_{$userId}.webp";

        if (!Storage::disk('public')->exists($filename)) {
            $image = $this->generateInitials($name);
            Storage::disk('public')->put($filename, (string) $image);
        }

        return Storage::url($filename);
    }
}