<?php

namespace App\Helpers;

use App\Models\PeriodePengajuan;
use App\Models\Proposal;
use App\Models\Laporan;

/*
|--------------------------------------------------------------------------
| PeriodeStage
|--------------------------------------------------------------------------
| Central authority for what stage a Proposal / Laporan is in. The stage
| is determined entirely by the row's periode_id → kode_periode; there is
| no parallel state to keep in sync.
|
| Access-control rule: an action attached to stage X is only permitted
| when the record's periode row has kode_periode = X and status =
| 'Terbuka'. Advancing to the next stage means repointing the record's
| periode_id to the sibling row (same skema_id + jenis_penelitian) that
| carries the target kode.
|
| Sequences are split by (jenis_penelitian, semester) for Laporan so that
| Ganjil and Genap instances of the same proposal advance independently
| through their own stage list, meeting only at the terminal LUARAN_*.
|--------------------------------------------------------------------------
*/

class PeriodeStage
{
    /*
    |--------------------------------------------------------------------------
    | Proposal sequence
    |--------------------------------------------------------------------------
    | The crossover from PENGUMUMAN_SK into the first laporan stage is
    | handled explicitly by PengumumanSkController — proposal advance()
    | does not walk into laporan territory.
    |--------------------------------------------------------------------------
    */

    public const PROPOSAL_SEQUENCE = [
        'PENERIMAAN_PROPOSAL',
        'SELEKSI_PROPOSAL',
        'PENGUMUMAN_SK',
    ];

    /*
    |--------------------------------------------------------------------------
    | Laporan sequences (semester-specific)
    |--------------------------------------------------------------------------
    */

    public static function laporanSequence(string $jenisPenelitian, string $semester): array
    {
        $sem = strtoupper($semester);

        if ($jenisPenelitian === 'PkM') {
            return [
                "CLAIM_DANA_{$sem}",
                "PROSES_PKM_{$sem}",
                "PUBLIKASI_{$sem}",
                "PENGEMBALIAN_DANA_{$sem}",
                "DISEMINASI_{$sem}",
                'LUARAN_PKM',
            ];
        }

        return [
            "PROSES_PENELITIAN_{$sem}",
            "PUBLIKASI_{$sem}",
            "DISEMINASI_{$sem}",
            "CLAIM_DANA_{$sem}",
            'LUARAN_PENELITIAN',
        ];
    }

    /*
    |--------------------------------------------------------------------------
    | Dispatch to the right sequence for any record type
    |--------------------------------------------------------------------------
    */

    public static function sequenceFor($record): array
    {
        if ($record instanceof Proposal) {
            return self::PROPOSAL_SEQUENCE;
        }

        if ($record instanceof Laporan) {

            $jenis = $record->proposal?->jenis_penelitian ?? 'Penelitian';

            return self::laporanSequence($jenis, $record->semester ?? 'Ganjil');
        }

        return [];
    }

    /*
    |--------------------------------------------------------------------------
    | First laporan stage for a given (jenis, semester)
    |--------------------------------------------------------------------------
    | Used by PengumumanSkController when it needs to point a fresh Laporan
    | at its starting kode without needing an instance to inspect.
    |--------------------------------------------------------------------------
    */

    public static function firstLaporanStage(string $jenisPenelitian, string $semester): string
    {
        return self::laporanSequence($jenisPenelitian, $semester)[0];
    }

    /*
    |--------------------------------------------------------------------------
    | Current kode of a record (via its periode row)
    |--------------------------------------------------------------------------
    */

    public static function currentKode($record): ?string
    {
        if (!$record) {
            return null;
        }

        return $record->periode()
            ->withTrashed()
            ->first()
            ?->kode_periode;
    }

    public static function currentSkemaId($record): ?int
    {
        return $record?->periode()
            ->withTrashed()
            ->first()
            ?->skema_id;
    }

    /*
    |--------------------------------------------------------------------------
    | Compute the next kode after $current in the record's sequence.
    |--------------------------------------------------------------------------
    | Returns null if $current is the last stage or is not in the sequence.
    |--------------------------------------------------------------------------
    */

    public static function nextKode(string $current, $record): ?string
    {
        $sequence = self::sequenceFor($record);

        $index = array_search($current, $sequence, true);

        if ($index === false) {
            return null;
        }

        return $sequence[$index + 1] ?? null;
    }

    /*
    |--------------------------------------------------------------------------
    | Is $kode currently open ("Terbuka") for the skema of $record?
    |--------------------------------------------------------------------------
    */

    public static function isOpen($record, string $kode): bool
    {
        $skemaId = self::currentSkemaId($record);

        if (!$skemaId) {
            return false;
        }

        return PeriodePengajuan::where('skema_id', $skemaId)
            ->where('jenis_penelitian', self::jenisOf($record))
            ->where('kode_periode', $kode)
            ->where('status', 'Terbuka')
            ->exists();
    }

    /*
    |--------------------------------------------------------------------------
    | Locate the sibling periode row that carries a target kode.
    |--------------------------------------------------------------------------
    */

    public static function findPeriode($record, string $kode): ?PeriodePengajuan
    {
        $skemaId = self::currentSkemaId($record);

        if (!$skemaId) {
            return null;
        }

        return PeriodePengajuan::where('skema_id', $skemaId)
            ->where('jenis_penelitian', self::jenisOf($record))
            ->where('kode_periode', $kode)
            ->first();
    }

    /*
    |--------------------------------------------------------------------------
    | Advance $record's periode_id to the row carrying $targetKode.
    |--------------------------------------------------------------------------
    | Returns the PeriodePengajuan the record now points at, or null if the
    | target row does not exist for this skema/jenis (nothing changed).
    |--------------------------------------------------------------------------
    */

    public static function move($record, string $targetKode): ?PeriodePengajuan
    {
        $target = self::findPeriode($record, $targetKode);

        if (!$target) {
            return null;
        }

        $record->update([
            'periode_id' => $target->periode_id,
        ]);

        return $target;
    }

    /*
    |--------------------------------------------------------------------------
    | Advance $record to whatever the next stage in its sequence is.
    |--------------------------------------------------------------------------
    */

    public static function advance($record): ?PeriodePengajuan
    {
        $current = self::currentKode($record);

        if (!$current) {
            return null;
        }

        $next = self::nextKode($current, $record);

        if (!$next) {
            return null;
        }

        return self::move($record, $next);
    }

    /*
    |--------------------------------------------------------------------------
    | Helpers
    |--------------------------------------------------------------------------
    */

    private static function jenisOf($record): ?string
    {
        if ($record instanceof Proposal) {
            return $record->jenis_penelitian;
        }

        if ($record instanceof Laporan) {
            return $record->proposal?->jenis_penelitian;
        }

        return $record->jenis_penelitian ?? null;
    }
}
