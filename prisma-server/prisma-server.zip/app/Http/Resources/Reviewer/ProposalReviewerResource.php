<?php

namespace App\Http\Resources\Reviewer;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Auth;

class ProposalReviewerResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $status = $this->penugasan->firstWhere('user_id', Auth::id());

        return [
            'proposal_id'                   => $this->proposal_id, 
            'penugasan_id'                  => $this->penugasan_id,

            'jenis_penelitian'              => $this->jenis_penelitian,
            'topik_penelitian'              => $this->topik_penelitian,
            'bidang_ilmu'                   => $this->bidang_ilmu,
            'fokus_sdgs'                    => $this->fokus_sdg,
            'ra_data_collection'            => $this->ra_data_collection,
            'ra_biaya_publikasi'            => $this->ra_biaya_publikasi,
            'ra_insentif'                   => $this->ra_insentif,

            'target_publikasi_gan'          => $this->target_publikasi_gan,
            'target_publikasi_gen'          => $this->target_publikasi_gen,
            'rencana_judul_publikasi_gan'   => $this->rencana_judul_publikasi_gan,
            'rencana_judul_publikasi_gen'   => $this->rencana_judul_publikasi_gen,
            'metopen_gan'                   => $this->metopen_gan,
            'metopen_gen'                   => $this->metopen_gen,
            'unit_analisis_gan'             => $this->unit_analisis_gan,
            'unit_analisis_gen'             => $this->unit_analisis_gen,

            'kontribusi_ilmu_makul'         => $this->kontribusi_ilmu_makul,
            'kontribusi_pkm'                => $this->kontribusi_pkm,
            
            'rencana_luaran'                => $this->rencana_luaran,
            'institusi_mitra'               => $this->institusi_mitra,
            'tgl_pengajuan'                 => $this->tgl_pengajuan,
            'skema'                         => $this->skema,
            'sumber_skema'                  => $this->sumber_skema,

            'ketua'                         => $this->user,
            'dokumen'                       => $this->dokumen,

            'member_dosen_proposal'         => $this->memberDosenProposal->map(function ($item) {
                                                    return [
                                                        'user_id'  => $item->member_id,
                                                        'nama'     => $item->user?->nama,
                                                        'avatar'   => $item->user?->avatar_url,
                                                        'ttjp'     => $item->ttjp,
                                                        'semester' => $item->semester,
                                                    ];
                                                }),
            'member_mhswa_proposal'         => $this->memberMhswaProposal->map(function ($item) {
                                                    return [
                                                        'mhswa_id' => $item->member_id,
                                                        'nama'     => $item->mahasiswa?->nama,
                                                        'avatar'   => $item->mahasiswa?->avatar_url,
                                                        'ttjp'     => $item->ttjp,
                                                        'semester' => $item->semester,
                                                    ];
                                                }),
            'member_kolab_proposal'         => $this->memberKolabProposal->map(function ($item) {
                                                    return [
                                                        'kolab_id' => $item->member_id,
                                                        'nama'     => $item->kolaborator?->nama,
                                                        'avatar'   => $item->kolaborator?->avatar_url,
                                                        'ttjp'     => $item->ttjp,
                                                        'semester' => $item->semester,
                                                    ];
                                                }),

            'periode_id'                    => $this->periode?->periode_id,
            'nama_periode'                  => $this->periode?->nama_periode,

            'penugasan'                     => $this->penugasan,
            'status'                        => $status->status_review,

            'kriteria_penilaian'            => $this->kriteria_penilaian ?? [],
            'kriteria_kesesuaian_tema'      => $this->kriteria_kesesuaian_tema ?? [],

            'created_at'                    => $this->created_at, 
            'updated_at'                    => $this->updated_at,
        ];
    }
}
