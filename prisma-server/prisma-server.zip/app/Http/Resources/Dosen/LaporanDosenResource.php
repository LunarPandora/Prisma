<?php

namespace App\Http\Resources\Dosen;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class LaporanDosenResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $proposal = $this->proposal;

        $isGanjil = $this->isGanjil();

        $judul = $isGanjil
            ? $proposal?->rencana_judul_publikasi_gan
            : $proposal?->rencana_judul_publikasi_gen;

        $members = collect()
            ->merge($proposal?->memberDosenProposal ?? [])
            ->merge($proposal?->memberMhswaProposal ?? [])
            ->merge($proposal?->memberKolabProposal ?? [])
            ->filter(fn ($item) => $item->semester === $this->semester)
            ->map(function ($item) {

                // ✅ explicit resolution based on actual relation
                if ($item->role === 'Dosen') {
                    $entity = $item->user;
                    $uniqueId = $entity?->id;
                    $identityType = 'user';
                }

                elseif ($item->role === 'Mahasiswa') {
                    $entity = $item->mahasiswa;
                    $uniqueId = $entity?->mhswa_id;
                    $identityType = 'mahasiswa';
                }

                elseif ($item->role === 'Kolaborator') {
                    $entity = $item->kolaborator;
                    $uniqueId = $entity?->kolab_id;
                    $identityType = 'kolaborator';
                }

                else {
                    $entity = null;
                    $uniqueId = null;
                    $identityType = 'unknown';
                }

                return [
                    'nama'          => $entity?->nama,
                    'avatar'        => $entity?->avatar_url ?? null,
                    'unique_id'     => $uniqueId,
                    'identity_type' => $identityType,
                    'role'          => $item->role,
                    'ttjp'          => $item->ttjp,
                ];
            })
            ->values();

        return [
            'laporan_id'  => $this->laporan_id,
            'proposal_id' => $this->proposal_id,

            'judul'       => $judul,
            'semester'    => $this->semester,
            'status'      => $this->status,

            'kode_periode' => $this->periode?->kode_periode,
            'nama_periode' => $this->periode?->nama_periode,

            'detail' => [
                'judul_penelitian'  => $this->judul_penelitian,
                'metode_penelitian' => $this->metode_penelitian,
                'unit_analisis'     => $this->unit_analisis,
                'target_publikasi'  => $this->target_publikasi,
                'institusi_mitra'   => $this->institusi_mitra,

                'realisasi_data_collection' => $this->realisasi_data_collection,
                'realisasi_biaya_publikasi' => $this->realisasi_biaya_publikasi,
                'realisasi_insentif'        => $this->realisasi_insentif,

                'link_publikasi'     => $this->link_publikasi,
                'link_laporan_akhir' => $this->link_laporan_akhir,
                'link_hki'           => $this->link_hki,
                'link_buku'          => $this->link_buku,
                'link_poster'        => $this->link_poster,
                'link_video'         => $this->link_video,

                'dana_dikembalikan'  => $this->dana_dikembalikan,

                'claim_dana_status'        => $this->claim_dana_status,
                'pengembalian_dana_status' => $this->pengembalian_dana_status,
            ],

            'dokumen' => $this->whenLoaded('dokumen', function () {

                return $this->dokumen->map(function ($dokumen) {

                    return [
                        'dokumen_id'     => $dokumen->dokumen_id,
                        'jenis_dokumen'  => $dokumen->jenis_dokumen,
                        'nama_file'      => $dokumen->nama_file,
                        'file_url'       => $dokumen->file_url,
                        'drive_file_url' => $dokumen->drive_file_url,
                        'tgl_upload'     => $dokumen->tgl_upload,
                    ];
                })->values();
            }),

            'progress' => [
                'tgl_mulai'   => $this->tgl_mulai,
                'tgl_submit'  => $this->tgl_submit,
                'tgl_selesai' => $this->tgl_selesai,
            ],

            'proposal' => [
                'topik'  => $proposal?->topik_penelitian,
                'bidang' => $proposal?->bidang_ilmu,
                'skema'  => $proposal?->skema,
                'jenis_penelitian' => $proposal?->jenis_penelitian,
            ],

            'members' => $members,
        ];
    }
}