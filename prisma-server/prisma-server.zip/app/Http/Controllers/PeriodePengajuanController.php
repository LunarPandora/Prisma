<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PeriodePengajuan;
use Carbon\Carbon;

use App\Http\Resources\PeriodePengajuanResource;
use App\Helpers\ApiResponse;

class PeriodePengajuanController extends Controller
{
    public function index(Request $request)
    {
        $query = PeriodePengajuan::with('skema');

        /*
        |--------------------------------------------------------------------------
        | Search
        |--------------------------------------------------------------------------
        */

        if ($request->filled('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('nama_periode', 'like', '%' . $request->search . '%')
                ->orWhere('kode_periode', 'like', '%' . $request->search . '%');
            });
        }

        /*
        |--------------------------------------------------------------------------
        | Filters
        |--------------------------------------------------------------------------
        */

        if ($request->filled('skema_id')) {
            $query->where('skema_id', $request->skema_id);
        }

        if ($request->filled('jenis_penelitian')) {
            $query->where(
                'jenis_penelitian',
                $request->jenis_penelitian
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Sorting
        |--------------------------------------------------------------------------
        */

        if (
            $request->filled('sort_by')
            &&
            $request->filled('sort_order')
        ) {
            $query->orderBy(
                $request->sort_by,
                $request->sort_order
            );
        }
        else {
            $query->orderBy('periode_id');
        }

        return PeriodePengajuanResource::collection(
            $query->paginate(
                $request->per_page ?? 10
            )
        );
    }

    /**
     * Fetch active periods (today is inside timeline)
     */
    public function fetch(Request $request)
    {
        $today = Carbon::today();
        $query = PeriodePengajuan::select(
                'periode_id',
                'skema_id',
                'jenis_penelitian',
                'kode_periode',
                'nama_periode'
            )
            ->whereDate('tgl_mulai', '<=', $today)
            ->whereDate('tgl_selesai', '>=', $today);

        if ($request->filled('skema_id')) {
            $query->where('skema_id', $request->skema_id);
        }

        if ($request->filled('jenis_penelitian')) {
            $query->where('jenis_penelitian', $request->jenis_penelitian);
        }

        return $query
            ->orderBy('periode_id')
            ->get();
    }

    /**
     * Fetch all periods
     */
    public function fetchAll(Request $request)
    {
        $query = PeriodePengajuan::query();

        if ($request->filled('skema_id')) {
            $query->where('skema_id', $request->skema_id);
        }

        if ($request->filled('jenis_penelitian')) {
            $query->where('jenis_penelitian', $request->jenis_penelitian);
        }

        return $query
            ->orderBy('periode_id')
            ->get();
    }

    /**
     * Create manually (optional)
     * In practice periods should be generated automatically from Skema.
     */
    public function create(Request $request)
    {
        try {
            PeriodePengajuan::create([
                'skema_id'          => $request->skema_id,
                'jenis_penelitian'  => $request->jenis_penelitian,
                'kode_periode'      => $request->kode_periode,
                'nama_periode'      => $request->nama_periode,
                'tgl_mulai'         => $request->tgl_mulai,
                'tgl_selesai'       => $request->tgl_selesai,
                'status'            => $request->status ?? 'Belum dibuka',
            ]);

            return ApiResponse::success();
        } catch (\Exception $e) {
            \Log::error('Create failed: ' . $e->getMessage());
            return ApiResponse::failed();
        }
    }

    /**
     * Update timeline of period
     */
    public function update(Request $request)
    {
        try {
            $periode = PeriodePengajuan::findOrFail($request->periode_id);

            $periode->update([
                'tgl_mulai' => $request->tgl_mulai,
                'tgl_selesai' => $request->tgl_selesai,
                'status' => $request->status,
            ]);

            return ApiResponse::success();
        } catch (\Exception $e) {
            \Log::error('Update failed: ' . $e->getMessage());
            return ApiResponse::failed();
        }
    }

    public function delete(Request $request)
    {
        try {
            $periode = PeriodePengajuan::findOrFail($request->id);
            $periode->delete();

            return ApiResponse::success();
        } catch (\Exception $e) {
            \Log::error('Delete failed: ' . $e->getMessage());
            return ApiResponse::failed();
        }
    }

    public function fetchPenerimaanProposal()
    {
        $today = Carbon::today();

        return PeriodePengajuan::query()
            ->join('skema', 'skema.skema_id', '=', 'periode_pengajuan.skema_id')
            ->select([
                'periode_pengajuan.periode_id',
                'skema.nama_skema'
            ])
            ->where('periode_pengajuan.kode_periode', 'PENERIMAAN_PROPOSAL')
            ->where('periode_pengajuan.status', 'Terbuka')
            ->where('skema.status', 'Aktif')
            ->whereDate('periode_pengajuan.tgl_mulai', '<=', $today)
            ->whereDate('periode_pengajuan.tgl_selesai', '>=', $today)
            ->orderBy('skema.nama_skema')
            ->get();
    }
}