<?php

namespace App\Http\Controllers;

use App\Models\LogbookPengerjaan;
use App\Models\Laporan;
use App\Helpers\PeriodeStage;
use Illuminate\Http\Request;
use App\Helpers\ApiResponse;
use App\Http\Resources\LogbookPengerjaanResource;

class LogbookPengerjaanController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | INDEX
    |--------------------------------------------------------------------------
    */

    public function index(Request $request)
    {
        try {
            $query = LogbookPengerjaan::query()
                ->with(['user', 'laporan']);

            if ($request->filled('laporan_id')) {
                $query->where('laporan_id', $request->laporan_id);
            }

            if ($request->filled('user_id')) {
                $query->where('user_id', $request->user_id);
            }

            $data = $query
                ->orderByDesc('tgl_kegiatan')
                ->paginate($request->get('per_page', 10));

            return LogbookPengerjaanResource::collection($data);

        } catch (\Throwable $e) {
            return ApiResponse::failed(
                'Failed to retrieve logbooks',
                $e->getMessage()
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | SHOW
    |--------------------------------------------------------------------------
    */
    public function show($id)
    {
        try {
            $data = LogbookPengerjaan::with(['user', 'laporan'])
                ->findOrFail($id);

            return ApiResponse::success($data, 'Logbook detail retrieved successfully');

        } catch (\Throwable $e) {
            return ApiResponse::failed(
                'Logbook not found',
                $e->getMessage(),
                404
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | STORE
    |--------------------------------------------------------------------------
    */
    public function store(Request $request)
    {
        try {
            $validated = $request->validate([
                'laporan_id'          => 'required|exists:laporan,laporan_id',
                'user_id'             => 'required|exists:users,id',
                'judul'               => 'required|string|max:255',
                'deskripsi'           => 'required|string',
                'tgl_kegiatan'        => 'required|date',
                'lampiran_drive_id'   => 'nullable|string',
                'lampiran_drive_url'  => 'nullable|string',
            ]);

            /*
            |--------------------------------------------------------------------------
            | Periode Gate
            |--------------------------------------------------------------------------
            | Logbook can only be filled while the laporan's own periode
            | (PROSES_PENELITIAN_* / PROSES_PKM_*) is open.
            |--------------------------------------------------------------------------
            */

            $laporan = Laporan::with([
                'proposal' => fn($q) => $q->withTrashed(),
                'periode'  => fn($q) => $q->withTrashed(),
            ])->findOrFail($validated['laporan_id']);

            $current = $laporan->kodePeriode();

            $prosesKodes = [
                'PROSES_PENELITIAN_GANJIL',
                'PROSES_PENELITIAN_GENAP',
                'PROSES_PKM_GANJIL',
                'PROSES_PKM_GENAP',
            ];

            if (!in_array($current, $prosesKodes, true)
                || !PeriodeStage::isOpen($laporan, $current)
            ) {
                return ApiResponse::failed(
                    'Periode proses penelitian belum dibuka.'
                );
            }

            $logbook = LogbookPengerjaan::create($validated);

            return ApiResponse::success(
                $logbook->load(['user', 'laporan']),
                'Logbook created successfully',
                201
            );

        } catch (\Throwable $e) {
            return ApiResponse::failed(
                'Failed to create logbook',
                $e->getMessage()
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | UPDATE
    |--------------------------------------------------------------------------
    */
    public function update(Request $request, $id)
    {
        try {
            $logbook = LogbookPengerjaan::findOrFail($id);

            $validated = $request->validate([
                'judul'               => 'sometimes|string|max:255',
                'deskripsi'           => 'sometimes|string',
                'tgl_kegiatan'        => 'sometimes|date',
                'lampiran_drive_id'   => 'nullable|string',
                'lampiran_drive_url'  => 'nullable|string',
            ]);

            $logbook->update($validated);

            return ApiResponse::success(
                $logbook->load(['user', 'laporan']),
                'Logbook updated successfully'
            );

        } catch (\Throwable $e) {
            return ApiResponse::failed(
                'Failed to update logbook',
                $e->getMessage()
            );
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */
    public function destroy($id)
    {
        try {
            $logbook = LogbookPengerjaan::findOrFail($id);
            $logbook->delete();

            return ApiResponse::success(
                null,
                'Logbook deleted successfully'
            );

        } catch (\Throwable $e) {
            return ApiResponse::failed(
                'Failed to delete logbook',
                $e->getMessage()
            );
        }
    }
}