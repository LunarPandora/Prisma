<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Laporan;
use App\Models\PenugasanReviewer;
use App\Models\Settings;

use App\Helpers\ApiResponse;
use App\Helpers\PeriodeStage;

class DiseminasiController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Fetch Laporan in Diseminasi Review
    |--------------------------------------------------------------------------
    | Admins and Reviewers see the same underlying rows but with different
    | scoping. This mirrors the Proposal review architecture.
    |--------------------------------------------------------------------------
    */

    public function index(Request $request)
    {
        try {

            $user = $request->user();

            $query = Laporan::query()
                ->with([
                    'proposal' => fn($q) => $q->withTrashed(),
                    'proposal.user' => fn($q) => $q->withTrashed(),
                    'proposal.prodi',
                    'proposal.periode' => fn($q) => $q->withTrashed(),

                    'periode' => fn($q) => $q->withTrashed(),

                    'penugasan' => fn($q) =>
                        $q->with([
                            'reviewer' => fn($q2) =>
                                $q2->select('id', 'nama', 'avatar'),
                            'review'
                        ]),

                    'dokumen.currentVersion',
                ])
                ->whereHas('periode', function ($q) {
                    $q->whereIn('kode_periode', [
                        'DISEMINASI_GANJIL',
                        'DISEMINASI_GENAP',
                    ]);
                });

            if ($user->role === 'Reviewer') {
                $query->whereHas('penugasan', function ($q) use ($user) {
                    $q->where('reviewable_type', 'App\\Models\\Laporan')
                        ->where('user_id', $user->id);
                });
            }

            if ($request->filled('skema_id')) {
                $query->whereHas('proposal', function ($q) use ($request) {
                    $q->whereHas('periode', function ($q2) use ($request) {
                        $q2->where('skema_id', $request->skema_id);
                    });
                });
            }

            if ($request->filled('semester')) {
                $query->where('semester', $request->semester);
            }

            $settings = Settings::first();

            $paginated = $query
                ->orderByDesc('tgl_submit')
                ->paginate($request->get('per_page', 10));

            $paginated->getCollection()->transform(
                function ($laporan) use ($settings, $user) {

                    return $this->transform($laporan, $settings, $user);
                }
            );

            return ApiResponse::success($paginated);

        } catch (\Exception $e) {

            \Log::error('Fetch diseminasi failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Approve Diseminasi (Admin)
    |--------------------------------------------------------------------------
    | Once all reviewers have submitted, admin approves and the laporan
    | moves to Claim Dana / Luaran stage.
    |--------------------------------------------------------------------------
    */

    public function approve(Request $request)
    {
        try {

            $laporan = Laporan::with('periode')
                ->findOrFail($request->laporan_id);

            $current = $laporan->kodePeriode();

            if (!in_array($current, ['DISEMINASI_GANJIL', 'DISEMINASI_GENAP'], true)) {
                return ApiResponse::failed(
                    'Laporan bukan pada tahap Diseminasi.'
                );
            }

            $penugasanList = PenugasanReviewer::with('review')
                ->where('reviewable_type', 'App\\Models\\Laporan')
                ->where('reviewable_id', $laporan->laporan_id)
                ->get();

            if ($penugasanList->isEmpty()) {
                return ApiResponse::failed(
                    'Reviewer diseminasi belum ditugaskan.'
                );
            }

            $allReviewed = $penugasanList->every(
                fn($p) => $p->status_review === 'Telah direview'
            );

            if (!$allReviewed) {
                return ApiResponse::failed(
                    'Belum semua reviewer menyelesaikan review.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | Advance: Penelitian → CLAIM_DANA_*, PkM → LUARAN_PKM (Genap only)
            |--------------------------------------------------------------------------
            */

            $moved = PeriodeStage::advance($laporan);

            $laporan->update([
                'status' => 'Dalam pengerjaan',
            ]);

            return ApiResponse::success([
                'kode_periode' => $moved?->kode_periode,
            ]);

        } catch (\Exception $e) {

            \Log::error('Approve diseminasi failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Transformer
    |--------------------------------------------------------------------------
    */

    private function transform($laporan, $settings, $user)
    {
        $proposal = $laporan->proposal;

        /*
        |--------------------------------------------------------------------------
        | Reviewer-scoped penugasan id (for the current logged-in reviewer)
        |--------------------------------------------------------------------------
        */

        $currentPenugasan = null;

        if ($user && $user->role === 'Reviewer') {

            $currentPenugasan = $laporan->penugasan
                ->firstWhere('user_id', $user->id);
        }

        return [
            'laporan_id'  => $laporan->laporan_id,
            'proposal_id' => $laporan->proposal_id,

            'semester' => $laporan->semester,
            'kode_periode' => $laporan->periode?->kode_periode,
            'nama_periode' => $laporan->periode?->nama_periode,
            'status'   => $laporan->status,
            'tgl_submit' => $laporan->tgl_submit,

            'judul_penelitian' => $laporan->judul_penelitian,
            'target_publikasi' => $laporan->target_publikasi,

            'ketua' => [
                'id'     => $proposal?->user?->id,
                'nama'   => $proposal?->user?->nama,
                'nidn'   => $proposal?->user?->nidn,
                'avatar' => $proposal?->user?->avatar_url,
            ],

            'jenis_penelitian' => $proposal?->jenis_penelitian,
            'nama_periode'     => $proposal?->periode?->nama_periode,

            'luaran' => [
                'link_laporan_akhir' => $laporan->link_laporan_akhir,
                'link_publikasi'     => $laporan->link_publikasi,
                'link_hki'           => $laporan->link_hki,
                'link_buku'          => $laporan->link_buku,
                'link_poster'        => $laporan->link_poster,
                'link_video'         => $laporan->link_video,
                'dana_dikembalikan'  => $laporan->dana_dikembalikan,
            ],

            'penugasan' => $laporan->penugasan->map(function ($p) {
                return [
                    'penugasan_id' => $p->penugasan_id,
                    'user_id'      => $p->user_id,
                    'status_review'=> $p->status_review,
                    'reviewer'     => $p->reviewer
                        ? [
                            'id'         => $p->reviewer->id,
                            'nama'       => $p->reviewer->nama,
                            'avatar_url' => $p->reviewer->avatar_url,
                        ]
                        : null,
                    'review' => $p->review,
                ];
            })->values(),

            'penugasan_id' => $currentPenugasan?->penugasan_id,

            'kriteria_kesesuaian_tema' => $settings?->list_kesesuaian_tema ?? [],
            'kriteria_penilaian'       => $settings?->kriteria_penilaian ?? [],
        ];
    }
}
