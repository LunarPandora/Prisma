<?php

namespace App\Http\Controllers;

use App\Models\Settings;
use App\Models\User;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Get Settings
    |--------------------------------------------------------------------------
    */

    public function index()
    {
        $settings = Settings::with([
            'kepalaLppmUser:id,nama,avatar',
            'rektorUser:id,nama,avatar',
        ])->first();

        return response()->json([
            'status' => 'success',
            'data' => $settings
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | Save / Update Settings
    |--------------------------------------------------------------------------
    */

    public function update(Request $request)
    {
        try {

            $settings = Settings::first();

            /*
            |--------------------------------------------------------------------------
            | Create Row If Not Exists
            |--------------------------------------------------------------------------
            */

            if (!$settings) {
                $settings = Settings::create([
                    'kepala_lppm' => null,
                    'rektor' => null,
                    'nama_kampus' => '',
                    'kriteria_penilaian' => [],
                ]);
            }

            /*
            |--------------------------------------------------------------------------
            | Update
            |--------------------------------------------------------------------------
            */

            $settings->update([
                'kepala_lppm' => $request->kepala_lppm,
                'rektor' => $request->rektor,
                'nama_kampus' => $request->nama_kampus,

                'kriteria_penilaian' => json_decode(
                    $request->kriteria_penilaian,
                    true
                ),

                'list_kesesuaian_tema' => json_decode(
                    $request->list_kesesuaian_tema, 
                    true
                )
            ]);

            return response()->json([
                'status' => 'success'
            ]);

        } catch (\Exception $e) {
            \Log::error(
                'Settings update failed: ' .
                $e->getMessage()
            );

            return response()->json([
                'status' => 'failed'
            ], 500);
        }
    }

    public function fetchRektor()
    {
        $users = User::where('role', 'Rektorat')
            ->select(
                'id',
                'nama',
                'avatar'
            )
            ->get()
            ->append('avatar_url');

        return response()->json([
            'status' => 'success',
            'data' => $users
        ]);
    }

    public function fetchTimLppm()
    {
        $users = User::where('role', 'Tim LPPM')
            ->select(
                'id',
                'nama',
                'avatar'
            )
            ->get()
            ->append('avatar_url');

        return response()->json([
            'status' => 'success',
            'data' => $users
        ]);
    }
}