<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PenugasanReviewer;
use App\Models\Proposal;
use App\Models\PeriodePengajuan;

// use App\Http\Resources\PenugasanReviewerResource;
use App\Helpers\ApiResponse;

class PenugasanReviewerController extends Controller
{
    public function fetch()
    {
        return ProposalDetail::collection(
            PenugasanReviewer::with(['prodi'])->orderBy('nim')->get()
        );
    }

    public function assignReviewers(Request $request)
    {
        try{
            $reviewerIds = $request->input('reviewer_id', []);

            /*
            |--------------------------------------------------------------------------
            | Resolve Subject (defaults to Proposal for backward compatibility)
            |--------------------------------------------------------------------------
            */

            $reviewableType = $request->input(
                'reviewable_type',
                'App\\Models\\Proposal'
            );

            $reviewableId = $request->input(
                'reviewable_id',
                $request->proposal_id
            );

            $baseQuery = PenugasanReviewer::where(
                'reviewable_type',
                $reviewableType
            )->where(
                'reviewable_id',
                $reviewableId
            );

            /*
            |--------------------------------------------------------------------------
            | Block Reviewer Change After Review Started
            |--------------------------------------------------------------------------
            | Per spec: "Admin may replace Reviewer before review starts."
            |--------------------------------------------------------------------------
            */

            $reviewStarted = $baseQuery->clone()
                ->where('status_review', 'Telah direview')
                ->exists();

            if ($reviewStarted && empty($reviewerIds)) {
                return ApiResponse::failed(
                    'Tidak dapat menghapus reviewer setelah review dimulai.'
                );
            }

            if (empty($reviewerIds)) {
                $baseQuery->clone()->forceDelete();
                return ApiResponse::success();
            }

            $existing = $baseQuery->clone()
                ->pluck('user_id')
                ->toArray();

            $toInsert = array_diff($reviewerIds, $existing);
            $toDelete = array_diff($existing, $reviewerIds);

            /*
            |--------------------------------------------------------------------------
            | Deletions are blocked if that reviewer already reviewed
            |--------------------------------------------------------------------------
            */

            if (!empty($toDelete)) {

                $lockedIds = $baseQuery->clone()
                    ->whereIn('user_id', $toDelete)
                    ->where('status_review', 'Telah direview')
                    ->pluck('user_id')
                    ->toArray();

                if (!empty($lockedIds)) {
                    return ApiResponse::failed(
                        'Tidak dapat mengganti reviewer yang sudah selesai mereview.'
                    );
                }
            }

            foreach ($toInsert as $reviewerId) {
                PenugasanReviewer::create([
                    'proposal_id' => $reviewableType === 'App\\Models\\Proposal'
                        ? $reviewableId
                        : null,
                    'reviewable_type' => $reviewableType,
                    'reviewable_id'   => $reviewableId,
                    'user_id'         => $reviewerId,
                    'tgl_penugasan'   => date('Y-m-d')
                ]);
            }

            $baseQuery->clone()
                ->whereIn('user_id', $toDelete)
                ->forceDelete();

            return ApiResponse::success();
        }
        catch (\Exception $e) {
            \Log::error('Update failed: ' . $e->getMessage());
            return ApiResponse::failed();
        }
    }

    public function confirmAssignment(Request $request)
    {
        try{
            $p = Proposal::with([
                'periode' => fn($q) => $q->withTrashed()
            ])->findOrFail($request->proposal_id);

            /*
            |--------------------------------------------------------------------------
            | Move Proposal to Seleksi Stage
            |--------------------------------------------------------------------------
            */

            $seleksiPeriode = PeriodePengajuan::where(
                'skema_id',
                $p->periode?->skema_id
            )
            ->where(
                'jenis_penelitian',
                $p->jenis_penelitian
            )
            ->where('kode_periode', 'SELEKSI_PROPOSAL')
            ->first();

            $p->update([
                'status' => 'Menunggu review',

                'periode_id' => $seleksiPeriode
                    ? $seleksiPeriode->periode_id
                    : $p->periode_id,
            ]);

            return ApiResponse::success();
        }
        catch (\Exception $e) {
            \Log::error('Update failed: ' . $e->getMessage());
            return ApiResponse::failed();
        }
    }
}
