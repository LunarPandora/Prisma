<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Mahasiswa;

use App\Services\AvatarService;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

use App\Http\Resources\MahasiswaResource;
use App\Helpers\ApiResponse;

class MahasiswaController extends Controller
{
    public function fetch()
    {
        return MahasiswaResource::collection(
            Mahasiswa::with(['prodi'])->orderBy('nim')->get()
        );
    }

    public function create(Request $request, AvatarService $avatarService)
    {
        try {
            $request->validate([
                'uploaded_file' => [
                    'sometimes',
                    'nullable',
                    'image',
                    'mimes:jpg,jpeg,png,webp',
                    'max:5120',
                ],
            ]);

            $avatarPath = null;

            if ($request->hasFile('uploaded_file')) {
                $avatarPath = $avatarService->processUpload($request->file('uploaded_file'));
            }

            $mhswa = Mahasiswa::create([
                'nim'      => $request->nim,
                'nama'     => $request->nama,
                'prodi_id' => $request->prodi_id,
                'avatar'   => $avatarPath
            ]);

            return ApiResponse::success();
        } catch (\Exception $e) {
            \Log::error('Create failed: ' . $e->getMessage());
            return ApiResponse::failed();
        }
    }

    public function update(Request $request, AvatarService $avatarService){
        try {
            $request->validate([
                'uploaded_file' => [
                    'sometimes',
                    'nullable',
                    'image',
                    'mimes:jpg,jpeg,png,webp',
                    'max:5120',
                ],
            ]);

            $mhswa = Mahasiswa::findOrFail($request->mhswa_id);
            $avatarUrl = $request->hasFile('uploaded_file')
                ? $avatarService->replace($mhswa->avatar, $request->file('uploaded_file'))
                : $mhswa->avatar;

            // Update mahasiswa
            $mhswa->update([
                'nim'      => $request->nim,
                'nama'     => $request->nama,
                'prodi_id' => $request->prodi_id,
                'avatar'   => $avatarUrl
            ]);

            return ApiResponse::success();
        } catch (\Exception $e) {
            \Log::error('Update failed: '.$e->getMessage());

            return ApiResponse::failed();
        }
    }

    public function delete(Request $request, AvatarService $avatarService){
        try {
            $mhswa = Mahasiswa::findOrFail($request->id);
            $avatarService->delete($mhswa->avatar);
            $mhswa->delete();

            return ApiResponse::success();
        } catch (\Exception $e) {
            \Log::error('Delete failed: ' . $e->getMessage());
            return ApiResponse::failed();
        }
    }
}
