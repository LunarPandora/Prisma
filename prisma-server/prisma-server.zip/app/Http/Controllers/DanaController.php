<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\Laporan;

use App\Services\DocumentService;
use App\Helpers\ApiResponse;
use App\Helpers\PeriodeStage;

/*
|--------------------------------------------------------------------------
| DanaController
|--------------------------------------------------------------------------
| Handles two related workflows, both keyed on kode_periode:
|
|  Claim Dana (all schemes)
|    Admin approves claim → Dosen uploads transfer proof → Admin confirms.
|    Runs while the laporan sits at CLAIM_DANA_GANJIL / CLAIM_DANA_GENAP.
|    On admin confirm, PeriodeStage advances the laporan.
|
|  Pengembalian Dana (PkM only)
|    Admin flags "Menunggu Pengembalian Dana" → Dosen uploads transfer
|    proof → Admin confirms. Runs while the laporan sits at
|    PENGEMBALIAN_DANA_GANJIL / PENGEMBALIAN_DANA_GENAP. On admin confirm,
|    PeriodeStage advances the laporan.
|--------------------------------------------------------------------------
*/

class DanaController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | LIST — Admin sees all in claim/pengembalian stage; Dosen sees own.
    |--------------------------------------------------------------------------
    */

    public function index(Request $request)
    {
        try {

            $user = $request->user();

            $mode = $request->get('mode', 'claim'); // 'claim' | 'pengembalian'

            $kodes = $mode === 'pengembalian'
                ? ['PENGEMBALIAN_DANA_GANJIL', 'PENGEMBALIAN_DANA_GENAP']
                : ['CLAIM_DANA_GANJIL', 'CLAIM_DANA_GENAP'];

            $query = Laporan::query()
                ->with([
                    'proposal' => fn($q) => $q->withTrashed(),
                    'proposal.user' => fn($q) => $q->withTrashed(),
                    'proposal.prodi',
                    'periode' => fn($q) => $q->withTrashed(),
                    'dokumen.currentVersion',
                ])
                ->whereHas('periode', function ($q) use ($kodes) {
                    $q->whereIn('kode_periode', $kodes);
                });

            if ($user->role === 'Dosen') {
                $query->whereHas('proposal', function ($q) use ($user) {
                    $q->where('user_id', $user->id);
                });
            }

            if ($request->filled('skema_id')) {
                $query->whereHas('periode', function ($q) use ($request) {
                    $q->where('skema_id', $request->skema_id);
                });
            }

            $paginated = $query
                ->orderByDesc('tgl_submit')
                ->paginate($request->get('per_page', 10));

            return ApiResponse::success($paginated);

        } catch (\Exception $e) {

            \Log::error('Fetch dana failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Claim Dana — Admin approves the claim
    |--------------------------------------------------------------------------
    */

    public function approveClaim(Request $request)
    {
        try {

            $laporan = $this->findLaporan(
                $request->laporan_id,
                ['CLAIM_DANA_GANJIL', 'CLAIM_DANA_GENAP']
            );

            if (!$laporan) {
                return ApiResponse::failed(
                    'Laporan bukan pada tahap Claim Dana.'
                );
            }

            $laporan->update([
                'claim_dana_status'     => 'Menunggu bukti transfer',
                'claim_dana_approved_at'=> now(),
            ]);

            return ApiResponse::success();

        } catch (\Exception $e) {

            \Log::error('Approve claim failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Claim Dana — Dosen uploads transfer proof (Drive link)
    |--------------------------------------------------------------------------
    */

    public function uploadClaimProof(Request $request)
    {
        DB::beginTransaction();

        try {

            $validated = $request->validate([
                'laporan_id'     => ['required', 'exists:laporan,laporan_id'],
                'drive_file_url' => ['required', 'url'],
            ]);

            $laporan = $this->findOwnedLaporan(
                $validated['laporan_id'],
                ['CLAIM_DANA_GANJIL', 'CLAIM_DANA_GENAP']
            );

            if (!$laporan) {
                return ApiResponse::failed('Laporan tidak ditemukan.');
            }

            if ($laporan->claim_dana_status !== 'Menunggu bukti transfer') {
                return ApiResponse::failed(
                    'Claim dana belum diapprove oleh admin.'
                );
            }

            $this->storeProof(
                $laporan,
                'Bukti Transfer Claim',
                $validated['drive_file_url']
            );

            $laporan->update([
                'claim_dana_status' => 'Menunggu konfirmasi admin',
            ]);

            DB::commit();

            return ApiResponse::success();

        } catch (\Exception $e) {

            DB::rollBack();

            \Log::error('Upload claim proof failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Claim Dana — Admin confirms transfer and advances stage
    |--------------------------------------------------------------------------
    */

    public function confirmClaim(Request $request)
    {
        try {

            $laporan = $this->findLaporan(
                $request->laporan_id,
                ['CLAIM_DANA_GANJIL', 'CLAIM_DANA_GENAP']
            );

            if (!$laporan) {
                return ApiResponse::failed(
                    'Laporan bukan pada tahap Claim Dana.'
                );
            }

            if ($laporan->claim_dana_status !== 'Menunggu konfirmasi admin') {
                return ApiResponse::failed(
                    'Belum ada bukti transfer yang diupload.'
                );
            }

            $laporan->update([
                'claim_dana_status'       => 'Selesai',
                'claim_dana_confirmed_at' => now(),
            ]);

            PeriodeStage::advance($laporan);

            return ApiResponse::success();

        } catch (\Exception $e) {

            \Log::error('Confirm claim failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Pengembalian Dana — Admin marks as awaiting return
    |--------------------------------------------------------------------------
    */

    public function requestPengembalian(Request $request)
    {
        try {

            $laporan = $this->findLaporan(
                $request->laporan_id,
                ['PENGEMBALIAN_DANA_GANJIL', 'PENGEMBALIAN_DANA_GENAP']
            );

            if (!$laporan) {
                return ApiResponse::failed(
                    'Laporan bukan pada tahap Pengembalian Dana.'
                );
            }

            $laporan->update([
                'pengembalian_dana_status' => 'Menunggu Pengembalian Dana',
            ]);

            return ApiResponse::success();

        } catch (\Exception $e) {

            \Log::error('Request pengembalian failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Pengembalian Dana — Dosen uploads transfer proof
    |--------------------------------------------------------------------------
    */

    public function uploadPengembalianProof(Request $request)
    {
        DB::beginTransaction();

        try {

            $validated = $request->validate([
                'laporan_id'     => ['required', 'exists:laporan,laporan_id'],
                'drive_file_url' => ['required', 'url'],
            ]);

            $laporan = $this->findOwnedLaporan(
                $validated['laporan_id'],
                ['PENGEMBALIAN_DANA_GANJIL', 'PENGEMBALIAN_DANA_GENAP']
            );

            if (!$laporan) {
                return ApiResponse::failed('Laporan tidak ditemukan.');
            }

            if ($laporan->pengembalian_dana_status !== 'Menunggu Pengembalian Dana') {
                return ApiResponse::failed(
                    'Belum ada instruksi pengembalian dari admin.'
                );
            }

            $this->storeProof(
                $laporan,
                'Bukti Transfer Pengembalian',
                $validated['drive_file_url']
            );

            $laporan->update([
                'pengembalian_dana_status' => 'Menunggu konfirmasi admin',
            ]);

            DB::commit();

            return ApiResponse::success();

        } catch (\Exception $e) {

            DB::rollBack();

            \Log::error('Upload pengembalian proof failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Pengembalian Dana — Admin confirms and advances to Diseminasi
    |--------------------------------------------------------------------------
    */

    public function confirmPengembalian(Request $request)
    {
        try {

            $laporan = $this->findLaporan(
                $request->laporan_id,
                ['PENGEMBALIAN_DANA_GANJIL', 'PENGEMBALIAN_DANA_GENAP']
            );

            if (!$laporan) {
                return ApiResponse::failed(
                    'Laporan bukan pada tahap Pengembalian Dana.'
                );
            }

            if ($laporan->pengembalian_dana_status !== 'Menunggu konfirmasi admin') {
                return ApiResponse::failed(
                    'Belum ada bukti pengembalian yang diupload.'
                );
            }

            $laporan->update([
                'pengembalian_dana_status'       => 'Selesai',
                'pengembalian_dana_confirmed_at' => now(),
            ]);

            PeriodeStage::advance($laporan);

            return ApiResponse::success();

        } catch (\Exception $e) {

            \Log::error('Confirm pengembalian failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Helpers
    |--------------------------------------------------------------------------
    */

    private function findLaporan($laporanId, array $expectedKodes)
    {
        $laporan = Laporan::with([
            'proposal' => fn($q) => $q->withTrashed(),
            'periode'  => fn($q) => $q->withTrashed(),
        ])->find($laporanId);

        if (!$laporan) {
            return null;
        }

        $current = $laporan->kodePeriode();

        if (!in_array($current, $expectedKodes, true)
            || !PeriodeStage::isOpen($laporan, $current)
        ) {
            return null;
        }

        return $laporan;
    }

    private function findOwnedLaporan($laporanId, array $expectedKodes)
    {
        $laporan = $this->findLaporan($laporanId, $expectedKodes);

        if (!$laporan) {
            return null;
        }

        if ($laporan->proposal?->user_id !== auth()->id()) {
            return null;
        }

        return $laporan;
    }

    private function storeProof(Laporan $laporan, string $jenis, string $driveUrl): void
    {
        $dokumen = $laporan->dokumen()
            ->firstOrCreate([
                'jenis_dokumen' => $jenis,
            ]);

        $nextVersion = ($dokumen->versions()->max('version') ?? 0) + 1;

        $version = $dokumen->versions()->create([
            'version'          => $nextVersion,

            'nama_file'        => $jenis . ' v' . $nextVersion,

            'drive_file_id'    => '-',
            'drive_file_url'   => $driveUrl,

            'local_file_url'   => '',

            'uploaded_by'      => auth()->id(),

            'catatan_revisi'   => $nextVersion === 1
                ? 'Upload bukti transfer awal'
                : 'Revisi bukti transfer',

            'tgl_upload'       => now(),
        ]);

        $dokumen->update([
            'current_version_id' => $version->version_id,
        ]);
    }
}
