<?php

namespace App\Http\Controllers;

use App\Models\Skema;
use App\Models\PeriodePengajuan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\ApiResponse;
use Carbon\Carbon;

class SkemaController extends Controller
{
    public function index()
    {
        return Skema::with('periode')
            ->orderByDesc('created_at')
            ->paginate(10);
    }

    public function fetchAll(){
        return Skema::select(
            'skema_id',
            'nama_skema'
        )->get();
    }

    public function show($id)
    {
        return Skema::with('periode')
            ->findOrFail($id);
    }

    public function store(Request $request)
    {
        DB::beginTransaction();

        try {

            $skema = Skema::create([
                'nama_skema'   => $request->nama_skema,
                'tahun_ajaran' => $request->tahun_ajaran,
                'status'       => 'Draft',
            ]);

            $this->generatePeriode($skema);

            DB::commit();

            return ApiResponse::success();
        }
        catch (\Exception $e) {

            DB::rollBack();

            return ApiResponse::failed(
                $e->getMessage()
            );
        }
    }

    public function update(Request $request)
    {
        try{
            $s = Skema::findOrFail($request->skema_id);

            /*
            |--------------------------------------------------------------------------
            | Validate Status Change
            |--------------------------------------------------------------------------
            */

            if(in_array($request->status, ['Aktif', 'Selesai']))
            {
                $missingTimeline = $s->periode()
                    ->where(function($q){
                        $q->whereNull('tgl_mulai')
                        ->orWhereNull('tgl_selesai');
                    })
                    ->exists();

                if($missingTimeline){
                    return ApiResponse::failed('Seluruh periode harus memiliki tanggal mulai dan tanggal selesai terlebih dahulu.');
                }
            }

            $s->update([
                'nama_skema' => $request->nama_skema,
                'tahun_ajaran' => $request->tahun_ajaran,
                'status' => $request->status,
            ]);

            return ApiResponse::success();
        }
        catch (\Exception $e) {
            \Log::error($e->getMessage());
            return ApiResponse::failed();
        }
    }

    public function destroy(Request $request)
    {
        try {
            $skema = Skema::findOrFail($request->skema_id);
            $skema->periode()->delete();
            $skema->delete();

            return ApiResponse::success();
        }
        catch (\Exception $e) {

            return ApiResponse::failed(
                $e->getMessage()
            );
        }
    }

    private function generatePeriode(Skema $skema)
    {
        $penelitian = [
            [
                'kode_periode' => 'PENERIMAAN_PROPOSAL',
                'nama_periode' => 'Penerimaan Proposal'
            ],
            [
                'kode_periode' => 'SELEKSI_PROPOSAL',
                'nama_periode' => 'Seleksi Proposal'
            ],
            [
                'kode_periode' => 'PENGUMUMAN_SK',
                'nama_periode' => 'Pengumuman SK Proposal'
            ],
            [
                'kode_periode' => 'PROSES_PENELITIAN_GANJIL',
                'nama_periode' => 'Proses Penelitian (Ganjil)'
            ],
            [
                'kode_periode' => 'PUBLIKASI_GANJIL',
                'nama_periode' => 'Publikasi Penelitian (Ganjil)'
            ],
            [
                'kode_periode' => 'DISEMINASI_GANJIL',
                'nama_periode' => 'Diseminasi Hasil Penelitian (Ganjil)'
            ],
            [
                'kode_periode' => 'CLAIM_DANA_GANJIL',
                'nama_periode' => 'Claim Pembiayaan Penelitian (Ganjil)'
            ],
            [
                'kode_periode' => 'PROSES_PENELITIAN_GENAP',
                'nama_periode' => 'Proses Penelitian (Genap)'
            ],
            [
                'kode_periode' => 'PUBLIKASI_GENAP',
                'nama_periode' => 'Publikasi Penelitian (Genap)'
            ],
            [
                'kode_periode' => 'DISEMINASI_GENAP',
                'nama_periode' => 'Diseminasi Hasil Penelitian (Genap)'
            ],
            [
                'kode_periode' => 'CLAIM_DANA_GENAP',
                'nama_periode' => 'Claim Pembiayaan Penelitian (Genap)'
            ],
            [
                'kode_periode' => 'LUARAN_PENELITIAN',
                'nama_periode' => 'Luaran Penelitian'
            ],
        ];

        $pkm = [
            [
                'kode_periode' => 'PENERIMAAN_PROPOSAL',
                'nama_periode' => 'Penerimaan Proposal'
            ],
            [
                'kode_periode' => 'SELEKSI_PROPOSAL',
                'nama_periode' => 'Seleksi Proposal'
            ],
            [
                'kode_periode' => 'PENGUMUMAN_SK',
                'nama_periode' => 'Pengumuman SK Proposal'
            ],
            [
                'kode_periode' => 'CLAIM_DANA_GANJIL',
                'nama_periode' => 'Claim Pembiayaan PkM (Ganjil)'
            ],
            [
                'kode_periode' => 'PROSES_PKM_GANJIL',
                'nama_periode' => 'Proses PkM (Ganjil)'
            ],
            [
                'kode_periode' => 'PUBLIKASI_GANJIL',
                'nama_periode' => 'Publikasi PkM (Ganjil)'
            ],
            [
                'kode_periode' => 'PENGEMBALIAN_DANA_GANJIL',
                'nama_periode' => 'Pengembalian Dana (Ganjil)'
            ],
            [
                'kode_periode' => 'DISEMINASI_GANJIL',
                'nama_periode' => 'Diseminasi Hasil PkM (Ganjil)'
            ],
            [
                'kode_periode' => 'CLAIM_DANA_GENAP',
                'nama_periode' => 'Claim Pembiayaan PkM (Genap)'
            ],
            [
                'kode_periode' => 'PROSES_PKM_GENAP',
                'nama_periode' => 'Proses PkM (Genap)'
            ],
            [
                'kode_periode' => 'PUBLIKASI_GENAP',
                'nama_periode' => 'Publikasi PkM (Genap)'
            ],
            [
                'kode_periode' => 'PENGEMBALIAN_DANA_GENAP',
                'nama_periode' => 'Pengembalian Dana (Genap)'
            ],
            [
                'kode_periode' => 'DISEMINASI_GENAP',
                'nama_periode' => 'Diseminasi Hasil PkM (Genap)'
            ],
            [
                'kode_periode' => 'LUARAN_PKM',
                'nama_periode' => 'Luaran PkM'
            ],
        ];

        $this->generateTimeline(
            $skema,
            'Penelitian',
            $penelitian
        );

        $this->generateTimeline(
            $skema,
            'PkM',
            $pkm
        );
    }

    private function generateTimeline(
        Skema $skema,
        string $jenisPenelitian,
        array $periods
    )
    {
        $startDate = Carbon::create(
            now()->year,
            7,
            1
        );

        $endDate = Carbon::create(
            now()->year + 1,
            7,
            1
        );

        $totalDays = $startDate->diffInDays($endDate);

        $periodCount = count($periods);

        $daysPerPeriod = floor(
            $totalDays / $periodCount
        );

        $currentStart = $startDate->copy();

        foreach ($periods as $index => $item) {

            if ($index === ($periodCount - 1)) {
                $currentEnd = $endDate->copy();
            }
            else {
                $currentEnd = $currentStart
                    ->copy()
                    ->addDays($daysPerPeriod - 1);
            }

            PeriodePengajuan::create([
                'skema_id' => $skema->skema_id,
                'jenis_penelitian' => $jenisPenelitian,
                'kode_periode' => $item['kode_periode'],
                'nama_periode' => $item['nama_periode'],
                'tgl_mulai' => $currentStart->toDateString(),
                'tgl_selesai' => $currentEnd->toDateString(),
                'status' => 'Belum dibuka',
            ]);

            $currentStart = $currentEnd
                ->copy()
                ->addDay();
        }
}
}