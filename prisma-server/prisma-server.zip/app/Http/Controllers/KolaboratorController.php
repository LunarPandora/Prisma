<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Kolaborator;

use App\Services\AvatarService;

use App\Http\Resources\KolaboratorResource;
use App\Helpers\ApiResponse;

class KolaboratorController extends Controller
{
    public function fetch()
    {
        return KolaboratorResource::collection(
            Kolaborator::orderBy('nama')->get()
        );
    }

    public function create(Request $request, AvatarService $avatarService)
    {
        try {

            $request->validate([
                'uploaded_file' => [
                    'sometimes',
                    'nullable',
                    'image',
                    'mimes:jpg,jpeg,png,webp',
                    'max:5120',
                ],
            ]);

            $avatarPath = null;

            if ($request->hasFile('uploaded_file')) {
                $avatarPath = $avatarService->processUpload(
                    $request->file('uploaded_file')
                );
            }

            $kolab = Kolaborator::create([
                'nama'       => $request->nama,
                'email'      => $request->email,
                'no_hp'      => $request->no_hp,
                'nidn'       => $request->nidn,
                'nuptk'      => $request->nuptk,
                'prodi'      => $request->prodi,
                'institusi'  => $request->institusi,
                'avatar'     => $avatarPath
            ]);

            return ApiResponse::success($kolab);

        } catch (\Exception $e) {

            \Log::error('Create failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    public function update(Request $request, AvatarService $avatarService)
    {
        try {

            $request->validate([
                'uploaded_file' => [
                    'sometimes',
                    'nullable',
                    'image',
                    'mimes:jpg,jpeg,png,webp',
                    'max:5120',
                ],
            ]);

            $kolab = Kolaborator::findOrFail($request->kolab_id);

            $avatarUrl = $request->hasFile('uploaded_file')
                ? $avatarService->replace(
                    $kolab->avatar,
                    $request->file('uploaded_file')
                )
                : $kolab->avatar;

            $kolab->update([
                'nama'       => $request->nama,
                'email'      => $request->email,
                'no_hp'      => $request->no_hp,
                'nidn'       => $request->nidn,
                'nuptk'      => $request->nuptk,
                'prodi'      => $request->prodi,
                'institusi'  => $request->institusi,
                'avatar'     => $avatarUrl
            ]);

            return ApiResponse::success();

        } catch (\Exception $e) {

            \Log::error('Update failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    public function delete(Request $request, AvatarService $avatarService)
    {
        try {

            $kolab = Kolaborator::findOrFail($request->id);

            $avatarService->delete($kolab->avatar);

            $kolab->delete();

            return ApiResponse::success();

        } catch (\Exception $e) {

            \Log::error('Delete failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }
}