<?php

namespace App\Http\Controllers;

use App\Models\Review;
use App\Models\PenugasanReviewer;
use App\Helpers\ApiResponse;

use Illuminate\Http\Request;

class ReviewController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Create Review
    |--------------------------------------------------------------------------
    */

    public function store(Request $request)
    {
        try {
            /*
            |--------------------------------------------------------------------------
            | Check Penugasan
            |--------------------------------------------------------------------------
            */

            $penugasan = PenugasanReviewer::findOrFail(
                $request->penugasan_id
            );

            /*
            |--------------------------------------------------------------------------
            | Prevent Duplicate Review
            |--------------------------------------------------------------------------
            */

            $existing = Review::where(
                'penugasan_id',
                $request->penugasan_id
            )->first();

            if ($existing) {
                \Log::error([
                    'status' => 'failed',
                    'message' => 'Review already exists'
                ], 409);

                return ApiResponse::failed($e->getMessage());
            }

            /*
            |--------------------------------------------------------------------------
            | Create Review
            |--------------------------------------------------------------------------
            */

            Review::create([
                'penugasan_id' => $request->penugasan_id,
                'keputusan' => $request->keputusan,
                'catatan' => $request->catatan,
                'tgl_review' => now(),

                'kriteria_kesesuaian_tema' => json_decode(
                    $request->kriteria_kesesuaian_tema,
                    true
                ),

                'kriteria_penilaian' => json_decode(
                    $request->kriteria_penilaian,
                    true
                ),
            ]);

            $penugasan->status_review = 'Telah direview';
            $penugasan->save();

            /*
            |--------------------------------------------------------------------------
            | Diseminasi: promote laporan when all reviewers approved
            |--------------------------------------------------------------------------
            | Mirrors the Proposal admin-approve flow, but scoped to a Laporan.
            |--------------------------------------------------------------------------
            */

            if ($penugasan->reviewable_type === 'App\\Models\\Laporan') {

                $penugasanList = \App\Models\PenugasanReviewer::with('review')
                    ->where('reviewable_type', 'App\\Models\\Laporan')
                    ->where('reviewable_id', $penugasan->reviewable_id)
                    ->get();

                $allReviewed = $penugasanList->every(
                    fn($p) => $p->status_review === 'Telah direview'
                );

                $anyRejected = $penugasanList->contains(
                    fn($p) => $p->review?->keputusan === 'Ditolak'
                );

                if ($allReviewed) {

                    $laporan = \App\Models\Laporan::with('periode')
                        ->find($penugasan->reviewable_id);

                    if ($laporan) {

                        if ($anyRejected) {

                            /*
                            |--------------------------------------------------------------------------
                            | Send back to Publikasi for revision
                            |--------------------------------------------------------------------------
                            */

                            $current = $laporan->kodePeriode();

                            $publikasi = str_replace(
                                'DISEMINASI',
                                'PUBLIKASI',
                                $current ?? ''
                            );

                            if (in_array($publikasi, ['PUBLIKASI_GANJIL', 'PUBLIKASI_GENAP'], true)) {
                                \App\Helpers\PeriodeStage::move(
                                    $laporan,
                                    $publikasi
                                );
                            }

                            $laporan->update([
                                'status' => 'Menunggu review',
                            ]);

                        } else {

                            /*
                            |--------------------------------------------------------------------------
                            | All approved: advance to next stage (Claim / Luaran)
                            |--------------------------------------------------------------------------
                            */

                            \App\Helpers\PeriodeStage::advance($laporan);

                            $laporan->update([
                                'status' => 'Dalam pengerjaan',
                            ]);
                        }
                    }
                }
            }

            return ApiResponse::success();
        }
        catch (\Exception $e) {

            \Log::error(
                'Review create failed: ' .
                $e->getMessage()
            );

            return ApiResponse::failed($e->getMessage());
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Update Review
    |--------------------------------------------------------------------------
    */

    public function update(Request $request)
    {
        try {
            /*
            |--------------------------------------------------------------------------
            | Find Review
            |--------------------------------------------------------------------------
            */

            $review = Review::findOrFail(
                $request->review_id
            );

            /*
            |--------------------------------------------------------------------------
            | Update Review
            |--------------------------------------------------------------------------
            */

            $review->update([

                'keputusan' => $request->keputusan,

                'catatan' => $request->catatan,

                'tgl_review' => now(),

                'kriteria_kesesuaian_tema' => json_decode(
                    $request->kriteria_kesesuaian_tema,
                    true
                ),

                'kriteria_penilaian' => json_decode(
                    $request->kriteria_penilaian,
                    true
                ),
            ]);

            return ApiResponse::success();

        }
        catch (\Exception $e) {
            \Log::error(
                'Review update failed: ' .
                $e->getMessage()
            );

            return ApiResponse::failed($e->getMessage());
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Fetch Single Review
    |--------------------------------------------------------------------------
    */

    public function show($id)
    {
        try {
            $review = Review::with([
                'penugasan'
            ])->findOrFail($id);

            return ApiResponse::success($review);
        }
        catch (\Exception $e) {
            \Log::error(
                'Review fetch failed: ' .
                $e->getMessage()
            );

            return ApiResponse::failed($e->getMessage());
        }
    }
}