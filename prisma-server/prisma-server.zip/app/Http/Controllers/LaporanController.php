<?php

namespace App\Http\Controllers;

use App\Models\Laporan;
use App\Models\ProposalMember;
use App\Models\Settings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Resources\Dosen\LaporanDosenResource;

use App\Services\LaporanAkhirDocxService;
use App\Helpers\ApiResponse;
use App\Helpers\PeriodeStage;

class LaporanController extends Controller
{
    public function index(Request $request)
    {
        $query = Laporan::query()
            ->with([
                'proposal',
                'proposal.memberDosenProposal.user',
                'proposal.memberMhswaProposal.mahasiswa',
                'proposal.memberKolabProposal.kolaborator',
                'periode' => fn($q) => $q->withTrashed(),
                'dokumen.currentVersion',
            ]);

        if ($request->has('semester')) {
            $query->where('semester', $request->semester);
        }

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        if ($request->has('kode_periode')) {
            $query->whereHas('periode', function ($q) use ($request) {
                $q->where('kode_periode', $request->kode_periode);
            });
        }

        $query->whereHas('proposal', function ($q) use ($request) {
            $q->where('user_id', $request->user()->id);
        });

        return LaporanDosenResource::collection(
            $query
                ->orderByDesc('tgl_mulai')
                ->paginate($request->get('per_page', 10))
        );
    }

    public function show($id)
    {
        $laporan = Laporan::with([
            'proposal',
            'proposal.members.user',
            'proposal.members.mahasiswa',
            'proposal.members.kolaborator',
        ])->findOrFail($id);

        return new LaporanDosenResource($laporan);
    }

    /*
    |--------------------------------------------------------------------------
    | Update Research Info
    |--------------------------------------------------------------------------
    | Researchers may update research information (title may change, data
    | may change) during the Laporan or Publikasi stage.
    |--------------------------------------------------------------------------
    */

    public function update(Request $request)
    {
        try {

            $validated = $request->validate([
                'laporan_id' => ['required', 'exists:laporan,laporan_id'],

                'judul_penelitian' => ['nullable', 'string', 'max:255'],
                'metode_penelitian' => ['nullable', 'string'],
                'unit_analisis' => ['nullable', 'string'],
                'target_publikasi' => ['nullable', 'string', 'max:255'],
                'institusi_mitra' => ['nullable', 'string', 'max:255'],

                'realisasi_data_collection' => ['nullable', 'numeric', 'min:0'],
                'realisasi_biaya_publikasi' => ['nullable', 'numeric', 'min:0'],
                'realisasi_insentif' => ['nullable', 'numeric', 'min:0'],
            ]);

            $laporan = $this->findOwnedLaporan($validated['laporan_id']);

            if (!$laporan) {
                return ApiResponse::failed('Laporan tidak ditemukan.');
            }

            if (!$this->stageIsOpen($laporan)) {
                return ApiResponse::failed(
                    'Periode untuk tahap ini belum dibuka.'
                );
            }

            unset($validated['laporan_id']);

            $laporan->update($validated);

            return ApiResponse::success(
                new LaporanDosenResource($laporan->fresh([
                    'proposal',
                    'dokumen.currentVersion',
                ]))
            );

        } catch (\Exception $e) {

            \Log::error('Update laporan failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Upload Revised Laporan Document (Google Drive link)
    |--------------------------------------------------------------------------
    */

    public function uploadDokumen(Request $request)
    {
        DB::beginTransaction();

        try {

            $validated = $request->validate([
                'laporan_id' => ['required', 'exists:laporan,laporan_id'],
                'drive_file_url' => ['required', 'url'],
                'catatan_revisi' => ['nullable', 'string'],
            ]);

            $laporan = $this->findOwnedLaporan($validated['laporan_id']);

            if (!$laporan) {
                return ApiResponse::failed('Laporan tidak ditemukan.');
            }

            if (!$this->stageIsOpen($laporan)) {
                return ApiResponse::failed(
                    'Periode untuk tahap ini belum dibuka.'
                );
            }

            $dokumen = $laporan->dokumen()
                ->firstOrCreate([
                    'jenis_dokumen' => 'Dokumen Laporan'
                ]);

            $nextVersion = (
                $dokumen->versions()->max('version') ?? 0
            ) + 1;

            $version = $dokumen->versions()->create([
                'version'          => $nextVersion,

                'nama_file'        => 'Dokumen Laporan v' . $nextVersion,

                'drive_file_id'    => '-',
                'drive_file_url'   => $validated['drive_file_url'],

                'local_file_url'   => '',

                'uploaded_by'      => auth()->id(),

                'catatan_revisi'   => $validated['catatan_revisi']
                    ?? ($nextVersion === 1
                        ? 'Upload dokumen laporan awal'
                        : 'Revisi dokumen laporan'),

                'tgl_upload'       => now(),
            ]);

            $dokumen->update([
                'current_version_id' => $version->version_id
            ]);

            DB::commit();

            return ApiResponse::success(
                $dokumen->fresh()->load('currentVersion')
            );

        } catch (\Exception $e) {

            DB::rollBack();

            \Log::error('Upload dokumen laporan failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Finish Report
    |--------------------------------------------------------------------------
    | When a researcher clicks Finish Report, the laporan automatically
    | enters the Publikasi stage.
    |--------------------------------------------------------------------------
    */

    public function finish(Request $request)
    {
        try {

            $validated = $request->validate([
                'laporan_id' => ['required', 'exists:laporan,laporan_id'],
            ]);

            $laporan = $this->findOwnedLaporan($validated['laporan_id']);

            if (!$laporan) {
                return ApiResponse::failed('Laporan tidak ditemukan.');
            }

            /*
            |--------------------------------------------------------------------------
            | Gate: current kode must be a PROSES_* stage (open)
            |--------------------------------------------------------------------------
            */

            $current = $laporan->kodePeriode();

            $prosesKodes = [
                'PROSES_PENELITIAN_GANJIL',
                'PROSES_PENELITIAN_GENAP',
                'PROSES_PKM_GANJIL',
                'PROSES_PKM_GENAP',
            ];

            if (!in_array($current, $prosesKodes, true)) {
                return ApiResponse::failed(
                    'Laporan sedang bukan pada tahap Proses.'
                );
            }

            if (!PeriodeStage::isOpen($laporan, $current)) {
                return ApiResponse::failed(
                    'Periode proses penelitian belum dibuka.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | Advance to next kode (Publikasi for Penelitian; also Publikasi
            | for PkM since PROSES_PKM_* → PUBLIKASI_* in the PkM sequence).
            |--------------------------------------------------------------------------
            */

            PeriodeStage::advance($laporan);

            $laporan->update([
                'tgl_submit' => now(),
            ]);

            return ApiResponse::success(
                new LaporanDosenResource($laporan->fresh(['proposal', 'periode']))
            );

        } catch (\Exception $e) {

            \Log::error('Finish laporan failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Generate Laporan Akhir Document
    |--------------------------------------------------------------------------
    */

    public function generateLaporanAkhir(
        Request $request,
        LaporanAkhirDocxService $laporanAkhirDocxService
    ) {
        DB::beginTransaction();

        try {

            $validated = $request->validate([
                'laporan_id' => ['required', 'exists:laporan,laporan_id'],
            ]);

            $laporan = $this->findOwnedLaporan($validated['laporan_id']);

            if (!$laporan) {
                return ApiResponse::failed('Laporan tidak ditemukan.');
            }

            $current = $laporan->kodePeriode();

            if (!in_array($current, ['PUBLIKASI_GANJIL', 'PUBLIKASI_GENAP'], true)) {
                return ApiResponse::failed(
                    'Laporan akhir hanya dapat digenerate pada tahap Publikasi.'
                );
            }

            if (!PeriodeStage::isOpen($laporan, $current)) {
                return ApiResponse::failed(
                    'Periode publikasi belum dibuka.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | Collect Data
            |--------------------------------------------------------------------------
            */

            $proposal = $laporan->proposal()->with([
                'user' => fn($q) => $q->withTrashed(),
                'user.prodi',
                'periode' => fn($q) => $q->withTrashed(),
                'periode.skema',
            ])->first();

            $proposalMembers = ProposalMember::with([
                'user',
                'user.prodi',
                'mahasiswa',
                'kolaborator'
            ])
            ->where('proposal_id', $laporan->proposal_id)
            ->get();

            $logbooks = $laporan->logbooks()
                ->orderBy('tgl_kegiatan')
                ->get();

            $settings = Settings::first();

            /*
            |--------------------------------------------------------------------------
            | Generate Document
            |--------------------------------------------------------------------------
            */

            $docxPath = $laporanAkhirDocxService->generate(
                $laporan,
                $proposal,
                $proposalMembers,
                $logbooks,
                $settings
            );

            /*
            |--------------------------------------------------------------------------
            | Store as Dokumen Version
            |--------------------------------------------------------------------------
            */

            $dokumen = $laporan->dokumen()
                ->firstOrCreate([
                    'jenis_dokumen' => 'Laporan Akhir'
                ]);

            $nextVersion = (
                $dokumen->versions()->max('version') ?? 0
            ) + 1;

            $version = $dokumen->versions()->create([
                'version'          => $nextVersion,

                'nama_file'        => basename($docxPath),

                'drive_file_id'    => '-',
                'drive_file_url'   => '-',

                'local_file_url'   => $docxPath,

                'uploaded_by'      => auth()->id(),

                'catatan_revisi'   => $nextVersion === 1
                    ? 'Generate laporan akhir awal'
                    : 'Regenerate laporan akhir',

                'tgl_upload'       => now(),
            ]);

            $dokumen->update([
                'current_version_id' => $version->version_id
            ]);

            DB::commit();

            return ApiResponse::success(
                $dokumen->fresh()->load('currentVersion')
            );

        } catch (\Exception $e) {

            DB::rollBack();

            \Log::error('Generate laporan akhir failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Submit Publikasi
    |--------------------------------------------------------------------------
    | Mandatory: link laporan akhir. For Penelitian the publication link is
    | mandatory, for PkM it is optional. All uploads are Google Drive links.
    |--------------------------------------------------------------------------
    */

    public function submitPublikasi(Request $request)
    {
        try {

            $validated = $request->validate([
                'laporan_id' => ['required', 'exists:laporan,laporan_id'],

                'link_laporan_akhir' => ['required', 'url'],

                'link_publikasi' => ['nullable', 'url'],

                'link_hki' => ['nullable', 'url'],
                'link_buku' => ['nullable', 'url'],
                'link_poster' => ['nullable', 'url'],
                'link_video' => ['nullable', 'url'],

                'dana_dikembalikan' => ['nullable', 'boolean'],
            ]);

            $laporan = $this->findOwnedLaporan($validated['laporan_id']);

            if (!$laporan) {
                return ApiResponse::failed('Laporan tidak ditemukan.');
            }

            $current = $laporan->kodePeriode();

            if (!in_array($current, ['PUBLIKASI_GANJIL', 'PUBLIKASI_GENAP'], true)) {
                return ApiResponse::failed(
                    'Laporan belum memasuki tahap Publikasi.'
                );
            }

            if (!PeriodeStage::isOpen($laporan, $current)) {
                return ApiResponse::failed(
                    'Periode publikasi belum dibuka.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | Publication link is mandatory for Penelitian
            |--------------------------------------------------------------------------
            */

            $isPenelitian =
                $laporan->proposal?->jenis_penelitian !== 'PkM';

            if ($isPenelitian && empty($validated['link_publikasi'])) {
                return ApiResponse::failed(
                    'Link publikasi wajib diisi untuk Penelitian.'
                );
            }

            $laporan->update([
                'link_laporan_akhir' => $validated['link_laporan_akhir'],
                'link_publikasi' => $validated['link_publikasi'] ?? null,

                'link_hki' => $validated['link_hki'] ?? null,
                'link_buku' => $validated['link_buku'] ?? null,
                'link_poster' => $validated['link_poster'] ?? null,
                'link_video' => $validated['link_video'] ?? null,

                'dana_dikembalikan' =>
                    filter_var(
                        $request->input('dana_dikembalikan', false),
                        FILTER_VALIDATE_BOOLEAN
                    ),

                'status' => 'Menunggu review',
            ]);

            /*
            |--------------------------------------------------------------------------
            | Advance stage: PUBLIKASI_* → DISEMINASI_*
            |--------------------------------------------------------------------------
            */

            PeriodeStage::advance($laporan);

            return ApiResponse::success(
                new LaporanDosenResource($laporan->fresh(['proposal', 'periode']))
            );

        } catch (\Exception $e) {

            \Log::error('Submit publikasi failed: ' . $e->getMessage());

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Helpers
    |--------------------------------------------------------------------------
    */

    private function findOwnedLaporan($laporanId)
    {
        return Laporan::with([
            'proposal' => fn($q) => $q->withTrashed(),
        ])
        ->where('laporan_id', $laporanId)
        ->whereHas('proposal', function ($q) {
            $q->where('user_id', auth()->id());
        })
        ->first();
    }

    private function stageIsOpen(Laporan $laporan)
    {
        $kode = $laporan->kodePeriode();

        if (!$kode) {
            return false;
        }

        return PeriodeStage::isOpen($laporan, $kode);
    }
}
