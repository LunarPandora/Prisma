<?php

namespace App\Http\Controllers\Proposal;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\Proposal;
use App\Models\ProposalMember;
use App\Models\Dokumen;
use App\Models\DokumenVersion;
use App\Models\PenugasanReviewer;
use App\Models\Settings;
use App\Models\Laporan;

use App\Http\Resources\Admin\ProposalAdminResource;
use App\Http\Resources\Dosen\ProposalDosenResource;
use App\Http\Resources\Reviewer\ProposalReviewerResource;

use App\Http\Resources\Dosen\ProposalUploadResource;

use App\Services\ProposalDocxService;
use App\Services\DocumentService;
use App\Helpers\ApiResponse;

class ProposalDocumentController extends Controller
{
    public function prepareProposalUpload(Request $request)
    {
        /*
        |--------------------------------------------------------------------------
        | Load Proposal
        |--------------------------------------------------------------------------
        */

        $proposal = Proposal::with([
            'user' => fn($q) => $q->withTrashed(),

            'dokumen' => fn($q) => $q->withTrashed()
                ->where('jenis_dokumen', 'Halaman Pengesahan')
                ->limit(1),
        ])
        ->where('proposal_id', $request->proposal_id)
        ->first();

        if (!$proposal) {
            \Log::error('Fetch failed: No document were found.');

            return ApiResponse::failed();
        }

        $absolutePath = storage_path('app/' . $proposal->local_file_url);

        /*
        |--------------------------------------------------------------------------
        | Check File Exists
        |--------------------------------------------------------------------------
        */

        if (!file_exists($absolutePath)) {
            \Log::error('Fetch failed: File does not exist.');

            return ApiResponse::failed();
        }

        /*
        |--------------------------------------------------------------------------
        | Return
        |--------------------------------------------------------------------------
        */

        return ApiResponse::success($proposal->dokumen[0]->file_url);
    }

    public function uploadProposal(
        Request $request,
        DocumentService $documentService
    ) {
        DB::beginTransaction();

        try {

            $request->validate([
                'uploaded_file' => [
                    'required',
                    'file',
                    'max:10240',
                    'mimes:pdf',
                    'mimetypes:application/pdf',
                ],
            ]);

            /*
            |--------------------------------------------------------------------------
            | Find Proposal
            |--------------------------------------------------------------------------
            */

            $proposal = Proposal::findOrFail(
                $request->proposal_id
            );

            /*
            |--------------------------------------------------------------------------
            | Upload File
            |--------------------------------------------------------------------------
            */

            $file = $request->file('uploaded_file');

            $relativePath = $documentService->upload(
                $file,
                'documents/proposal'
            );

            /*
            |--------------------------------------------------------------------------
            | Generate File Name
            |--------------------------------------------------------------------------
            */

            $originalName = pathinfo(
                $file->getClientOriginalName(),
                PATHINFO_FILENAME
            );

            $extension = $file->getClientOriginalExtension();

            $timestamp = now()->format('Ymd_His');

            $namaFile = $originalName . '_' . $timestamp . '.' . $extension;

            /*
            |--------------------------------------------------------------------------
            | Find/Create Dokumen Container
            |--------------------------------------------------------------------------
            */

            $dokumen = $proposal->dokumen()
                ->firstOrCreate([
                    'jenis_dokumen' => 'Dokumen Proposal'
                ]);

            /*
            |--------------------------------------------------------------------------
            | Get Next Version
            |--------------------------------------------------------------------------
            */

            $nextVersion = (
                $dokumen->versions()->max('version') ?? 0
            ) + 1;

            /*
            |--------------------------------------------------------------------------
            | Create New Version
            |--------------------------------------------------------------------------
            */

            $version = $dokumen->versions()->create([
                'version'          => $nextVersion,

                'nama_file'        => $namaFile,

                'drive_file_id'    => '-',
                'drive_file_url'   => '-',

                'local_file_url'   => $relativePath,

                'uploaded_by'      => auth()->id(),

                'catatan_revisi'   => $nextVersion === 1
                    ? 'Upload proposal awal'
                    : 'Revisi dokumen proposal',

                'tgl_upload'       => now(),
            ]);

            /*
            |--------------------------------------------------------------------------
            | Set Current Version
            |--------------------------------------------------------------------------
            */

            $dokumen->update([
                'current_version_id' => $version->version_id
            ]);

            /*
            |--------------------------------------------------------------------------
            | Update Proposal Status
            |--------------------------------------------------------------------------
            */

            $proposal->update([
                'status' => 'Menunggu penugasan reviewer'
            ]);

            DB::commit();

            return ApiResponse::success();

        } catch (\Exception $e) {

            DB::rollBack();

            \Log::error(
                'Upload failed: ' . $e->getMessage()
            );

            return ApiResponse::failed();
        }
    }
}
