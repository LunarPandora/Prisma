<?php

namespace App\Http\Controllers\Proposal;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\Proposal;
use App\Models\ProposalMember;
use App\Models\Dokumen;
use App\Models\DokumenVersion;
use App\Models\PenugasanReviewer;
use App\Models\Settings;
use App\Models\Laporan;

use App\Http\Resources\Admin\ProposalAdminResource;
use App\Http\Resources\Dosen\ProposalDosenResource;
use App\Http\Resources\Reviewer\ProposalReviewerResource;

use App\Http\Resources\Dosen\ProposalUploadResource;

use App\Services\ProposalDocxService;
use App\Services\DocumentService;
use App\Helpers\ApiResponse;

class ProposalController extends Controller
{
    public function index(Request $request)
    {
        $query = Proposal::with([
            'prodi',

            'user' => fn($q) => $q->withTrashed(),
            
            'periode' => fn($q) => $q->withTrashed(),

            'dokumen.currentVersion' => fn($q) => $q->withTrashed(),

            'penugasan' => fn($q) =>
                $q->select(
                    'penugasan_id',
                    'proposal_id',
                    'user_id',
                    'tgl_penugasan',
                    'status_review'
                )
                ->with([
                    'reviewer' => fn($q2) =>
                        $q2->select(
                            'id',
                            'nama',
                            'avatar'
                        ),
                    'review'
                ]),

            'memberDosenProposal' => fn($q) =>
                $q->where('role', 'Dosen')
                ->select('prop_member_id', 'proposal_id', 'member_id', 'ttjp', 'semester')
                ->with([
                    'user' => fn($q2) =>
                        $q2->select(
                            'id',
                            'nama',
                            'avatar',
                            'nidn'
                        )
                ]),

            'memberMhswaProposal' => fn($q) =>
                $q->where('role', 'Mahasiswa')
                ->select('prop_member_id', 'proposal_id', 'member_id', 'ttjp', 'semester')
                ->with([
                    'mahasiswa' => fn($q2) =>
                        $q2->select(
                            'mhswa_id',
                            'nama',
                            'avatar',
                            'nim'
                        )
                ]),

            'memberKolabProposal' => fn($q) =>
                $q->where('role', 'Kolaborator')
                ->select('prop_member_id', 'proposal_id', 'member_id', 'ttjp', 'semester')
                ->with([
                    'kolaborator' => fn($q2) =>
                        $q2->select(
                            'kolab_id',
                            'nama',
                            'avatar',
                            'nidn'
                        )
                ]),
        ]);

        if ($search = request('search')) {
            $query->where(function ($q) use ($search) {
                $q->where('judul', 'like', "%{$search}%")
                ->orWhereHas('user', function ($q2) use ($search) {
                    $q2->where('nama', 'like', "%{$search}%");
                })
                ->orWhereHas('penugasan.reviewer', function ($q2) use ($search) {
                    $q2->where('nama', 'like', "%{$search}%");
                });
            });
        }

        /*
        |--------------------------------------------------------------------------
        | Filters
        |--------------------------------------------------------------------------
        */

        $this->applyFilters(
            $query,
            $request
        );

        $user = auth()->user();
        if ($user->role === 'Admin') {

            $query->where('status', '!=', 'Draft');

            $settings = Settings::first();

            return ProposalAdminResource::collection(
                $query
                    ->orderBy('periode_id')
                    ->paginate(10)
                    ->through(fn ($proposal) =>
                        $this->detailKriteria(
                            $proposal,
                            $settings
                        )
                    )
            );
        }

        if ($user->role === 'Dosen') {
            $query->where('user_id', $user->id);

            return ProposalDosenResource::collection(
                $query->orderBy('periode_id')->paginate(10)
            );
        }

        if ($user->role === 'Reviewer') {
            $query->whereHas('penugasan', function ($q) use ($user) {
                $q->where('user_id', $user->id);
            });

            $settings = Settings::first();

            return ProposalReviewerResource::collection(
                $query
                    ->orderBy('periode_id')
                    ->paginate(10)
                    ->through(fn ($proposal) =>
                        $this->detailKriteria(
                            $proposal,
                            $settings,
                            $user
                        )
                    )
            );
        }
    }

    private function detailKriteria($proposal, $settings, $user = null)
    {
        /*
        |--------------------------------------------------------------------------
        | Get Current Reviewer's Penugasan ID
        |--------------------------------------------------------------------------
        */

        if ($user && $user->role === 'Reviewer') {

            $currentPenugasan = $proposal->penugasan
                ->firstWhere('user_id', $user->id);

            $proposal->setAttribute(
                'penugasan_id',
                $currentPenugasan?->penugasan_id
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Global Kriteria Penilaian
        |--------------------------------------------------------------------------
        */

        $proposal->setAttribute(
            'kriteria_kesesuaian_tema',
            $settings?->list_kesesuaian_tema ?? []
        );

        $proposal->setAttribute(
            'kriteria_penilaian',
            $settings?->kriteria_penilaian ?? []
        );

        return $proposal;
    }

    private function applyFilters($query, Request $request)
    {
        if ($request->filled('kode_periode')) {
            $query->whereHas('periode', function ($q) use ($request) {
                $q->where('kode_periode', $request->kode_periode);
            });
        }

        if ($request->filled('periode_id')) {
            $query->where('periode_id', $request->periode_id);
        }

        if ($request->filled('skema_id')) {
            $query->whereHas('periode', function ($q) use ($request) {
                $q->where('skema_id', $request->skema_id);
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        return $query;
    }
}
