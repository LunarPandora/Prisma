<?php

namespace App\Http\Controllers\Proposal;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\Models\Proposal;
use App\Models\Dokumen;
use App\Models\DokumenVersion;
use App\Models\Laporan;
use App\Models\PeriodePengajuan;
use App\Models\Settings;

use App\Services\PengumumanSkService;
use App\Services\DocumentService;
use App\Helpers\ApiResponse;

class PengumumanSkController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Fetch SK Documents for a Skema + Jenis
    |--------------------------------------------------------------------------
    */

    public function fetch(Request $request)
    {
        try {

            $periode = $this->findPeriode(
                $request->skema_id,
                $request->jenis_penelitian,
                'PENGUMUMAN_SK'
            );

            if (!$periode) {
                return ApiResponse::failed(
                    'Periode Pengumuman SK tidak ditemukan.'
                );
            }

            $dokumen = $periode->dokumen()
                ->with('currentVersion')
                ->whereIn('jenis_dokumen', [
                    'Pengumuman SK',
                    'SK Resmi'
                ])
                ->get();

            return ApiResponse::success([
                'periode' => $periode,
                'dokumen' => $dokumen,
            ]);

        } catch (\Exception $e) {

            \Log::error($e);

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Generate Pengumuman SK Document
    |--------------------------------------------------------------------------
    */

    public function generate(
        Request $request,
        PengumumanSkService $pengumumanSkService
    ) {
        DB::beginTransaction();

        try {

            $periode = $this->findPeriode(
                $request->skema_id,
                $request->jenis_penelitian,
                'PENGUMUMAN_SK'
            );

            if (!$periode) {
                return ApiResponse::failed(
                    'Periode Pengumuman SK tidak ditemukan.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | Proposals in Pengumuman Stage
            |--------------------------------------------------------------------------
            */

            $proposals = Proposal::with([
                'user' => fn($q) => $q->withTrashed(),
                'user.prodi',
            ])
            ->where('periode_id', $periode->periode_id)
            ->where('status', '!=', 'Ditolak')
            ->orderBy('proposal_id')
            ->get();

            if ($proposals->count() < 1) {
                return ApiResponse::failed(
                    'Belum ada proposal yang lolos seleksi pada periode ini.'
                );
            }

            $settings = Settings::with([
                'kepalaLppmUser',
                'rektorUser'
            ])->first();

            /*
            |--------------------------------------------------------------------------
            | Generate Document
            |--------------------------------------------------------------------------
            */

            $docxPath = $pengumumanSkService->generate(
                $periode,
                $proposals,
                $settings
            );

            /*
            |--------------------------------------------------------------------------
            | Store as Dokumen Version
            |--------------------------------------------------------------------------
            */

            $dokumen = $periode->dokumen()
                ->firstOrCreate([
                    'jenis_dokumen' => 'Pengumuman SK'
                ]);

            $nextVersion = (
                $dokumen->versions()->max('version') ?? 0
            ) + 1;

            $version = $dokumen->versions()->create([
                'version'          => $nextVersion,

                'nama_file'        => basename($docxPath),

                'drive_file_id'    => '-',
                'drive_file_url'   => '-',

                'local_file_url'   => $docxPath,

                'uploaded_by'      => auth()->id(),

                'catatan_revisi'   => $nextVersion === 1
                    ? 'Generate pengumuman SK awal'
                    : 'Regenerate pengumuman SK',

                'tgl_upload'       => now(),
            ]);

            $dokumen->update([
                'current_version_id' => $version->version_id
            ]);

            DB::commit();

            return ApiResponse::success(
                $dokumen->fresh()->load('currentVersion')
            );

        } catch (\Exception $e) {

            DB::rollBack();

            \Log::error(
                'Generate SK failed: ' . $e->getMessage()
            );

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Upload Official SK
    |--------------------------------------------------------------------------
    | After upload:
    | - Close SELEKSI_PROPOSAL and PENGUMUMAN_SK
    | - Open the next stage (PROSES_PENELITIAN_GANJIL / CLAIM_DANA_GANJIL)
    | - Move approved proposals into the next stage
    | - Split each proposal into Laporan Ganjil + Laporan Genap
    |--------------------------------------------------------------------------
    */

    public function upload(
        Request $request,
        DocumentService $documentService
    ) {
        DB::beginTransaction();

        try {

            $request->validate([
                'uploaded_file' => [
                    'required',
                    'file',
                    'max:10240',
                    'mimes:pdf',
                    'mimetypes:application/pdf',
                ],
            ]);

            $periode = $this->findPeriode(
                $request->skema_id,
                $request->jenis_penelitian,
                'PENGUMUMAN_SK'
            );

            if (!$periode) {
                return ApiResponse::failed(
                    'Periode Pengumuman SK tidak ditemukan.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | Upload File
            |--------------------------------------------------------------------------
            */

            $file = $request->file('uploaded_file');

            $relativePath = $documentService->upload(
                $file,
                'documents/sk'
            );

            $originalName = pathinfo(
                $file->getClientOriginalName(),
                PATHINFO_FILENAME
            );

            $extension = $file->getClientOriginalExtension();

            $timestamp = now()->format('Ymd_His');

            $namaFile = $originalName . '_' . $timestamp . '.' . $extension;

            /*
            |--------------------------------------------------------------------------
            | Store as Dokumen Version
            |--------------------------------------------------------------------------
            */

            $dokumen = $periode->dokumen()
                ->firstOrCreate([
                    'jenis_dokumen' => 'SK Resmi'
                ]);

            $nextVersion = (
                $dokumen->versions()->max('version') ?? 0
            ) + 1;

            $version = $dokumen->versions()->create([
                'version'          => $nextVersion,

                'nama_file'        => $namaFile,

                'drive_file_id'    => '-',
                'drive_file_url'   => '-',

                'local_file_url'   => $relativePath,

                'uploaded_by'      => auth()->id(),

                'catatan_revisi'   => $nextVersion === 1
                    ? 'Upload SK resmi'
                    : 'Revisi SK resmi',

                'tgl_upload'       => now(),
            ]);

            $dokumen->update([
                'current_version_id' => $version->version_id
            ]);

            /*
            |--------------------------------------------------------------------------
            | Move Periode Forward
            |--------------------------------------------------------------------------
            */

            $nextPeriode = $this->moveToNextStage($periode);

            /*
            |--------------------------------------------------------------------------
            | Split Proposals into Laporan Ganjil + Genap
            |--------------------------------------------------------------------------
            */

            $proposals = Proposal::where(
                'periode_id',
                $periode->periode_id
            )
            ->where('status', '!=', 'Ditolak')
            ->get();

            foreach ($proposals as $proposal) {

                $this->splitLaporan($proposal);

                $proposal->update([
                    'periode_id' => $nextPeriode->periode_id,
                    'tahap_penelitian' => 'Laporan',
                    'status' => 'Dalam pengerjaan',
                ]);
            }
            DB::commit();

            return ApiResponse::success();

        } catch (\Exception $e) {

            DB::rollBack();

            \Log::error(
                'Upload SK failed: ' . $e->getMessage()
            );

            return ApiResponse::failed();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Helpers
    |--------------------------------------------------------------------------
    */

    private function findPeriode($skemaId, $jenisPenelitian, $kodePeriode)
    {
        return PeriodePengajuan::with('skema')
            ->where('skema_id', $skemaId)
            ->where('jenis_penelitian', $jenisPenelitian)
            ->where('kode_periode', $kodePeriode)
            ->first();
    }

    private function moveToNextStage(PeriodePengajuan $periode)
    {
        /*
        |--------------------------------------------------------------------------
        | Close Seleksi + Pengumuman
        |--------------------------------------------------------------------------
        */

        PeriodePengajuan::where('skema_id', $periode->skema_id)
            ->where('jenis_penelitian', $periode->jenis_penelitian)
            ->whereIn('kode_periode', [
                'SELEKSI_PROPOSAL',
                'PENGUMUMAN_SK'
            ])
            ->update([
                'status' => 'Selesai'
            ]);

        /*
        |--------------------------------------------------------------------------
        | Open Next Stage
        |--------------------------------------------------------------------------
        | After PENGUMUMAN_SK the workflow moves out of the Proposal sequence
        | into the first Laporan stage (Ganjil), which depends on jenis.
        |--------------------------------------------------------------------------
        */

        $nextKode = \App\Helpers\PeriodeStage::firstLaporanStage(
            $periode->jenis_penelitian,
            'Ganjil'
        );

        $nextPeriode = $this->findPeriode(
            $periode->skema_id,
            $periode->jenis_penelitian,
            $nextKode
        );

        if (!$nextPeriode) {
            throw new \Exception(
                "Periode {$nextKode} tidak ditemukan untuk skema ini."
            );
        }

        $nextPeriode->update([
            'status' => 'Terbuka'
        ]);

        return $nextPeriode;
    }

    private function splitLaporan(Proposal $proposal)
    {
        /*
        |--------------------------------------------------------------------------
        | Locate each semester's first stage from its own sequence.
        |--------------------------------------------------------------------------
        */

        $ganjilKode = \App\Helpers\PeriodeStage::firstLaporanStage(
            $proposal->jenis_penelitian,
            'Ganjil'
        );

        $genapKode = \App\Helpers\PeriodeStage::firstLaporanStage(
            $proposal->jenis_penelitian,
            'Genap'
        );

        $ganjilPeriode = \App\Models\PeriodePengajuan::where(
            'skema_id',
            $proposal->periode?->skema_id
        )
        ->where('jenis_penelitian', $proposal->jenis_penelitian)
        ->where('kode_periode', $ganjilKode)
        ->first();

        $genapPeriode = \App\Models\PeriodePengajuan::where(
            'skema_id',
            $proposal->periode?->skema_id
        )
        ->where('jenis_penelitian', $proposal->jenis_penelitian)
        ->where('kode_periode', $genapKode)
        ->first();

        /*
        |--------------------------------------------------------------------------
        | Laporan Ganjil
        |--------------------------------------------------------------------------
        */

        Laporan::firstOrCreate(
            [
                'proposal_id' => $proposal->proposal_id,
                'semester'    => 'Ganjil',
            ],
            [
                'periode_id'        => $ganjilPeriode?->periode_id,
                'judul_penelitian'  => $proposal->topik_penelitian,
                'metode_penelitian' => $proposal->metopen_gan,
                'unit_analisis'     => $proposal->unit_analisis_gan,
                'target_publikasi'  => $proposal->target_publikasi_gan,
                'institusi_mitra'   => $proposal->institusi_mitra,
                'status'            => 'Dalam pengerjaan',
                'tgl_mulai'         => now(),
                'catatan'           => '-',
            ]
        );

        /*
        |--------------------------------------------------------------------------
        | Laporan Genap
        |--------------------------------------------------------------------------
        */

        Laporan::firstOrCreate(
            [
                'proposal_id' => $proposal->proposal_id,
                'semester'    => 'Genap',
            ],
            [
                'periode_id'        => $genapPeriode?->periode_id,
                'judul_penelitian'  => $proposal->topik_penelitian,
                'metode_penelitian' => $proposal->metopen_gen,
                'unit_analisis'     => $proposal->unit_analisis_gen,
                'target_publikasi'  => $proposal->target_publikasi_gen,
                'institusi_mitra'   => $proposal->institusi_mitra,
                'status'            => 'Belum dimulai',
                'catatan'           => '-',
            ]
        );
    }
}
