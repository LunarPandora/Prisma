<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;

use App\Models\User;

use App\Http\Resources\UserResource;
use App\Helpers\ApiResponse;

use App\Services\AvatarService;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class UserController extends Controller
{
    public function index()
    {
        return UserResource::collection(
            User::orderBy('id')
                ->paginate(10, [
                    'id',
                    'nama',
                    'email',
                    'role',
                    'status',
                    'gender',
                    'avatar',
                    'nidn',
                    'prodi_id',
                    'created_at'
                ])
        );
    }

    public function fetch(){
        return UserResource::collection(
            User::orderBy('id')->get()
        );
    }

    public function create(Request $request, AvatarService $avatarService)
    {
        try {
            $request->validate([
                'uploaded_file' => [
                    'sometimes',
                    'nullable',
                    'image',
                    'mimes:jpg,jpeg,png,webp',
                    'max:5120',
                ],
            ]);

            $avatarPath = null;

            if ($request->hasFile('uploaded_file')) {
                $avatarPath = $avatarService->processUpload($request->file('uploaded_file'));
            }

            $user = User::create([
                'nama'     => $request->nama,
                'email'    => $request->email,
                'password' => Hash::make($request->password),
                'role'     => $request->role,
                'status'   => $request->status,
                'gender'   => $request->gender,
                'nidn'     => $request->nidn,
                'prodi_id' => $request->prodi_id,
                'avatar'   => $avatarPath
            ]);

            return ApiResponse::success();
        } catch (\Exception $e) {
            \Log::error('Create failed: ' . $e->getMessage());
            return ApiResponse::failed();
        }
    }

    public function update(Request $request, AvatarService $avatarService){
        try {
            $request->validate([
                'uploaded_file' => [
                    'sometimes',
                    'nullable',
                    'image',
                    'mimes:jpg,jpeg,png,webp',
                    'max:5120',
                ],
            ]);

            $user = User::findOrFail($request->id);
            $avatarUrl = $request->hasFile('uploaded_file')
                ? $avatarService->replace($user->avatar, $request->file('uploaded_file'))
                : $user->avatar;

            // Update user
            $user->update([
                'nama'     => $request->nama,
                'email'    => $request->email,
                'role'     => $request->role,
                'status'   => $request->status,
                'gender'   => $request->gender,
                'nidn'     => $request->nidn,
                'prodi_id' => $request->prodi_id,
                'avatar'   => $avatarUrl
            ]);

            return ApiResponse::success();
        } catch (\Exception $e) {
            \Log::error('Update failed: '.$e->getMessage());

            return ApiResponse::failed();
        }
    }

    public function delete(Request $request, AvatarService $avatarService){
        try {
            $user = User::findOrFail($request->id);

            $user->status = 'Nonaktif'; // disable the user
            $user->save(); // save status change

            $avatarService->delete($user->avatar);
            $user->delete();

            return ApiResponse::success();
        } catch (\Exception $e) {
            \Log::error('Delete failed: ' . $e->getMessage());
            return ApiResponse::failed();
        }
    }
}
