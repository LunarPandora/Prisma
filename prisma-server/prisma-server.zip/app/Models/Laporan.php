<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Laporan extends Model
{
    use SoftDeletes;

    protected $primaryKey = "laporan_id";
    protected $table = "laporan";

    protected $fillable = [
        'proposal_id',
        'periode_id',

        'semester',

        'judul_penelitian',
        'metode_penelitian',
        'unit_analisis',

        'link_luaran_drive_id',
        'link_luaran_drive_url',

        'target_publikasi',
        'link_publikasi',

        'link_laporan_akhir',
        'link_hki',
        'link_buku',
        'link_poster',
        'link_video',

        'dana_dikembalikan',

        'claim_dana_status',
        'claim_dana_approved_at',
        'claim_dana_confirmed_at',

        'pengembalian_dana_status',
        'pengembalian_dana_confirmed_at',

        'institusi_mitra',

        'realisasi_data_collection',
        'realisasi_biaya_publikasi',
        'realisasi_insentif',

        'status',
        // 'tahap' — replaced by periode_id → kode_periode

        'tgl_mulai',
        'tgl_submit',
        'tgl_selesai',

        'current_logbook_id',

        'catatan',
    ];

    protected $casts = [
        'tgl_mulai' => 'date',
        'tgl_submit' => 'date',
        'tgl_selesai' => 'date',

        'realisasi_data_collection' => 'double',
        'realisasi_biaya_publikasi' => 'double',
        'realisasi_insentif' => 'double',

        'dana_dikembalikan' => 'boolean',

        'claim_dana_approved_at' => 'datetime',
        'claim_dana_confirmed_at' => 'datetime',
        'pengembalian_dana_confirmed_at' => 'datetime',
    ];

    /*
    |--------------------------------------------------------------------------
    | Stage (kode_periode is the source of truth)
    |--------------------------------------------------------------------------
    */

    public function periode()
    {
        return $this->belongsTo(
            PeriodePengajuan::class,
            'periode_id',
            'periode_id'
        );
    }

    public function kodePeriode(): ?string
    {
        return $this->periode()
            ->withTrashed()
            ->first()
            ?->kode_periode;
    }

    /*
    |--------------------------------------------------------------------------
    | Proposal
    |--------------------------------------------------------------------------
    */

    public function proposal()
    {
        return $this->belongsTo(
            Proposal::class,
            'proposal_id',
            'proposal_id'
        );
    }

    public function logbooks()
    {
        return $this->hasMany(
            LogbookPengerjaan::class,
            'laporan_id',
            'laporan_id'
        );
    }

    public function currentLogbook()
    {
        return $this->belongsTo(
            LogbookPengerjaan::class,
            'current_logbook_id',
            'logbook_id'
        );
    }

    public function dokumen()
    {
        return $this->morphMany(
            Dokumen::class,
            'documentable'
        );
    }

    public function penugasan()
    {
        return $this->morphMany(
            PenugasanReviewer::class,
            'reviewable'
        );
    }

    public function isGanjil()
    {
        return $this->semester === 'Ganjil';
    }

    public function isGenap()
    {
        return $this->semester === 'Genap';
    }

    public function isFinished()
    {
        return $this->status === 'Selesai';
    }

    public function isRevisi()
    {
        return $this->status === 'Revisi';
    }

    public function isDalamPengerjaan()
    {
        return $this->status === 'Dalam pengerjaan';
    }

    public function isMenungguReview()
    {
        return $this->status === 'Menunggu review';
    }
}