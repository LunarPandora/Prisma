<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Services\AvatarService;

class Mahasiswa extends Model
{
    use SoftDeletes;

    protected $primaryKey = "mhswa_id";
    protected $table = "mahasiswa";

    protected $fillable = [
        'nim',
        'nama',
        'prodi_id',
        'avatar'
    ];

    protected $appends = ['avatar_url'];

    public function prodi(){
        return $this->belongsTo(Prodi::class, 'prodi_id');
    }

    public function getAvatarUrlAttribute()
    {
        if ($this->avatar) {
            return asset($this->avatar);
        }

        $service = app(AvatarService::class);

        return asset(
            $service->generateAndStore($this->nama, $this->mhswa_id)
        );
    }
}
