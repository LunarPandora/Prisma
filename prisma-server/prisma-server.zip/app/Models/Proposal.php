<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Proposal extends Model
{
    use SoftDeletes;
    
    protected $primaryKey = "proposal_id";
    protected $table = "proposal";

    protected $fillable = [
        'topik_penelitian',
        'jenis_penelitian',
        'tahap_penelitian',
        'bidang_ilmu',
        'fokus_sdg',
        'ra_data_collection',
        'ra_biaya_publikasi',
        'ra_insentif',

        'target_publikasi_gan',
        'target_publikasi_gen',
        'rencana_judul_publikasi_gan',
        'rencana_judul_publikasi_gen',
        'metopen_gan',
        'metopen_gen',
        'unit_analisis_gan',
        'unit_analisis_gen',
        'kontribusi_ilmu_makul',
        'kontribusi_pkm',

        'rencana_luaran',
        'institusi_mitra',
        'user_id',
        'periode_id',
        'skema',
        'sumber_skema',
        'status',
        'tgl_pengajuan',
        'catatan'
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function periode()
    {
        return $this->belongsTo(PeriodePengajuan::class, 'periode_id');
    }

    public function dokumen()
    {
        return $this->morphMany(
            Dokumen::class,
            'documentable'
        );
    }

    public function penugasan()
    {
        return $this->hasMany(PenugasanReviewer::class, 'proposal_id');
    }

    public function prodi()
    {
        return $this->belongsTo(Prodi::class, 'prodi_id', 'prodi_id');
    }

    public function laporan()
    {
        return $this->hasMany(Laporan::class, 'proposal_id', 'proposal_id');
    }

    public function memberDosenProposal()
    {
        return $this->hasMany(ProposalMember::class, 'proposal_id')
            ->where('role', 'Dosen');
    }

    public function memberMhswaProposal()
    {
        return $this->hasMany(ProposalMember::class, 'proposal_id')
            ->where('role', 'Mahasiswa');
    }

    public function memberKolabProposal()
    {
        return $this->hasMany(ProposalMember::class, 'proposal_id')
            ->where('role', 'Kolaborator');
    }
}
