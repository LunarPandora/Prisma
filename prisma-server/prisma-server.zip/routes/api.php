<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\UserController;
use App\Http\Controllers\ReviewerController;
use App\Http\Controllers\DosenController;
use App\Http\Controllers\MahasiswaController;
use App\Http\Controllers\KolaboratorController;
use App\Http\Controllers\ProdiController;

use App\Http\Controllers\Proposal\ProposalController;
use App\Http\Controllers\Proposal\ProposalDraftController;
use App\Http\Controllers\Proposal\ProposalDocumentController;
use App\Http\Controllers\Proposal\ProposalWorkflowController;
use App\Http\Controllers\Proposal\PengumumanSkController;

use App\Http\Controllers\SkemaController;
use App\Http\Controllers\PenelitiDetailController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\PeriodePengajuanController;
use App\Http\Controllers\PenugasanReviewerController;
use App\Http\Controllers\PublicationCategoryController;
use App\Http\Controllers\LogbookPengerjaanController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\DiseminasiController;
use App\Http\Controllers\DanaController;
use App\Http\Controllers\SitasiController;

Route::middleware(['auth:sanctum'])->group(function () {
    Route::prefix('users')->group(function (){
        Route::get('/', [UserController::class, 'index']);
        Route::get('/fetch', [UserController::class, 'fetch']);
        Route::get('/me', function(Request $request){
            return $request->user();
        });
        Route::post('/add', [UserController::class, 'create']);
        Route::post('/update', [UserController::class, 'update']);
        Route::delete('/delete/{id}', [UserController::class, 'delete']);
    });

    Route::prefix('reviewer')->group(function (){
        Route::get('/', [ReviewerController::class, 'index']);
    });

    Route::prefix('dosen')->group(function (){
        Route::get('/', [DosenController::class, 'index']);
    });

    Route::prefix('mahasiswa')->group(function (){
        Route::get('/fetch', [MahasiswaController::class, 'fetch']);
        Route::post('/add', [MahasiswaController::class, 'create']);
        Route::post('/update', [MahasiswaController::class, 'update']);
        Route::delete('/delete/{id}', [MahasiswaController::class, 'delete']);
    });

    Route::prefix('kolaborator')->group(function (){
        Route::get('/fetch', [KolaboratorController::class, 'fetch']);
        Route::post('/add', [KolaboratorController::class, 'create']);
        Route::post('/update', [KolaboratorController::class, 'update']);
        Route::delete('/delete/{id}', [KolaboratorController::class, 'delete']);
    });

    Route::prefix('prodi')->group(function (){
        Route::get('/', [ProdiController::class, 'index']);
        Route::get('/fetch', [ProdiController::class, 'fetch']);
        
        Route::post('/add', [ProdiController::class, 'create']);
        Route::post('/update', [ProdiController::class, 'update']);
        Route::delete('/delete/{id}', [ProdiController::class, 'delete']);
    });

    Route::prefix('proposal')->group(function (){
        /*
        |--------------------------------------------------------------------------
        | Proposal
        |--------------------------------------------------------------------------
        */

        Route::get('/', [ProposalController::class, 'index']);
        Route::get('/fetch', [ProposalController::class, 'fetch']);

        /*
        |--------------------------------------------------------------------------
        | Draft
        |--------------------------------------------------------------------------
        */

        Route::prefix('draft')->group(function () {
            Route::post('/add', [ProposalDraftController::class, 'createDraft']);
            Route::post('/update', [ProposalDraftController::class, 'updateDraft']);
        });

        /*
        |--------------------------------------------------------------------------
        | Documents
        |--------------------------------------------------------------------------
        */

        Route::prefix('upload')->group(function () {
            Route::post('/prepare', [ProposalDocumentController::class, 'prepareProposalUpload']);
            Route::post('/store', [ProposalDocumentController::class, 'uploadProposal']);
        });

        /*
        |--------------------------------------------------------------------------
        | Workflow
        |--------------------------------------------------------------------------
        */

        Route::post('/update', [ProposalWorkflowController::class, 'updateTahapProposal']);
        Route::post('/delete', [ProposalWorkflowController::class, 'tolakProposal']);

        /*
        |--------------------------------------------------------------------------
        | Pengumuman SK
        |--------------------------------------------------------------------------
        */

        Route::prefix('sk')->group(function () {
            Route::get('/fetch', [PengumumanSkController::class, 'fetch']);
            Route::post('/generate', [PengumumanSkController::class, 'generate']);
            Route::post('/upload', [PengumumanSkController::class, 'upload']);
        });
    });

    Route::prefix('laporan')->group(function (){
        Route::get('/', [LaporanController::class, 'index']);

        Route::post('/update', [LaporanController::class, 'update']);
        Route::post('/upload-dokumen', [LaporanController::class, 'uploadDokumen']);
        Route::post('/finish', [LaporanController::class, 'finish']);
        Route::post('/generate-laporan-akhir', [LaporanController::class, 'generateLaporanAkhir']);
        Route::post('/publikasi', [LaporanController::class, 'submitPublikasi']);
    });

    Route::prefix('diseminasi')->group(function (){
        Route::get('/', [DiseminasiController::class, 'index']);
        Route::post('/approve', [DiseminasiController::class, 'approve']);
    });

    /*
    |--------------------------------------------------------------------------
    | Claim Dana + Pengembalian Dana
    |--------------------------------------------------------------------------
    */

    Route::prefix('dana')->group(function () {
        Route::get('/', [DanaController::class, 'index']);

        Route::post('/claim/approve', [DanaController::class, 'approveClaim']);
        Route::post('/claim/upload-proof', [DanaController::class, 'uploadClaimProof']);
        Route::post('/claim/confirm', [DanaController::class, 'confirmClaim']);

        Route::post('/pengembalian/request', [DanaController::class, 'requestPengembalian']);
        Route::post('/pengembalian/upload-proof', [DanaController::class, 'uploadPengembalianProof']);
        Route::post('/pengembalian/confirm', [DanaController::class, 'confirmPengembalian']);
    });

    /*
    |--------------------------------------------------------------------------
    | Luaran (Sitasi)
    |--------------------------------------------------------------------------
    */

    Route::prefix('sitasi')->group(function () {
        Route::get('/', [SitasiController::class, 'index']);
        Route::post('/', [SitasiController::class, 'store']);
        Route::delete('/{id}', [SitasiController::class, 'destroy']);
    });

    Route::prefix('logbook_pengerjaan')->group(function () {
        Route::get('/', [LogbookPengerjaanController::class, 'index']);
        Route::get('/{id}', [LogbookPengerjaanController::class, 'show']);
        Route::post('/', [LogbookPengerjaanController::class, 'store']);
        Route::put('/{id}', [LogbookPengerjaanController::class, 'update']);
        Route::delete('/{id}', [LogbookPengerjaanController::class, 'destroy']);
    });

    Route::prefix('skema')->group(function () {
        Route::get('/', [SkemaController::class, 'index']);
        Route::post('/add', [SkemaController::class, 'store']);
        Route::post('/update', [SkemaController::class, 'update']);
        Route::post('/delete', [SkemaController::class, 'destroy']);
        Route::get('/fetch', [SkemaController::class, 'fetch']);
        Route::get('/fetch/all', [SkemaController::class, 'fetchAll']);
    });

    Route::prefix('periode')->group(function (){
        Route::get('/', [PeriodePengajuanController::class, 'index']);
        Route::get('/fetch', [PeriodePengajuanController::class, 'fetch']);
        Route::get('/fetch/all', [PeriodePengajuanController::class, 'fetchAll']);
        Route::get('/fetch-penerimaan-proposal', [PeriodePengajuanController::class, 'fetchPenerimaanProposal']);
        // Route::get('/search', [PeriodePengajuanController::class, 'search']);

        Route::post('/add', [PeriodePengajuanController::class, 'create']);
        Route::post('/update', [PeriodePengajuanController::class, 'update']);
        Route::delete('/delete/{id}', [PeriodePengajuanController::class, 'delete']);
    });

    Route::prefix('penugasan')->group(function (){
        Route::post('/assign', [PenugasanReviewerController::class, 'assignReviewers']);
        Route::post('/confirm-assignment', [PenugasanReviewerController::class, 'confirmAssignment']);
    });

    Route::prefix('review')->group(function (){
        Route::post('/upload', [ReviewController::class, 'store']);
        // Route::post('/', [PenugasanReviewerController::class, 'confirmAssignment']);
    });

    Route::prefix('settings')->group(function (){
        Route::get('/', [SettingsController::class, 'index']);
        Route::post('/update', [SettingsController::class, 'update']);
        Route::get('/fetch-rektorat', [SettingsController::class, 'fetchRektor']);
        Route::get('/fetch-lppm', [SettingsController::class, 'fetchTimLppm']);
    });

    Route::prefix('peneliti-detail')->group(function () {
        Route::get('/', [PenelitiDetailController::class, 'detail']);
        Route::post('/update', [PenelitiDetailController::class, 'update']);
    });

    Route::prefix('publication-category')->group(function () {
        Route::get('/fetch', [PublicationCategoryController::class, 'fetch']);

        Route::post('/add', [PublicationCategoryController::class, 'create']);
        Route::post('/update', [PublicationCategoryController::class, 'update']);

        Route::delete('/delete/{id}', [PublicationCategoryController::class, 'delete']);
    });
});
