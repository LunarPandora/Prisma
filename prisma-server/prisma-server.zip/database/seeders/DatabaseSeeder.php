<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Skema;
use App\Models\Prodi;
use App\Models\Dosen;
use App\Models\Reviewer;
use App\Models\TimLPPM;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        Prodi::create(['nama_prodi' => 'Sistem Teknologi dan Informasi']);
        Prodi::create(['nama_prodi' => 'Bisnis Digital']);
        Prodi::create(['nama_prodi' => 'Kewirausahaan']);

        User::create([
            'nama' => 'Admin',
            'email' => 'admin_lppm@itbss.ac.id',
            'email_verified_at' => now(),
            'password' => Hash::make('admin123'),
            'role' => 'Admin',
            'status' => 'Aktif',
            'gender' => 'L',
            'avatar' => null,
            'remember_token' => Str::random(10),
        ]);

        $d = User::create([
            'nama' => 'Dosen A',
            'email' => 'dosen.a@itbss.ac.id',
            'email_verified_at' => now(),
            'password' => Hash::make('dosen123'),
            'role' => 'Dosen',
            'status' => 'Aktif',
            'gender' => 'L',
            'nidn'     => '123456',
            'prodi_id' => 1,
            'avatar' => null,
            'remember_token' => Str::random(10),
        ]);

        $r1 = User::create([
            'nama' => 'Reviewer A',
            'email' => 'reviewer.a@itbss.ac.id',
            'email_verified_at' => now(),
            'password' => Hash::make('reviewer123'),
            'role' => 'Reviewer',
            'status' => 'Aktif',
            'gender' => 'L',
            'nidn'      => '1234',
            'avatar' => null,
            'remember_token' => Str::random(10),
        ]);

        $r2 = User::create([
            'nama' => 'Reviewer B',
            'email' => 'reviewer.b@itbss.ac.id',
            'email_verified_at' => now(),
            'password' => Hash::make('reviewer123'),
            'role'     => 'Reviewer',
            'status'   => 'Aktif',
            'gender'   => 'L',
            'nidn'     => '5678',
            'avatar'   => null,
            'remember_token' => Str::random(10),
        ]);

        $r3 = User::create([
            'nama' => 'Reviewer C',
            'email' => 'reviewer.c@itbss.ac.id',
            'email_verified_at' => now(),
            'password' => Hash::make('reviewer123'),
            'role'   => 'Reviewer',
            'status' => 'Aktif',
            'gender' => 'L',
            'nidn'   => '4321',
            'avatar' => null,
            'remember_token' => Str::random(10),
        ]);

        $lp = User::create([
            'nama' => 'LPPM 1',
            'email' => 'lppm@itbss.ac.id',
            'email_verified_at' => now(),
            'password' => Hash::make('lppm123'),
            'role' => 'Tim LPPM',
            'status' => 'Aktif',
            'gender' => 'L',
            'nidn'      => '1357',
            'avatar' => null,
            'remember_token' => Str::random(10),
        ]);
    }
}
