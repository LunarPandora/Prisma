"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX } from "@fortawesome/free-solid-svg-icons"

import TextInput from "@/app/component/Inputs/TextInput"
import Button from "@/app/component/Inputs/Button"

import {
    uploadClaimProof,
    uploadPengembalianProof,
} from "@/app/component/Libraries/api/dana"

/*
 * mode: "claim" | "pengembalian"
 */
export default function TransferProofForm({
    mode = "claim",
    close,
    refresh,
    laporan,

    alertMsg,
    alertStatus,
    alertTrigger,
}) {
    const [driveUrl, setDriveUrl] = useState("")
    const [loading, setLoading] = useState(false)

    const title = mode === "pengembalian"
        ? "Upload Bukti Transfer Pengembalian Dana"
        : "Upload Bukti Transfer Claim Dana"

    async function submit() {
        if (!driveUrl) {
            alertMsg("Link Google Drive wajib diisi.")
            alertStatus("error")
            alertTrigger()
            return
        }

        try {
            setLoading(true)

            const formData = new FormData()
            formData.append("laporan_id", laporan.laporan_id)
            formData.append("drive_file_url", driveUrl)

            const uploader = mode === "pengembalian"
                ? uploadPengembalianProof
                : uploadClaimProof

            const res = await uploader(formData)

            if (res.data.status === "success") {
                alertMsg("Bukti transfer berhasil diupload.")
                alertStatus("success")
                refresh()
                close()
            } else {
                alertMsg(res.data.message || "Gagal mengupload bukti transfer.")
                alertStatus("error")
            }
        } catch (err) {
            console.error(err)
            alertMsg("Gagal mengupload bukti transfer.")
            alertStatus("error")
        } finally {
            setLoading(false)
            alertTrigger()
        }
    }

    return (
        <motion.div
            className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
        >
            <motion.div
                className="w-1/2 bg-white p-5 rounded-xl flex flex-col gap-4"
                initial={{ scale: 1.05 }}
                animate={{ scale: 1 }}
            >
                <div className="flex justify-between">
                    <p className="text-lg font-medium">{title}</p>

                    <FontAwesomeIcon
                        icon={faX}
                        onClick={close}
                        className="cursor-pointer"
                    />
                </div>

                <p className="text-sm text-gray-500">
                    Silakan upload bukti transfer dalam bentuk file (PDF /
                    gambar) yang disimpan di Google Drive Anda, lalu
                    tempelkan link-nya di bawah.
                </p>

                <TextInput
                    placeholder="Link Google Drive bukti transfer"
                    value={driveUrl}
                    onChange={(e) => setDriveUrl(e.target.value)}
                />

                <div className="flex justify-end gap-2">
                    <Button variant="secondary" onClick={close}>
                        Batal
                    </Button>

                    <Button onClick={submit} disabled={loading}>
                        {loading ? "Mengupload..." : "Upload"}
                    </Button>
                </div>
            </motion.div>
        </motion.div>
    )
}
