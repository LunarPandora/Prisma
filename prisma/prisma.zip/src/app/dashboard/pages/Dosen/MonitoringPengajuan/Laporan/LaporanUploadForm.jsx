"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX } from "@fortawesome/free-solid-svg-icons"

import TextInput from "@/app/component/Inputs/TextInput"
import Button from "@/app/component/Inputs/Button"
import { uploadDokumenLaporan } from "@/app/component/Libraries/api/laporan"

export default function LaporanUploadForm({
    close,
    refresh,
    laporan,

    alertMsg,
    alertStatus,
    alertTrigger,
}) {
    const defaultForm = {
        laporan_id: laporan.laporan_id,
        drive_file_url: "",
        catatan_revisi: "",
    }

    const [form, setForm] = useState(defaultForm)
    const [loading, setLoading] = useState(false)

    const dokumenLaporan = (laporan.dokumen || []).find(
        (d) => d.jenis_dokumen === "Dokumen Laporan"
    )

    const handleChange = (e) => {
        setForm(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }))
    }

    const submit = async () => {
        try {
            setLoading(true)

            const formData = new FormData()
            Object.keys(form).forEach(k => formData.append(k, form[k]))

            const res = await uploadDokumenLaporan(formData)

            if (res.data.status === "success") {
                alertMsg("Dokumen laporan berhasil diupload.")
                alertStatus("success")

                refresh()
                close()
            } else {
                alertMsg(res.data.message || "Gagal mengupload dokumen laporan.")
                alertStatus("error")
            }

        } catch (err) {
            console.error(err)

            alertMsg("Gagal mengupload dokumen laporan.")
            alertStatus("error")
        } finally {
            setLoading(false)
            alertTrigger()
        }
    }

    return (
        <motion.div
            className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
        >
            <motion.div
                className="w-1/2 bg-white p-5 rounded-xl flex flex-col gap-4"
                initial={{ scale: 1.05 }}
                animate={{ scale: 1 }}
            >
                {/* HEADER */}
                <div className="flex justify-between">
                    <p className="text-lg font-medium">
                        Upload Revisi Dokumen Laporan
                    </p>

                    <FontAwesomeIcon
                        icon={faX}
                        onClick={close}
                        className="cursor-pointer"
                    />
                </div>

                {dokumenLaporan?.drive_file_url &&
                    <p className="text-sm text-gray-500">
                        Versi terakhir:{" "}
                        <a
                            href={dokumenLaporan.drive_file_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                        >
                            {dokumenLaporan.nama_file}
                        </a>
                    </p>
                }

                {/* FORM */}
                <div className="flex flex-col gap-2">
                    <TextInput
                        name="drive_file_url"
                        placeholder="Link Google Drive dokumen laporan"
                        value={form.drive_file_url}
                        onChange={handleChange}
                    />

                    <TextInput
                        name="catatan_revisi"
                        placeholder="Catatan revisi (opsional)"
                        value={form.catatan_revisi}
                        onChange={handleChange}
                    />
                </div>

                {/* ACTION */}
                <div className="flex justify-end gap-2">
                    <Button variant="secondary" onClick={close}>
                        Batal
                    </Button>

                    <Button onClick={submit} disabled={loading}>
                        Upload
                    </Button>
                </div>
            </motion.div>
        </motion.div>
    )
}
