"use client"

import { useState } from "react"
import { AnimatePresence } from "framer-motion"

import Alert from "@/app/component/Alert/Alert"
import ContextMenu from "@/app/component/Context/ContextMenu"

import { useUserStore } from "@/app/stores/useUserStore"
import { getModuleAccess } from "@/app/component/Libraries/utils/menu"

import { useContextMenu } from "@/app/component/Libraries/hooks/useContextMenu"

import CustomTable from "@/app/component/Table/CustomTable"

import Proposal from "./Proposal/page"
import Laporan from "./Laporan/page"
import SelectMonitoring from "./SelectMonitoring"
import { getSkema } from "@/app/component/Libraries/api/skema"
import { createMonitoringProgressDosenMenus } from "@/app/component/Libraries/config/MonitoringProgress/MonitoringProgressDosenMenu"

export default function DosenMonitoringPengajuan() {
    const [selectedSkema, setSelectedSkema] = useState(null)
    const [view, setView] = useState(null)

    if (selectedSkema && view === "proposal") {
        return (
            <Proposal
                skema={selectedSkema}
                onBack={() => setView(null)}
            />
        )
    }

    if (selectedSkema && view === "laporan") {
        return (
            <Laporan
                skema={selectedSkema}
                onBack={() => setView(null)}
            />
        )
    }

    if (selectedSkema) {
        return (
            <SelectMonitoring
                skema={selectedSkema}
                setView={setView}
                onBack={() => setSelectedSkema(null)}
            />
        )
    }

    return (
        <SkemaView
            onSelectSkema={(row) => setSelectedSkema(row)}
        />
    )
}

function SkemaView({ onSelectSkema }){
    const [refreshKey, setRefreshKey] = useState(0)

    const [showAlert, setShowAlert] = useState(false)
    const [alertMsg, setAlertMsg] = useState("")
    const [alertStatus, setAlertStatus] = useState("success")

    const [addSkemaModal, setAddSkemaModal] = useState(false)
    const [editSkemaModal, setEditSkemaModal] = useState(false)
    const [removeSkemaModal, setRemoveSkemaModal] = useState(false)

    const [tempRowData, setTempRowData] = useState({})
    const [loadingForm, setLoadingForm] = useState(false)

    const user = useUserStore(state => state.user)
    const access = getModuleAccess("dosenmonitoringprogress", user?.role)

    const { contextMenu, openMenu, closeMenu } = useContextMenu()

    const menus = createMonitoringProgressDosenMenus({
        access,
        refreshTable,
    })

    function refreshTable(){
        setRefreshKey(prev => prev + 1)
    }

    return (
        <div
            className="flex flex-col gap-5 min-h-screen"
            onContextMenu={(e) => openMenu(e)}
        >
            <div className="flex flex-col gap-5">

                <div className="flex flex-col gap-2">
                    <h1 className="text-4xl font-medium">
                        Monitoring Progress
                    </h1>

                    <p className="text-lg text-gray-500 font-light">
                        Pilih skema penelitian yang ingin di monitor
                    </p>
                </div>

                <CustomTable
                    fetchMethod={getSkema}
                    refreshKey={refreshKey}
                    className="w-full"
                    roundedStyle="rounded-lg rounded-tl-none"
                    onContextRequest={(e, type, data, source) =>
                        openMenu(e, type, data, source)
                    }
                    onRowClick={(row) => {
                        onSelectSkema(row)
                    }}
                    columns={[
                        {
                            header: "Nama Skema",
                            key: "nama_skema"
                        },
                        {
                            header: "Tahun Ajaran",
                            key: "tahun_ajaran"
                        },
                        {
                            header: "Jumlah Periode",
                            key: "periode_count",
                            render: (value, row) => {
                                return (
                                    <span>
                                        {row.periode?.length ?? 0} Periode
                                    </span>
                                )
                            }
                        },
                        {
                            header: "Status",
                            key: "status",
                            render: (value) => {

                                const style = {
                                    Draft:
                                        "text-yellow-600 bg-yellow-100 border-yellow-500",
                                    Aktif:
                                        "text-blue-600 bg-blue-100 border-blue-500",
                                    Selesai:
                                        "text-green-600 bg-green-100 border-green-500",
                                }

                                return (
                                    <span
                                        className={`
                                            ${style[value]}
                                            text-sm
                                            px-2 py-1
                                            border
                                            rounded
                                        `}
                                    >
                                        {value}
                                    </span>
                                )
                            }
                        }
                    ]}
                />
            </div>

            <AnimatePresence mode="wait">
                {
                    addSkemaModal &&
                    <FormSkema
                        refresh={refreshTable}
                        close={() => setAddSkemaModal(false)}
                        isEdit={false}
                        data={{}}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                }
            </AnimatePresence>

            <AnimatePresence mode="wait">
                {
                    editSkemaModal &&
                    <FormSkema
                        refresh={refreshTable}
                        close={() => setEditSkemaModal(false)}
                        isEdit={true}
                        data={tempRowData}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                }
            </AnimatePresence>

            <AnimatePresence mode="wait">
                {
                    removeSkemaModal &&
                    <Alert
                        alertType="warning"
                        title="Hapus Skema"
                        msg="Apakah anda yakin ingin menghapus skema ini?"
                        onCancel={() => setRemoveSkemaModal(false)}
                        onAccept={removeSkema}
                        acceptText="Hapus"
                        isConfirmation={true}
                        withBackground={true}
                    />
                }
            </AnimatePresence>

            {
                showAlert &&
                <Alert
                    msg={alertMsg}
                    onCancel={() => setShowAlert(false)}
                    alertType={alertStatus}
                />
            }

            <ContextMenu
                contextMenu={contextMenu}
                closeMenu={closeMenu}
                menus={menus}
            />
        </div>
    )
}