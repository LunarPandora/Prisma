"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX, faPlus } from "@fortawesome/free-solid-svg-icons"

import Button from "@/app/component/Inputs/Button"
import { getLogbook, addLogbook, deleteLogbook } from "@/app/component/Libraries/api/logbook"
import LogbookFormDosen from "./LogbookForm"

export default function LogbookViewDosen({
    close,
    data
}) {
    const [logbooks, setLogbooks] = useState([])
    const [loading, setLoading] = useState(false)
    const [refreshKey, setRefreshKey] = useState(0)
    const [showForm, setShowForm] = useState(false)

    const [showAddModal, setShowAddModal] = useState(false)

    const fetchLogbooks = async () => {
        try {
            setLoading(true)

            const res = await getLogbook(1, {
                laporan_id: data?.laporan_id,
            })

            setLogbooks(res.data?.data || [])
        } catch (err) {
            console.error(err)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        if (data?.laporan_id) {
            fetchLogbooks()
        }
    }, [data, refreshKey])

    return (
        <motion.div
            className="fixed inset-0 bg-black/40 flex items-center justify-center z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
        >
            <motion.div
                className="w-2/3 bg-white p-5 rounded-xl flex flex-col gap-5"
                initial={{ scale: 1.05, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 1.05, opacity: 0 }}
            >
                {/* HEADER */}
                <div className="flex justify-between items-center">
                    <p className="text-xl font-medium">Logbook Progress</p>

                    <FontAwesomeIcon
                        icon={faX}
                        onClick={() => close()}
                        className="cursor-pointer"
                    />
                </div>

                {/* ACTION */}
                <div className="flex justify-between items-center">
                    <p className="text-sm text-gray-500">
                        Laporan ID: {data.laporan_id}
                    </p>

                    <Button
                        icon={faPlus}
                        onClick={() => setShowAddModal(true)}
                    >
                        Tambah Logbook
                    </Button>
                </div>

                {/* TABLE */}
                <div className="flex flex-col gap-2">
                    <div className="flex justify-between items-center">
                        <p className="font-medium text-lg">Logbook Pengerjaan</p>

                        <Button onClick={() => setShowForm(true)}>
                            Tambah Logbook
                        </Button>
                    </div>

                    <div className="border rounded-lg overflow-hidden">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-100 text-left">
                                <tr>
                                    <th className="p-2">Judul</th>
                                    <th className="p-2">Tanggal</th>
                                    <th className="p-2">Deskripsi</th>
                                    <th className="p-2">Aksi</th>
                                </tr>
                            </thead>

                            <tbody>
                                {logbooks.length === 0 ? (
                                    <tr>
                                        <td colSpan={4} className="p-4 text-center text-gray-500">
                                            Belum ada logbook
                                        </td>
                                    </tr>
                                ) : (
                                    logbooks.map((item) => (
                                        <tr key={item.logbook_id} className="border-t">
                                            <td className="p-2 font-medium">{item.judul}</td>
                                            <td className="p-2">{item.tgl_kegiatan}</td>
                                            <td className="p-2 line-clamp-2">{item.deskripsi}</td>
                                            <td className="p-2">
                                                <button
                                                    className="text-red-500 text-sm"
                                                    onClick={async () => {
                                                        await deleteLogbook(item.logbook_id)
                                                        setRefreshKey(prev => prev + 1)
                                                    }}
                                                >
                                                    Hapus
                                                </button>
                                            </td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* STACKED MODAL */}
                <AnimatePresence>
                    {showForm && (
                        <LogbookFormDosen
                            laporan={data}
                            refresh={() => setRefreshKey(prev => prev + 1)}
                            close={() => setShowForm(false)}
                        />
                    )}
                </AnimatePresence>

            </motion.div>
        </motion.div>
    )
}