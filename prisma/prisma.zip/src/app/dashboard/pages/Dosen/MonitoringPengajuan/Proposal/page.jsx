import { useState } from "react";
import Image from "next/image";
import SelectInput from "@/app/component/Inputs/SelectInput";
import { faFile, faSearch, faSquarePollVertical } from "@fortawesome/free-solid-svg-icons";
import { useUserStore } from "@/app/stores/useUserStore";

import { getModuleAccess } from "@/app/component/Libraries/utils/menu";

import { deleteProposal, getProposal } from "@/app/component/Libraries/api/proposal";
import { fetchAllPeriode } from "@/app/component/Libraries/api/periode";
import { useQueryBuilder } from "@/app/component/Libraries/hooks/useQueryBuilder";

import CustomTable from "@/app/component/Table/CustomTable";
import { formatIndonesianDate } from "@/app/component/Libraries/utils/date";
import ContextMenu from "@/app/component/Context/ContextMenu";
import { motion, AnimatePresence } from "framer-motion";
import TextInput from "@/app/component/Inputs/TextInput";
import Button from "@/app/component/Inputs/Button";
import Alert from "@/app/component/Alert/Alert";
import { createProposalDosenMenus } from "@/app/component/Libraries/config/Proposal/proposalDosenMenu";
import { useContextMenu } from "@/app/component/Libraries/hooks/useContextMenu";
import LoadingBar from "@/app/component/AppLoader/LoadingBar";
import FormProposalViewDosen from "./ProposalViewForm";
import FormProposal from "./ProposalForm";
import FormProposalUpload from "./ProposalUploadForm";
import TextTag from "@/app/component/Tags/TextTag";


export default function MonitoringProgressProposal({ skema, onBack }){
    const defaultForm = {
        search: "",
        periode_id: "",
    }

    const qb = useQueryBuilder()
    const [qs, setqs] = useState('')

    const [form, setForm] = useState(defaultForm)
    const { contextMenu, openMenu, closeMenu } = useContextMenu()

    const [refreshKey, setRefreshKey] = useState(0)
    const [addProposalModal, setAddProposalModal] = useState(false)
    const [editProposalModal, setEditProposalModal] = useState(false)
    const [viewProposalModal, setViewProposalModal] = useState(false)
    const [removeProposalModal, setRemoveProposalModal] = useState(false)
    const [uploadProposalModal, setUploadProposalModal] = useState(false)
    const [tempRowData, setTempRowData] = useState({})

    const [showAlert, setShowAlert] = useState(false)
    const [alertMsg, setAlertMsg] = useState('')
    const [alertStatus, setAlertStatus] = useState('success')
    const [loadingForm, setLoadingForm] = useState(false)

    const user = useUserStore(state => state.user)
    const access = getModuleAccess("dosenmonitoringprogressproposal", user?.role)

    const statusStyles = {
        'menunggu proposal untuk diupload': 'text-blue-600 bg-blue-100 border-blue-500',
        'menunggu penugasan reviewer': 'text-blue-600 bg-blue-100 border-blue-500',
        'menunggu review': 'text-yellow-600 bg-yellow-100 border-yellow-500',
        'dalam pengerjaan': 'text-purple-600 bg-purple-100 border-purple-500',
        default: 'text-gray-600 bg-gray-100 border-gray-600'
    }

    const menus = createProposalDosenMenus({
        user,
        access,
        refreshTable,
        handleView,
        handleAddG,
        handleEditG,
        handleRemoveG,
        handleUpload,
    })

    function handleView(r){
        setViewProposalModal(true)
        setTempRowData(r)
    }

    function handleAddG(){
        setAddProposalModal(true)
    }

    function handleEditG(r){
        setEditProposalModal(true)
        setTempRowData(r)
    }

    function handleRemoveG(r){
        setRemoveProposalModal(true)
        setTempRowData(r)
    }
    
    function handleUpload(r){
        setUploadProposalModal(true)
        setTempRowData(r)
    }

    function refreshTable() {
        setRefreshKey(prev => prev + 1)
    }

    async function removeProposal(){
        try{
            setLoadingForm(true)

            const formData = new FormData()
            formData.append('proposal_id', tempRowData.proposal_id)
            const res = await deleteProposal(formData)

            setLoadingForm(false)

            if (res.data.status == 'success'){ 
                setAlertMsg('Sistem berhasil menghapus draft proposal anda!')
                setAlertStatus('success')
            }
            else {
                setAlertMsg('Sistem gagal menghapus draft proposal anda!')
                setAlertStatus('danger')
            }
        }
        catch(err){
            setAlertMsg('Sistem gagal menghapus draft proposal anda dikarenakan error di sistem!')
            setAlertStatus('danger')

            console.error(err)
        }
        finally{
            refreshTable()
            setRemoveProposalModal(false)
            setShowAlert(true)
        }
    }

    const handleChange = (e, type) => {
        const { name, value } = e.target
        setForm(prev => ({
            ...prev,
            [name]: value,
        }))

        if(type == 'search'){
            qb.setSearch(e.target.value)
        }
        else if(type == 'filter'){
            qb.addFilter(e.target.name, e.target.value)
        }
    }

    const handleSearch = () => {
        setqs(qb.toQueryString(form.search))
        refreshTable()
    }

    return (
        <div 
            className="flex flex-col gap-5 min-h-screen"
            onContextMenu={(e) => openMenu(e)}
        >
            <div className="flex flex-col justify-between items-start gap-5">
                <div className="flex items-center gap-2 text-sm text-gray-500">
                    <button
                        onClick={onBack}
                        className="hover:text-black"
                    >
                        Monitoring Progress
                    </button>
                    <span>›</span>
                    <span>{skema.nama_skema}</span>
                    <span>›</span>
                    <span className="font-medium text-black">
                        Monitoring Progress Proposal
                    </span>
                </div>

                <div className="flex flex-col gap-2">
                    <h1 className="text-4xl font-medium">Monitoring Pengajuan Proposal</h1>
                    <p className="text-lg text-gray-500 font-light">Cek progress pengajuan dan progress proposal anda disini.</p>
                </div>

                <div className="bg-white rounded-lg p-3 w-full flex items-end gap-2">
                    <div className="w-1/4">
                        <TextInput
                            name="search" 
                            type="text"
                            placeholder="Cari reviewer, judul penelitian, dsb..."
                            icon={faFile}
                            value={form.search}
                            onChange={(e) => handleChange(e, 'search')}
                        />
                    </div>
                </div>

                <CustomTable
                    fetchMethod={getProposal}
                    searchQuery={qb.toQueryString()}
                    refreshKey={refreshKey}
                    className="w-full"
                    roundedStyle="rounded-lg rounded-tl-none"
                    onContextRequest={(e, type, data, source) => openMenu(e, type, data, source)}
                    columns={[  
                        { 
                            header: "Rencana Judul",
                            key: "judul", 
                            width: "20%",
                            render: (value, row) => {
                                return (
                                    <div className="flex flex-col gap-1">
                                        <div className="flex items-center gap-2">
                                            <TextTag color="#C4161C" size="text-xs">Ganjil</TextTag>
                                            <div className="relative w-full">
                                                <p className="text-sm line-clamp-1 peer">{ row.rencana_judul_publikasi_gan }</p>

                                                <span className="absolute opacity-0 top-5 w-fit text-xs bg-white drop-shadow-sm border border-gray-300 px-2 py-1 rounded-lg z-10 transition-all duration-200 ease-in-out translate-y-8 peer-hover:opacity-100 peer-hover:translate-y-0">
                                                    <p className="w-full">{ row.rencana_judul_publikasi_gan }</p>
                                                </span>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <TextTag color="#0197CA" size="text-xs">Genap</TextTag>
                                            <div className="relative w-full">
                                                <p className="text-sm line-clamp-1 peer">{ row.rencana_judul_publikasi_gen }</p>

                                                <span className="absolute opacity-0 top-5 w-fit text-xs bg-white drop-shadow-sm border border-gray-300 px-2 py-1 rounded-lg z-10 transition-all duration-200 ease-in-out translate-y-8 peer-hover:opacity-100 peer-hover:translate-y-0">
                                                    <p className="w-full">{ row.rencana_judul_publikasi_gen }</p>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                )
                            }
                        },
                        { header: "Periode", key: "nama_periode" },
                        { 
                            header: "Tgl Pengajuan", 
                            key: "tgl_pengajuan", 
                            render: (value) => { 
                                return (value == null ? '-' : formatIndonesianDate(value))
                            } 
                        },
                        {
                            header: "Reviewer", 
                            key: "nama_reviewer",
                            width: "20%",
                            render: (value, row) => {
                                console.log(row)
                                if(row.penugasan.length > 0){
                                    return (
                                        <div className="grid grid-cols-2 gap-1">
                                            {
                                                row.penugasan.map((p, i) => (
                                                    <span className="relative" key={i}>
                                                        <div className="flex items-center gap-2 text-xs peer">
                                                            <Image
                                                                src={`${p.reviewer.avatar_url}`}
                                                                alt={p.reviewer.nama}
                                                                width={25}
                                                                height={25}
                                                                className="relative rounded-full peer"
                                                                unoptimized
                                                            />
                                                            <p className="peer truncate">{p.reviewer.nama}</p>
                                                        </div>
                                                        
                                                        <span className="absolute -top-7 bg-white shadow-lg opacity-0 peer-hover:opacity-100 rounded-md text-black text-xs px-2 py-1 transition-opacity duration-200 ease-in-out">{p.reviewer.nama}</span>
                                                    </span>
                                                ))
                                            }
                                        </div>
                                    )
                                }
                                else{
                                    return (
                                        <span className="text-sm italic text-gray-500">Belum ada reviewer yang ditugaskan.</span>
                                    )
                                }
                            }
                        },
                        { 
                            header: "Status", 
                            key: "status",
                            render: (value, row) => {
                                const isActive = value.toLowerCase()
                                const style = statusStyles[isActive] || statusStyles.default
        
                                return (
                                    <span className={`${style} text-sm px-2 py-1 border rounded`}>
                                        { value }
                                    </span>
                                )
                            }
                        },
                    ]}
                />
            </div>

            <AnimatePresence>
                {addProposalModal && (
                    <FormProposal
                        refresh={() => refreshTable()}
                        close={() => setAddProposalModal(false)}
                        isEdit={false}
                        skema={skema}
                        alertMsg={(msg) => setAlertMsg(msg)}
                        alertStatus={(stt) => setAlertStatus(stt)}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {editProposalModal && (
                    <FormProposal
                        refresh={() => refreshTable()}
                        close={() => setEditProposalModal(false)}
                        data={tempRowData}
                        isEdit={true}
                        alertMsg={(msg) => setAlertMsg(msg)}
                        alertStatus={(stt) => setAlertStatus(stt)}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {uploadProposalModal && (
                    <FormProposalUpload
                        refresh={() => refreshTable()}
                        close={() => setUploadProposalModal(false)}
                        data={tempRowData}
                        alertMsg={(msg) => setAlertMsg(msg)}
                        alertStatus={(stt) => setAlertStatus(stt)}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {viewProposalModal && (
                    <FormProposalViewDosen
                        close={() => setViewProposalModal(false)}
                        data={tempRowData}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence mode="wait">
                {removeProposalModal && (
                    <motion.div
                        key="removeModal"
                        initial={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
                        animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
                        exit={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
                        transition={{ duration: 0.2 }}
                        className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 will-change-auto"
                    >
                        {loadingForm ? 
                            (
                                <LoadingBar />
                            )
                            :
                            (
                                <Alert 
                                    alertType="warning"
                                    title="Hapus draft proposal"
                                    msg="Apakah anda yakin ingin menghapus draft proposal ini?" 
                                    onCancel={() => setRemoveProposalModal(false)} 
                                    onAccept={() => removeProposal()} 
                                    acceptText="Hapus"
                                    isConfirmation={true}
                                />
                            )
                        }
                    </motion.div>
                )}
            </AnimatePresence>

            { showAlert && 
                <Alert 
                    msg={alertMsg} 
                    onCancel={() => setShowAlert(false)} 
                    alertType={alertStatus}
                /> 
            }

            <ContextMenu
                contextMenu={contextMenu}
                closeMenu={closeMenu}
                menus={menus}
            />
        </div>
    )
}