"use client"

import Image from "next/image"
import { useState, useEffect, useRef } from "react"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX, faEdit, faSpinner } from '@fortawesome/free-solid-svg-icons'
import { AnimatePresence, motion } from "framer-motion"

import LoadingBar from "@/app/component/AppLoader/LoadingBar"

import { getGeneratedTemplate, uploadProposal } from "@/app/component/Libraries/api/proposal"
import { generatePDFPreview, getPDFPageCount, getFileMeta, isValidPDF, isPDFExceedSizeLimit, estimateReadingTime, getPDFMetadata } from "@/app/component/Libraries/utils/pdfPreview"

import { useUserStore } from "@/app/stores/useUserStore";
import Button from "@/app/component/Inputs/Button"

export default function FormProposalUpload({ refresh, close, data, alertMsg, alertStatus, alertTrigger }){
    const defaultForm = {
        generated_file_url: "", 
        local_file_url: "",
        
        uploaded_file: null,
    }

    const [form, setForm] = useState(defaultForm)
    const [preview, setPreview] = useState(null)
    const [fileMeta, setFileMeta] = useState(null)
    const [fileMetadata, setFileMetadata] = useState(null)
    const [estimateTime, setEstimateTime] = useState(null)
    const [pageCount, setPageCount] = useState(0)

    const [loadingForm, setLoadingForm] = useState(false)
    const [loadingFile, setLoadingFile] = useState(false)
    const [existingFile, setExistingFile] = useState(null)

    const user = useUserStore(state => state.user)
    const MotionLoadingBar = motion.create(LoadingBar);
    const fileInputRef = useRef(null);
    const imageSrc = preview || null

    useEffect(() => {
        if (data) {
            setForm(prev => ({
                ...prev,
                ...data,
            }))
        } else {
            setForm(defaultForm)
        }
    }, [data])

    const fetchData = async () => {
        const formData = new FormData()
        formData.append('proposal_id', data.proposal_id)
    
        const res = await getGeneratedTemplate(formData)

        if (res.data.status == 'success'){ 
            setForm(prev => ({
                ...prev,
                generated_file_url: res.data.data
            }))

            setLoadingForm(false)
        }
        else {
            alertMsg(`Sistem gagal mengambil dokumen halaman pengesahan dikarenakan error di sistem!`)
            alertStatus('danger')

            setLoadingForm(false)
            refresh()
            close()
            alertTrigger()

            console.error(err)
        }
    }

    const uploadData = async() => {
        try{
            setLoadingForm(true)

            const formData = new FormData()

            formData.append('proposal_id', data.proposal_id)
            formData.append('uploaded_file', form.uploaded_file)

            const res = await uploadProposal(formData)

            if (res.data.status == 'success'){ 
                alertMsg(`Sistem berhasil mengajukan proposal!`)
                alertStatus('success')
            }
            else {
                alertMsg(`Sistem gagal mengajukan proposal!`)
                alertStatus('danger')
            }
        }
        catch(err){
            alertMsg(`Sistem gagal mengajukan proposal dikarenakan error di sistem!`)
            alertStatus('danger')

            console.error(err)
        }
        finally{
            setTimeout(() => {
                setLoadingForm(false)
                refresh()
                close()
                alertTrigger()
            }, 300)
        }
    }

    const handleFileInput = async (e) => {
        setLoadingFile(true)

        const file = e.target.files[0]
        if (!file) return

        if (e.target.files.length > 1) {
            alert("Hanya 1 file yang diperbolehkan!");
            return;
        }

        if (!isValidPDF(file)) {
            alert("Hanya file PDF yang diperbolehkan!");
            return;
        }

        if (isPDFExceedSizeLimit(file)) {
            alert("File terlalu besar (max 10MB)");
            return;
        }

        setForm((prev) => ({
            ...prev,
            uploaded_file: file,
        }))
        setExistingFile(null)

        const meta = getFileMeta(file)
        setFileMeta(meta)

        const preview = await generatePDFPreview(file)
        setPreview(preview)

        const pages = await getPDFPageCount(file)
        setPageCount(pages)

        const estimate = await estimateReadingTime(file, pages)
        setEstimateTime(estimate)

        setLoadingFile(false)
    }

    useEffect(() => {
        fetchData()
    }, [data])

    return (
        <motion.div
            key="formModal"
            initial={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 will-change-auto"
        >
             <AnimatePresence mode="wait">
                { loadingForm ?
                    (
                        <MotionLoadingBar />
                    )
                    :
                    (
                        <motion.div
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="w-1/2 bg-white p-5 rounded-xl flex flex-col gap-5"
                        >
                            <div class="flex w-full justify-between items-center">
                                <p className="font-medium text-xl">Cek Proposal</p>
                                <FontAwesomeIcon onClick={() => close('this')} icon={faX} className="text-sm" />
                            </div>

                            <div
                                key="form_proposal"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.2 }}
                                className="flex flex-col gap-3"
                            >
                                <div className="flex flex-col gap-3">
                                    <div className="w-full grid grid-cols-2 gap-3 h-fit">
                                        <a href={form.generated_file_url} download className="bg-white hover:bg-foreground text-foreground/90 hover:text-white text-lg px-5 py-2 rounded-lg font-medium transition-colors duration-300 ease-in-out cursor-pointer border-2 border-foreground/80 flex items-center justify-center col-span-2">
                                            Download dokumen pengesahan dan uraian luaran publikasi
                                        </a> 

                                        {/* <InputFrame
                                            placeholder="Reviewer yang ditugaskan"
                                            icon={faUsers}
                                            className="col-span-2"
                                        >
                                            {
                                                form.penugasan.length > 0 ? 
                                                    (
                                                        form.penugasan.map((p, i) => ( 
                                                            <UserTag 
                                                                img={`${p.reviewer?.user?.avatar_url}`}
                                                                name={p.reviewer?.user?.nama}
                                                                readOnly={true}
                                                            />  
                                                        ))
                                                    )
                                                    :
                                                    (
                                                        <span className="text-sm italic text-gray-500">Belum ada reviewer yang ditugaskan.</span>
                                                    )
                                            }
                                        </InputFrame> */}
                                    </div>

                                    <div className="w-full flex items-center justify-center gap-2 border-2 border-gray-400 rounded-md p-4 border-dashed min-h-60 relative overflow-hidden">
                                        <input
                                            type="file"
                                            accept="application/pdf"
                                            ref={fileInputRef}
                                            onChange={handleFileInput}
                                            style={{ display: "none" }}
                                        />

                                        { (form.uploaded_file || existingFile) &&
                                            <div
                                                className="w-full h-full z-10 absolute inset-0 opacity-0 hover:opacity-100 bg-black/40 flex items-center justify-center hover:cursor-pointer transition-opacity duration-200 ease-in-out" 
                                                onClick={() => fileInputRef.current.click()}
                                            >
                                                <FontAwesomeIcon icon={faEdit} className="text-white text-2xl" />
                                            </div>
                                        }
                                        { (form.uploaded_file || existingFile) && 
                                            <div className="flex w-full">
                                                <AnimatePresence mode="wait">
                                                    {loadingFile ? 
                                                        <motion.div
                                                            key="loading"
                                                            initial={{ opacity: 0 }}
                                                            animate={{ opacity: 1 }}
                                                            exit={{ opacity: 0 }}
                                                            transition={{ duration: 0.2 }}
                                                            className="flex w-full items-center justify-center gap-3"
                                                        >
                                                            <FontAwesomeIcon icon={faSpinner} className="text-3xl text-gray-600 animate-spin" />
                                                        </motion.div>
                                                    :
                                                        <motion.div 
                                                            key="file"
                                                            initial={{ opacity: 0 }}
                                                            animate={{ opacity: 1 }}
                                                            exit={{ opacity: 0 }}
                                                            transition={{ duration: 0.2 }}
                                                            className="flex w-full items-center justify-center gap-3"
                                                        >
                                                            <Image
                                                                src={imageSrc}
                                                                alt="avatar"
                                                                width={200}
                                                                height={200}
                                                                className="relative object-cover object-center border border-gray-200"
                                                                unoptimized
                                                            />

                                                            <div className="flex flex-col w-full">
                                                                <p className="font-semibold text-2xl line-clamp-2 pb-1 w-90">{fileMeta.name}</p>
                                                                <table border="0" className="w-fit">
                                                                    <tbody>
                                                                        <tr className="font-normal text-sm">
                                                                            <td><p>Ukuran file</p></td>
                                                                            <td><p className="px-2">:</p></td>
                                                                            <td><p>{fileMeta.formattedSize}</p></td>
                                                                        </tr>
                                                                        <tr className="font-normal text-sm">
                                                                            <td><p>Terakhir kali diedit</p></td>
                                                                            <td><p className="px-2">:</p></td>
                                                                            <td><p>{fileMeta.formattedDate}</p></td>
                                                                        </tr>
                                                                        <tr className="font-normal text-sm">
                                                                            <td><p>Jumlah halaman</p></td>
                                                                            <td><p className="px-2">:</p></td>
                                                                            <td><p>{pageCount} halaman</p></td>
                                                                        </tr>
                                                                        <tr className="font-normal text-sm">
                                                                            <td><p>Perkiraan lama baca</p></td>
                                                                            <td><p className="px-2">:</p></td>
                                                                            <td><p>{estimateTime?.label || "Menghitung..."}</p></td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </motion.div>
                                                    }
                                                </AnimatePresence>
                                            </div>
                                        }
                                        { !(form.uploaded_file || existingFile) ? 
                                            <span 
                                                className="underline decoration-dotted underline-offset-3 hover:cursor-pointer hover:text-primary text-center"
                                                onClick={() => fileInputRef.current.click()}
                                            >
                                                Upload dokumen proposal anda disini<br />
                                                Maks. 10MB
                                            </span>
                                        :
                                            <>
                                            </>
                                        }
                                    </div>
                                </div>

                                <div className="w-full grid grid-cols-2 gap-2">
                                    <Button fontSize="text-lg" onClick={close} variant="secondary">
                                        Kembali
                                    </Button>

                                    <Button onClick={() => uploadData()}>
                                        Ajukan Proposal
                                    </Button> 
                                </div>
                            </div>
                        </motion.div>
                    )
                }
            </AnimatePresence>
        </motion.div>
    )
}