"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import {
    faDownload,
    faFileWord,
    faSpinner,
    faX,
} from "@fortawesome/free-solid-svg-icons"

import TextInput from "@/app/component/Inputs/TextInput"
import Button from "@/app/component/Inputs/Button"

import {
    updateLaporan,
    generateLaporanAkhir,
    submitPublikasi,
} from "@/app/component/Libraries/api/laporan"

export default function PublikasiForm({
    close,
    refresh,
    laporan,

    alertMsg,
    alertStatus,
    alertTrigger,
}) {
    const detail = laporan.detail || {}

    const isPenelitian =
        laporan.proposal?.jenis_penelitian !== "PkM"

    const defaultInfo = {
        judul_penelitian: detail.judul_penelitian || "",
        metode_penelitian: detail.metode_penelitian || "",
        unit_analisis: detail.unit_analisis || "",
        target_publikasi: detail.target_publikasi || "",
        institusi_mitra: detail.institusi_mitra || "",

        realisasi_data_collection: detail.realisasi_data_collection || 0,
        realisasi_biaya_publikasi: detail.realisasi_biaya_publikasi || 0,
        realisasi_insentif: detail.realisasi_insentif || 0,
    }

    const defaultLinks = {
        link_laporan_akhir: detail.link_laporan_akhir || "",
        link_publikasi: detail.link_publikasi || "",
        link_hki: detail.link_hki || "",
        link_buku: detail.link_buku || "",
        link_poster: detail.link_poster || "",
        link_video: detail.link_video || "",
    }

    const [info, setInfo] = useState(defaultInfo)
    const [links, setLinks] = useState(defaultLinks)

    const [danaDikembalikan, setDanaDikembalikan] = useState(
        !!detail.dana_dikembalikan
    )

    const [generated, setGenerated] = useState(
        (laporan.dokumen || []).find(
            (d) => d.jenis_dokumen === "Laporan Akhir"
        ) || null
    )

    const [loadingInfo, setLoadingInfo] = useState(false)
    const [loadingGenerate, setLoadingGenerate] = useState(false)
    const [loadingSubmit, setLoadingSubmit] = useState(false)

    const handleInfoChange = (e) => {
        setInfo(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }))
    }

    const handleLinkChange = (e) => {
        setLinks(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }))
    }

    function showAlert(msg, status) {
        alertMsg(msg)
        alertStatus(status)
        alertTrigger()
    }

    /*
    |--------------------------------------------------------------------------
    | Save research info (title, data may change)
    |--------------------------------------------------------------------------
    */

    async function saveInfo() {
        try {
            setLoadingInfo(true)

            const formData = new FormData()
            formData.append("laporan_id", laporan.laporan_id)
            Object.keys(info).forEach(k => formData.append(k, info[k]))

            const res = await updateLaporan(formData)

            if (res.data.status === "success") {
                showAlert("Informasi penelitian berhasil disimpan.", "success")
                refresh()
            } else {
                showAlert(res.data.message || "Gagal menyimpan informasi.", "error")
            }
        }
        catch (err) {
            console.error(err)
            showAlert("Gagal menyimpan informasi.", "error")
        }
        finally {
            setLoadingInfo(false)
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Generate Laporan Akhir
    |--------------------------------------------------------------------------
    */

    async function handleGenerate() {
        try {
            setLoadingGenerate(true)

            const formData = new FormData()
            formData.append("laporan_id", laporan.laporan_id)

            const res = await generateLaporanAkhir(formData)

            if (res.data.status === "success") {
                setGenerated(res.data.data)
                showAlert("Laporan akhir berhasil digenerate.", "success")
                refresh()
            } else {
                showAlert(res.data.message || "Gagal generate laporan akhir.", "error")
            }
        }
        catch (err) {
            console.error(err)
            showAlert("Gagal generate laporan akhir.", "error")
        }
        finally {
            setLoadingGenerate(false)
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Submit publikasi
    |--------------------------------------------------------------------------
    */

    async function handleSubmit() {
        if (!links.link_laporan_akhir) {
            showAlert("Link laporan akhir wajib diisi.", "error")
            return
        }

        if (isPenelitian && !links.link_publikasi) {
            showAlert("Link publikasi wajib diisi untuk Penelitian.", "error")
            return
        }

        try {
            setLoadingSubmit(true)

            const formData = new FormData()
            formData.append("laporan_id", laporan.laporan_id)
            Object.keys(links).forEach(k => formData.append(k, links[k]))
            formData.append("dana_dikembalikan", danaDikembalikan ? 1 : 0)

            const res = await submitPublikasi(formData)

            if (res.data.status === "success") {
                showAlert("Publikasi berhasil disubmit.", "success")

                refresh()
                close()
            } else {
                showAlert(res.data.message || "Gagal submit publikasi.", "error")
            }
        }
        catch (err) {
            console.error(err)
            showAlert("Gagal submit publikasi.", "error")
        }
        finally {
            setLoadingSubmit(false)
        }
    }

    return (
        <motion.div
            className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
        >
            <motion.div
                className="w-2/3 max-h-[90vh] overflow-y-auto bg-white p-5 rounded-xl flex flex-col gap-4"
                initial={{ scale: 1.05 }}
                animate={{ scale: 1 }}
            >
                {/* HEADER */}
                <div className="flex justify-between">
                    <div className="flex flex-col">
                        <p className="text-lg font-medium">
                            Publikasi — Semester {laporan.semester}
                        </p>

                        <p className="text-sm text-gray-500">
                            Perbarui informasi penelitian, generate laporan
                            akhir, lalu upload luaran (link Google Drive).
                        </p>
                    </div>

                    <FontAwesomeIcon
                        icon={faX}
                        onClick={close}
                        className="cursor-pointer"
                    />
                </div>

                {/* INFORMASI PENELITIAN */}
                <div className="flex flex-col gap-2 border rounded-lg p-4">
                    <span className="text-gray-600 font-medium">
                        Informasi Penelitian
                    </span>

                    <TextInput
                        name="judul_penelitian"
                        placeholder="Judul Penelitian"
                        value={info.judul_penelitian}
                        onChange={handleInfoChange}
                    />

                    <div className="grid grid-cols-2 gap-2">
                        <TextInput
                            name="metode_penelitian"
                            placeholder="Metodologi Penelitian"
                            value={info.metode_penelitian}
                            onChange={handleInfoChange}
                        />

                        <TextInput
                            name="unit_analisis"
                            placeholder="Unit Analisis"
                            value={info.unit_analisis}
                            onChange={handleInfoChange}
                        />

                        <TextInput
                            name="target_publikasi"
                            placeholder="Target Publikasi"
                            value={info.target_publikasi}
                            onChange={handleInfoChange}
                        />

                        <TextInput
                            name="institusi_mitra"
                            placeholder="Institusi Mitra"
                            value={info.institusi_mitra}
                            onChange={handleInfoChange}
                        />
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                        <TextInput
                            name="realisasi_data_collection"
                            type="number"
                            placeholder="Realisasi Data Collection"
                            value={info.realisasi_data_collection}
                            onChange={handleInfoChange}
                        />

                        <TextInput
                            name="realisasi_biaya_publikasi"
                            type="number"
                            placeholder="Realisasi Biaya Publikasi"
                            value={info.realisasi_biaya_publikasi}
                            onChange={handleInfoChange}
                        />

                        <TextInput
                            name="realisasi_insentif"
                            type="number"
                            placeholder="Realisasi Insentif"
                            value={info.realisasi_insentif}
                            onChange={handleInfoChange}
                        />
                    </div>

                    <div className="flex justify-end">
                        <Button onClick={saveInfo} disabled={loadingInfo}>
                            {loadingInfo ? "Menyimpan..." : "Simpan Informasi"}
                        </Button>
                    </div>
                </div>

                {/* GENERATE LAPORAN AKHIR */}
                <div className="flex flex-col gap-2 border rounded-lg p-4">
                    <span className="text-gray-600 font-medium">
                        Laporan Akhir
                    </span>

                    <div className="flex flex-wrap items-center gap-3">
                        <Button
                            onClick={handleGenerate}
                            disabled={loadingGenerate}
                        >
                            <FontAwesomeIcon
                                icon={loadingGenerate ? faSpinner : faFileWord}
                                className={`mr-2 ${loadingGenerate ? "animate-spin" : ""}`}
                            />
                            Generate Laporan Akhir
                        </Button>

                        {generated?.file_url &&
                            <a
                                href={generated.file_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-2 text-sm text-blue-600 hover:underline"
                            >
                                <FontAwesomeIcon icon={faDownload} />
                                {generated.nama_file}
                            </a>
                        }
                    </div>
                </div>

                {/* LUARAN */}
                <div className="flex flex-col gap-2 border rounded-lg p-4">
                    <span className="text-gray-600 font-medium">
                        Upload Luaran (Link Google Drive)
                    </span>

                    <TextInput
                        name="link_laporan_akhir"
                        placeholder="Link Laporan Akhir (wajib)"
                        value={links.link_laporan_akhir}
                        onChange={handleLinkChange}
                    />

                    <TextInput
                        name="link_publikasi"
                        placeholder={
                            isPenelitian
                                ? "Link Publikasi (wajib)"
                                : "Link Publikasi (opsional)"
                        }
                        value={links.link_publikasi}
                        onChange={handleLinkChange}
                    />

                    <div className="grid grid-cols-2 gap-2">
                        <TextInput
                            name="link_hki"
                            placeholder="Link HKI (opsional)"
                            value={links.link_hki}
                            onChange={handleLinkChange}
                        />

                        <TextInput
                            name="link_buku"
                            placeholder="Link Buku (opsional)"
                            value={links.link_buku}
                            onChange={handleLinkChange}
                        />

                        <TextInput
                            name="link_poster"
                            placeholder="Link Poster (opsional)"
                            value={links.link_poster}
                            onChange={handleLinkChange}
                        />

                        <TextInput
                            name="link_video"
                            placeholder="Link Video (opsional)"
                            value={links.link_video}
                            onChange={handleLinkChange}
                        />
                    </div>

                    <label className="flex items-center gap-2 text-sm cursor-pointer mt-1">
                        <input
                            type="checkbox"
                            checked={danaDikembalikan}
                            onChange={(e) =>
                                setDanaDikembalikan(e.target.checked)
                            }
                        />
                        Apakah ada dana yang harus dikembalikan?
                    </label>
                </div>

                {/* ACTION */}
                <div className="flex justify-end gap-2">
                    <Button variant="secondary" onClick={close}>
                        Batal
                    </Button>

                    <Button onClick={handleSubmit} disabled={loadingSubmit}>
                        {loadingSubmit ? "Mengirim..." : "Submit Publikasi"}
                    </Button>
                </div>
            </motion.div>
        </motion.div>
    )
}
