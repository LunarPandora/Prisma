import { useState } from "react";
import Image from "next/image";
import SelectInput from "@/app/component/Inputs/SelectInput";
import { faFile, faSearch, faSquarePollVertical } from "@fortawesome/free-solid-svg-icons";
import { useUserStore } from "@/app/stores/useUserStore";

import { getModuleAccess } from "@/app/component/Libraries/utils/menu";

// import { fetchAllPeriode } from "@/app/component/Libraries/api/periode";
import { useQueryBuilder } from "@/app/component/Libraries/hooks/useQueryBuilder";

import CustomTable from "@/app/component/Table/CustomTable";
import { formatIndonesianDate } from "@/app/component/Libraries/utils/date";
import ContextMenu from "@/app/component/Context/ContextMenu";
import { motion, AnimatePresence } from "framer-motion";
import TextInput from "@/app/component/Inputs/TextInput";
import Button from "@/app/component/Inputs/Button";
import Alert from "@/app/component/Alert/Alert";
import { createProposalDosenMenus } from "@/app/component/Libraries/config/Proposal/proposalDosenMenu";
import { useContextMenu } from "@/app/component/Libraries/hooks/useContextMenu";
import { getLaporan, finishLaporan } from "@/app/component/Libraries/api/laporan";
import TextTag from "@/app/component/Tags/TextTag";
import { createLaporanDosenMenus } from "@/app/component/Libraries/config/Laporan/LaporanDosenMenu";
import LogbookViewDosen from "./LogbookView";
import LaporanUploadForm from "./LaporanUploadForm";
import PublikasiForm from "./PublikasiForm";
import TransferProofForm from "./TransferProofForm";
import SitasiForm from "./SitasiForm";

export default function MonitoringPenelitianLaporan({ skema, onBack }){
    const defaultForm = {
        // search: "",
        // periode_id: "",
    }

    const qb = useQueryBuilder()
    const [qs, setqs] = useState('')

    const [form, setForm] = useState(defaultForm)
    const { contextMenu, openMenu, closeMenu } = useContextMenu()

    const [refreshKey, setRefreshKey] = useState(0)
    const [tempLaporan, setTempLaporan] = useState({})

    const [showLogbookModal, setShowLogbookModal] = useState(false)
    const [showAddLogbookModal, setShowAddLogbookModal] = useState(false)

    const [showUploadModal, setShowUploadModal] = useState(false)
    const [showFinishModal, setShowFinishModal] = useState(false)
    const [showPublikasiModal, setShowPublikasiModal] = useState(false)

    const [showClaimProofModal, setShowClaimProofModal] = useState(false)
    const [showPengembalianProofModal, setShowPengembalianProofModal] = useState(false)
    const [showSitasiModal, setShowSitasiModal] = useState(false)

    const [tempRowData, setTempRowData] = useState({})

    const [showAlert, setShowAlert] = useState(false)
    const [alertMsg, setAlertMsg] = useState('')
    const [alertStatus, setAlertStatus] = useState('success')
    const [loadingForm, setLoadingForm] = useState(false)

    const user = useUserStore(state => state.user)
    const access = getModuleAccess("dosenmonitoringprogresslaporan", user?.role)

    const statusStyles = {
        'menunggu proposal untuk diupload': 'text-blue-600 bg-blue-100 border-blue-500',
        'menunggu penugasan reviewer': 'text-blue-600 bg-blue-100 border-blue-500',
        'menunggu review': 'text-yellow-600 bg-yellow-100 border-yellow-500',
        'dalam pengerjaan': 'text-purple-600 bg-purple-100 border-purple-500',
        default: 'text-gray-600 bg-gray-100 border-gray-600'
    }

    const menus = createLaporanDosenMenus({
        user,
        access,
        refreshTable,
        handleViewLogbook,
        handleUploadDokumen,
        handleFinish,
        handlePublikasi,
        handleUploadClaimProof,
        handleUploadPengembalianProof,
        handleSitasi,
    })

    function handleViewLogbook(r){
        setTempLaporan(r)
        setShowLogbookModal(true)
    }

    function handleUploadDokumen(r){
        setTempLaporan(r)
        setShowUploadModal(true)
    }

    function handleFinish(r){
        const prosesKodes = [
            "PROSES_PENELITIAN_GANJIL", "PROSES_PENELITIAN_GENAP",
            "PROSES_PKM_GANJIL", "PROSES_PKM_GENAP",
        ]

        if (!prosesKodes.includes(r.kode_periode)) {
            setAlertMsg("Laporan sedang bukan pada tahap Proses.")
            setAlertStatus("error")
            setShowAlert(true)
            return
        }

        setTempLaporan(r)
        setShowFinishModal(true)
    }

    function handlePublikasi(r){
        if (!["PUBLIKASI_GANJIL", "PUBLIKASI_GENAP"].includes(r.kode_periode)) {
            setAlertMsg("Laporan belum memasuki tahap Publikasi.")
            setAlertStatus("error")
            setShowAlert(true)
            return
        }

        setTempLaporan(r)
        setShowPublikasiModal(true)
    }

    function handleUploadClaimProof(r){
        setTempLaporan(r)
        setShowClaimProofModal(true)
    }

    function handleUploadPengembalianProof(r){
        setTempLaporan(r)
        setShowPengembalianProofModal(true)
    }

    function handleSitasi(r){
        setTempLaporan(r)
        setShowSitasiModal(true)
    }

    async function confirmFinish(){
        try {
            const formData = new FormData()
            formData.append("laporan_id", tempLaporan.laporan_id)

            const res = await finishLaporan(formData)

            if (res.data.status === "success") {
                setAlertMsg("Laporan selesai. Tahap Publikasi telah dimulai.")
                setAlertStatus("success")
            } else {
                setAlertMsg(res.data.message || "Gagal menyelesaikan laporan.")
                setAlertStatus("error")
            }
        }
        catch (err) {
            console.error(err)

            setAlertMsg("Gagal menyelesaikan laporan.")
            setAlertStatus("error")
        }
        finally {
            setShowFinishModal(false)
            setShowAlert(true)
            refreshTable()
        }
    }

    function refreshTable() {
        setRefreshKey(prev => prev + 1)
    }

    // const handleChange = (e, type) => {
    //     const { name, value } = e.target
    //     // setForm(prev => ({
    //     //     ...prev,
    //     //     [name]: value,
    //     // }))

    //     // if(type == 'search'){
    //     //     qb.setSearch(e.target.value)
    //     // }
    //     // else if(type == 'filter'){
    //     //     qb.addFilter(e.target.name, e.target.value)
    //     // }
    // }

    // const handleSearch = () => {
    //     setqs(qb.toQueryString(form.search))
    //     refreshTable()
    // }

    return (
        <div 
            className="flex flex-col gap-5 min-h-screen"
            onContextMenu={(e) => openMenu(e)}
        >
            <div className="flex flex-col justify-between items-start gap-5">
                <div className="flex items-center gap-2 text-sm text-gray-500">
                    <button
                        onClick={onBack}
                        className="hover:text-black"
                    >
                        Monitoring Progress
                    </button>
                    <span>›</span>
                    <span>{skema.nama_skema}</span>
                    <span>›</span>
                    <span className="font-medium text-black">
                        Monitoring Progress Laporan
                    </span>
                </div>

                <div className="flex flex-col gap-2">
                    <h1 className="text-4xl font-medium">Monitoring Progress Laporan</h1>
                    <p className="text-lg text-gray-500 font-light">Cek dan lacak progress pengerjaan laporan anda disini.</p>
                </div>

                {/* <div className="bg-white rounded-lg p-3 w-full flex items-end gap-2">
                    <div className="w-1/4">
                        <TextInput
                            name="search" 
                            type="text"
                            placeholder="Cari judul penelitian, dsb..."
                            icon={faFile}
                            value={form.search}
                            onChange={(e) => handleChange(e, 'search')}
                        />
                    </div>

                    <div className="w-1/4">
                        <SelectInput
                            name="periode_id"
                            value={form.periode_id}
                            onChange={(e) => handleChange(e, 'filter')}
                            dataSource={fetchAllPeriode}
                            transform={(item) => ({
                                text: item.nama_periode,
                                value: item.periode_id
                            })}
                            icon={faSquarePollVertical}
                            placeholder="Pilih periode penelitian"
                        />
                    </div>
                    <div className="w-1/4">
                        <Button icon={faSearch} onClick={handleSearch} className="!p-4" />
                    </div>
                </div> */}

                <CustomTable
                    fetchMethod={getLaporan}
                    searchQuery={qb.toQueryString()}
                    refreshKey={refreshKey}
                    className="w-full"
                    roundedStyle="rounded-lg rounded-tl-none"
                    onContextRequest={(e, type, data, source) => openMenu(e, type, data, source)}
                    columns={[  
                        { 
                            header: "Judul",
                            key: "judul", 
                            width: "20%",
                            render: (value, row) => {
                                return (
                                    <div className="flex flex-col gap-1">
                                        <div className="flex items-center gap-2">
                                            <TextTag color={`${row.semester == 'Ganjil' ? '#C4161C' : '#0197CA'}`} size="text-xs">{ row.semester }</TextTag>
                                            <div className="relative w-full">
                                                <p className="text-sm line-clamp-1 peer">{ row.judul }</p>

                                                <span className="absolute opacity-0 top-5 w-fit text-xs bg-white drop-shadow-sm border border-gray-300 px-2 py-1 rounded-lg z-10 transition-all duration-200 ease-in-out translate-y-8 peer-hover:opacity-100 peer-hover:translate-y-0">
                                                    <p className="w-full">{ row.judul }</p>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                )
                            }
                        },
                        { header: "Periode", key: "nama_periode" },
                        {
                            header: "Tahap",
                            key: "kode_periode",
                            render: (value) => {

                                if (!value) {
                                    return <span className="text-sm italic text-gray-500">-</span>
                                }

                                const label = ({
                                    "PROSES_PENELITIAN_GANJIL": "Proses",
                                    "PROSES_PENELITIAN_GENAP": "Proses",
                                    "PROSES_PKM_GANJIL": "Proses",
                                    "PROSES_PKM_GENAP": "Proses",
                                    "PUBLIKASI_GANJIL": "Publikasi",
                                    "PUBLIKASI_GENAP": "Publikasi",
                                    "DISEMINASI_GANJIL": "Diseminasi",
                                    "DISEMINASI_GENAP": "Diseminasi",
                                    "CLAIM_DANA_GANJIL": "Claim Dana",
                                    "CLAIM_DANA_GENAP": "Claim Dana",
                                    "PENGEMBALIAN_DANA_GANJIL": "Pengembalian Dana",
                                    "PENGEMBALIAN_DANA_GENAP": "Pengembalian Dana",
                                    "LUARAN_PENELITIAN": "Luaran",
                                    "LUARAN_PKM": "Luaran",
                                })[value] || value

                                const style = ({
                                    "Proses": "text-purple-600 bg-purple-100 border-purple-500",
                                    "Publikasi": "text-blue-600 bg-blue-100 border-blue-500",
                                    "Diseminasi": "text-yellow-600 bg-yellow-100 border-yellow-500",
                                    "Claim Dana": "text-emerald-600 bg-emerald-100 border-emerald-500",
                                    "Pengembalian Dana": "text-orange-600 bg-orange-100 border-orange-500",
                                    "Luaran": "text-green-600 bg-green-100 border-green-500",
                                })[label] || "text-gray-600 bg-gray-100 border-gray-600"

                                return (
                                    <span className={`${style} text-sm px-2 py-1 border rounded`}>
                                        {label}
                                    </span>
                                )
                            }
                        },
                        { 
                            header: "Tgl mulai", 
                            key: "tgl_mulai", 
                            render: (value, row) => { 
                                return (row.progress.tgl_mulai == null ? '-' : formatIndonesianDate(row.progress.tgl_mulai))
                            } 
                        },
                        { 
                            header: "Tgl submit", 
                            key: "tgl_submit", 
                            render: (value, row) => { 
                                return (row.progress.tgl_submit == null ? '-' : formatIndonesianDate(row.progress.tgl_submit))
                            } 
                        },
                        { 
                            header: "Tgl selesai", 
                            key: "tgl_selesai", 
                            render: (value, row) => { 
                                return (row.progress.tgl_selesai == null ? '-' : formatIndonesianDate(row.progress.tgl_selesai))
                            } 
                        },
                        {
                            header: "Reviewer", 
                            key: "nama_reviewer",
                            width: "20%",
                            render: (value, row) => {
                                console.log(row)
                                if(row.members.length > 0){
                                    return (
                                        <div className="grid grid-cols-2 gap-1">
                                            {
                                                row.members.map((p, i) => (
                                                    <span className="relative" key={i}>
                                                        <div className="flex items-center gap-2 text-xs peer">
                                                            <Image
                                                                src={`${p.avatar}`}
                                                                alt={p.nama}
                                                                width={25}
                                                                height={25}
                                                                className="relative rounded-full peer"
                                                                unoptimized
                                                            />
                                                            <p className="peer truncate">{p.nama}</p>
                                                        </div>
                                                        
                                                        <span className="absolute -top-7 bg-white shadow-lg opacity-0 peer-hover:opacity-100 rounded-md text-black text-xs px-2 py-1 transition-opacity duration-200 ease-in-out">{p.nama}</span>
                                                    </span>
                                                ))
                                            }
                                        </div>
                                    )
                                }
                                else{
                                    return (
                                        <span className="text-sm italic text-gray-500">Tidak ada anggota.</span>
                                    )
                                }
                            }
                        },
                        // { 
                        //     header: "Status", 
                        //     key: "status",
                        //     render: (value, row) => {
                        //         const isActive = value.toLowerCase()
                        //         const style = statusStyles[isActive] || statusStyles.default
        
                        //         return (
                        //             <span className={`${style} text-sm px-2 py-1 border rounded`}>
                        //                 { value }
                        //             </span>
                        //         )
                        //     }
                        // },
                    ]}
                />
            </div>

            <AnimatePresence>
                {showLogbookModal && (
                    <LogbookViewDosen
                        close={() => setShowLogbookModal(false)}
                        data={tempLaporan}
                        refresh={refreshTable}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {showUploadModal && (
                    <LaporanUploadForm
                        close={() => setShowUploadModal(false)}
                        laporan={tempLaporan}
                        refresh={refreshTable}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {showPublikasiModal && (
                    <PublikasiForm
                        close={() => setShowPublikasiModal(false)}
                        laporan={tempLaporan}
                        refresh={refreshTable}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {showFinishModal && (
                    <Alert
                        alertType="warning"
                        title="Selesaikan Laporan"
                        msg="Apakah anda yakin ingin menyelesaikan laporan ini? Laporan akan memasuki tahap Publikasi."
                        onCancel={() => setShowFinishModal(false)}
                        onAccept={confirmFinish}
                        acceptText="Selesaikan"
                        isConfirmation={true}
                        withBackground={true}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {showClaimProofModal && (
                    <TransferProofForm
                        mode="claim"
                        close={() => setShowClaimProofModal(false)}
                        laporan={tempLaporan}
                        refresh={refreshTable}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {showPengembalianProofModal && (
                    <TransferProofForm
                        mode="pengembalian"
                        close={() => setShowPengembalianProofModal(false)}
                        laporan={tempLaporan}
                        refresh={refreshTable}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {showSitasiModal && (
                    <SitasiForm
                        close={() => setShowSitasiModal(false)}
                        laporan={tempLaporan}
                        refresh={refreshTable}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            { showAlert && 
                <Alert 
                    msg={alertMsg} 
                    onCancel={() => setShowAlert(false)} 
                    alertType={alertStatus}
                /> 
            }

            <ContextMenu
                contextMenu={contextMenu}
                closeMenu={closeMenu}
                menus={menus}
            />
        </div>
    )
}