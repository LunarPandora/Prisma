"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX } from "@fortawesome/free-solid-svg-icons"

import TextInput from "@/app/component/Inputs/TextInput"
import Button from "@/app/component/Inputs/Button"
import { addLogbook } from "@/app/component/Libraries/api/logbook"
import { useUserStore } from "@/app/stores/useUserStore"

export default function LogbookFormDosen({
    close,
    refresh,
    laporan
}) {
    const user = useUserStore(state => state.user)

    const defaultForm = {
        laporan_id: laporan.laporan_id,
        judul: "",
        deskripsi: "",
        tgl_kegiatan: "",
        lampiran_drive_url: "",
    }

    const [form, setForm] = useState(defaultForm)
    const [loading, setLoading] = useState(false)

    const handleChange = (e) => {
        setForm(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }))
    }

    const submit = async () => {
        try {
            setLoading(true)

            const formData = new FormData()
            Object.keys(form).forEach(k => formData.append(k, form[k]))
            formData.append('user_id', user?.id)

            await addLogbook(formData)

            refresh()
            close()

        } catch (err) {
            console.error(err)
        } finally {
            setLoading(false)
        }
    }

    return (
        <motion.div
            className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
        >
            <motion.div
                className="w-1/2 bg-white p-5 rounded-xl flex flex-col gap-4"
                initial={{ scale: 1.05 }}
                animate={{ scale: 1 }}
            >
                {/* HEADER */}
                <div className="flex justify-between">
                    <p className="text-lg font-medium">Tambah Logbook</p>

                    <FontAwesomeIcon
                        icon={faX}
                        onClick={close}
                        className="cursor-pointer"
                    />
                </div>

                {/* FORM */}
                <div className="grid grid-cols-2 gap-2">
                    <TextInput
                        name="judul"
                        placeholder="Judul kegiatan"
                        value={form.judul}
                        onChange={handleChange}
                    />

                    <TextInput
                        name="tgl_kegiatan"
                        type="date"
                        value={form.tgl_kegiatan}
                        onChange={handleChange}
                    />

                    <div className="col-span-2">
                        <textarea
                            name="deskripsi"
                            placeholder="Deskripsi kegiatan"
                            value={form.deskripsi}
                            onChange={handleChange}
                            className="w-full border rounded-lg p-2 text-sm"
                        />
                    </div>

                    <div className="col-span-2">
                        <TextInput
                            name="lampiran_drive_url"
                            placeholder="Dokumen pendukung (link Google Drive, opsional)"
                            value={form.lampiran_drive_url}
                            onChange={handleChange}
                        />
                    </div>
                </div>

                {/* ACTION */}
                <div className="flex justify-end gap-2">
                    <Button variant="secondary" onClick={close}>
                        Batal
                    </Button>

                    <Button onClick={submit} disabled={loading}>
                        Simpan
                    </Button>
                </div>
            </motion.div>
        </motion.div>
    )
}