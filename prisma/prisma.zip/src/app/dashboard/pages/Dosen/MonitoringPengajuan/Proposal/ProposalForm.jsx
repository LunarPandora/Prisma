"use client"

import { useState, useEffect } from "react"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX, faFlask, faHashtag, faBrain, faGlasses, faRupiahSign, faBook, faPencil, faAtom, faFileExport, faWallet, faMoneyBillWave, faBuildingUser, faMicroscope, faHandHoldingHand} from '@fortawesome/free-solid-svg-icons'
import { AnimatePresence, motion } from "framer-motion"

import TextInput from "@/app/component/Inputs/TextInput"
import SelectInput from "@/app/component/Inputs/SelectInput"
import LoadingBar from "@/app/component/AppLoader/LoadingBar"

import { fetchPenerimaanProposal, fetchPeriode } from "@/app/component/Libraries/api/periode"
import { addHalamanPengesahan, updateHalamanPengesahan } from "@/app/component/Libraries/api/proposal"

import { useUserStore } from "@/app/stores/useUserStore";
import { jenisOptions, skemaPendanaanOptions, targetPublikasiOptions } from "@/app/component/Libraries/options/selections"
import ResearcherManager from "@/app/component/Research/ResearchManager"

export default function FormProposal({ refresh, close, data, isEdit, alertMsg, alertStatus, alertTrigger, skema }){
    const defaultForm = {
        proposal_id: "",
        topik_penelitian: "",
        jenis_penelitian: "",
        bidang_ilmu: "",
        fokus_sdgs: "",
        ra_data_collection: "",
        ra_biaya_publikasi: "",
        ra_insentif: "",

        target_publikasi_gan: "",
        target_publikasi_gen: "",
        rencana_judul_publikasi_gan: "",
        rencana_judul_publikasi_gen: "",
        metopen_gan: "",
        metopen_gen: "",
        unit_analisis_gan: "",
        unit_analisis_gen: "",
        kontribusi_ilmu_makul: "",
        kontribusi_pkm: "",
        
        rencana_luaran: "",
        institusi_mitra: "",
        periode_id: "",
        skema: "",
        sumber_skema: "",

        member_dosen_proposal: [],
        member_mhswa_proposal: [],
        member_kolab_proposal: [],
    }

    const [form, setForm] = useState(defaultForm)
    const [members, setMembers] = useState({
        ganjil: [],
        genap: []
    })

    const [loadingForm, setLoadingForm] = useState(false)

    const user = useUserStore(state => state.user)
    const MotionLoadingBar = motion.create(LoadingBar);

    useEffect(() => {
        if (!user || isEdit) return

        const ketuaPeneliti = {
            id: user.id,
            type: "Dosen",
            nama: user.nama,
            avatar: user.avatar,
            ttjp: "Ketua Peneliti",
            locked: true
        }

        setMembers({
            ganjil: [ketuaPeneliti],
            genap: [ketuaPeneliti]
        })

    }, [user, isEdit])

    useEffect(() => {
        if (isEdit && data) {
            setForm(prev => ({
                ...prev,
                ...data,
            }))
        } else {
            setForm(defaultForm)
        }
    }, [isEdit, data])

    const handleChange = (e) => {
        const { name, value } = e.target
        setForm(prev => ({
            ...prev,
            [name]: value,
        }))
    }

    async function sendData(mode){
        try{
            setLoadingForm(true)

            const formData = new FormData()
            Object.entries(form).forEach(([key, value]) => {
                // if (key === "uploaded_file") return // skip here

                if (value !== null && value !== undefined && value !== "" && value !== "-") {
                    formData.append(key, value)
                }
            })

            const serializeMembers = (type, semester, role) => {
                const key = memberConfig[type].key

                return members[type][semester].map(val => ({
                    id: val[key],
                    ttjp: val.ttjp,
                    semester:
                        semester === 'ganjil'
                            ? 'Ganjil'
                            : 'Genap',
                    role
                }))
            }

            const researcherList = [
                ...members.ganjil.map((item, index) => ({
                    id: item.id,
                    type: item.type,
                    nama: item.nama,
                    institusi: item.institusi,
                    prodi: item.prodi,
                    ttjp: item.ttjp,
                    semester: "Ganjil",
                    position: index + 1
                })),

                ...members.genap.map((item, index) => ({
                    id: item.id,
                    type: item.type,
                    nama: item.nama,
                    institusi: item.institusi,
                    prodi: item.prodi,
                    ttjp: item.ttjp,
                    semester: "Genap",
                    position: index + 1
                }))
            ]

            formData.append(
                "researcher_list",
                JSON.stringify(researcherList)
            )          

            if (form.uploaded_file instanceof File) {
                formData.append("uploaded_file", form.uploaded_file)
            }

            if (user.id){
                formData.append('user_id', user.id)
            }

            formData.append('mode', mode)

            const res = isEdit
                ? await updateHalamanPengesahan(formData)
                : await addHalamanPengesahan(formData)

            if (res.data.status == 'success'){ 
                alertMsg(`Sistem berhasil ${isEdit ? 'mengupdate' : 'mengajukan'} proposal!`)
                alertStatus('success')
            }
            else {
                alertMsg(`Sistem gagal ${isEdit ? 'mengupdate' : 'mengajukan'} proposal!`)
                alertStatus('danger')
            }
        }
        catch(err){
            alertMsg(`Sistem gagal ${isEdit ? 'mengupdate' : 'mengajukan'} proposal dikarenakan error di sistem!`)
            alertStatus('danger')

            console.error(err)
        }
        finally{
            setTimeout(() => {
                setLoadingForm(false)
                refresh()
                close()
                alertTrigger()
            }, 300)
        }
    }

    useEffect(() => {
        if (!data) return

        const buildMember = (val, type) => ({
            id:
                type === "Dosen"
                    ? val.user_id
                    : type === "Mahasiswa"
                        ? val.mhswa_id
                        : val.kolab_id,

            type,
            nama: val.nama,
            avatar: val.avatar,
            institusi: val.institusi ?? null,
            prodi: val.prodi ?? null,
            ttjp: val.ttjp || "",
            locked: false,
            position: val.position ?? 999
        })

        const grouped = {
            ganjil: [],
            genap: []
        }

        ;(data.member_dosen_proposal || []).forEach(val => {
            grouped[val.semester.toLowerCase()].push(
                buildMember(val, "Dosen")
            )
        })

        ;(data.member_mhswa_proposal || []).forEach(val => {
            grouped[val.semester.toLowerCase()].push(
                buildMember(val, "Mahasiswa")
            )
        })

        ;(data.member_kolab_proposal || []).forEach(val => {
            grouped[val.semester.toLowerCase()].push(
                buildMember(val, "Kolaborator")
            )
        })

        grouped.ganjil.sort((a, b) => a.position - b.position)
        grouped.genap.sort((a, b) => a.position - b.position)

        const injectKetua = (list) => {

            const exists = list.some(
                item =>
                    item.type === "Dosen"
                    &&
                    item.id === user?.id
            )

            if(exists){

                return list.map(item =>
                    item.id === user.id
                        ? {
                            ...item,
                            locked: true,
                            ttjp: item.ttjp || "Ketua Peneliti"
                        }
                        : item
                )
            }

            return [
                {
                    id: user.id,
                    type: "Dosen",
                    nama: user.nama,
                    avatar: user.avatar,
                    ttjp: "Ketua Peneliti",
                    locked: true
                },
                ...list
            ]
        }

        setMembers({
            ganjil: injectKetua(grouped.ganjil),
            genap: injectKetua(grouped.genap)
        })

    }, [data, user])

    return (
        <motion.div
            key="formModal"
            initial={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 will-change-auto"
        >
             <AnimatePresence mode="wait">
                { loadingForm ?
                    (
                        <MotionLoadingBar />
                    )
                    :
                    (
                        <motion.div
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="w-11/12 bg-white rounded-xl flex flex-col h-4/5 overflow-y-scroll relative"
                        >
                            <div className="flex w-full justify-between items-center sticky top-0 left-0 z-10 p-8">
                                <div className="absolute inset-0 backdrop-blur-sm 
                                            [mask-image:linear-gradient(to_bottom,black_60%,transparent_100%)]">
                                </div>

                                <div className="absolute inset-0 flex items-center justify-between w-full px-5">
                                    <p className="font-medium text-xl">{ isEdit ? 'Update Proposal' : 'Ajukan Proposal Baru' }</p>
                                    <FontAwesomeIcon onClick={close} icon={faX} className="text-sm" />
                                </div>
                            </div>

                            <div
                                key="form_proposal"
                                className="flex flex-col gap-3 p-5 pt-0"
                            >
                                <div className="w-full grid grid-cols-2 gap-4">
                                    <div className="flex flex-col gap-y-2 h-fit w-full border border-gray-300 rounded-md p-5 bg-white col-span-2">
                                        <span className="text-gray-600 text-md font-medium text-lg">
                                            Tipe penelitian
                                        </span>

                                        <div className="w-full grid grid-cols-2 gap-2"> 
                                            <SelectInput
                                                name="jenis_penelitian"
                                                value={form.jenis_penelitian}
                                                onChange={handleChange}
                                                options={jenisOptions}
                                                icon={faFlask}
                                                placeholder={`Pilih jenis penelitian`}
                                            />

                                            <SelectInput
                                                name="periode_id"
                                                value={form.periode_id}
                                                onChange={handleChange}
                                                dataSource={fetchPenerimaanProposal}
                                                transform={(item) => ({
                                                    text: item.nama_skema,
                                                    value: item.periode_id
                                                })}
                                                icon={faFlask}
                                                placeholder={`Pilih skema penelitian untuk disubmit`}
                                            />
                                        </div>
                                    </div>

                                    <div className="flex flex-col gap-y-2 h-fit w-full border border-gray-300 rounded-md p-5 bg-white col-span-2">
                                        <span className="text-gray-600 text-md font-medium text-lg">
                                            Detail penelitian
                                        </span>

                                        <div className="w-full grid grid-cols-6 col-span-3 gap-2">
                                            <TextInput
                                                name="topik_penelitian" 
                                                type="text"
                                                placeholder="Masukkan topik penelitian"
                                                icon={faHashtag}
                                                value={form.topik_penelitian}
                                                onChange={handleChange}
                                                className="col-span-2"
                                            />

                                            <TextInput
                                                name="bidang_ilmu" 
                                                type="text"
                                                placeholder="Masukkan bidang ilmu"
                                                icon={faBrain}
                                                value={form.bidang_ilmu}
                                                onChange={handleChange}
                                                className="col-span-2"
                                            />

                                            <TextInput
                                                name="fokus_sdgs" 
                                                type="text"
                                                placeholder="Masukkan fokus SDGs"
                                                icon={faGlasses}
                                                value={form.fokus_sdgs}
                                                onChange={handleChange}
                                                className="col-span-2"
                                            />

                                            <TextInput
                                                name="kontribusi_ilmu_makul" 
                                                type="text"
                                                placeholder="Masukkan kontribusi riset pada ilmu / matkul"
                                                icon={faAtom}
                                                value={form.kontribusi_ilmu_makul}
                                                onChange={handleChange}
                                                className="col-span-2"
                                                isTextArea={true}
                                            />

                                            <TextInput
                                                name="kontribusi_pkm" 
                                                type="text"
                                                placeholder="Masukkan kontribusi riset pada PKM"
                                                icon={faHandHoldingHand}
                                                value={form.kontribusi_pkm}
                                                onChange={handleChange}
                                                className="col-span-2"
                                                isTextArea={true}
                                            />

                                            <TextInput
                                                name="rencana_luaran" 
                                                type="text"
                                                placeholder="Masukkan rencana luaran (HKI, Buku, dsb)"
                                                icon={faFileExport}
                                                value={form.rencana_luaran}
                                                onChange={handleChange}
                                                className="col-span-2"
                                                isTextArea={true}
                                            />
                                        </div>
                                    </div>

                                    <div className="flex flex-col gap-y-2 h-fit w-full border border-gray-300 rounded-md p-5 bg-white">
                                        <span className="text-gray-600 text-md font-medium text-lg">
                                            Rancangan Semester Ganjil
                                        </span>

                                        <SelectInput
                                            name="target_publikasi_gan"
                                            value={form.target_publikasi_gan}
                                            onChange={handleChange}
                                            options={targetPublikasiOptions}
                                            icon={faBook}
                                            placeholder="Pilih target publikasi (ganjil)"
                                        />

                                        <TextInput
                                            name="rencana_judul_publikasi_gan" 
                                            type="text"
                                            placeholder="Masukkan rencana judul publikasi (ganjil)"
                                            icon={faPencil}
                                            value={form.rencana_judul_publikasi_gan}
                                            onChange={handleChange}
                                        />

                                        <TextInput
                                            name="metopen_gan" 
                                            type="text"
                                            placeholder="Masukkan metode penelitian yang digunakan (ganjil)"
                                            icon={faAtom}
                                            value={form.metopen_gan}
                                            onChange={handleChange}
                                            isTextArea={true}
                                        />

                                        <TextInput
                                            name="unit_analisis_gan" 
                                            type="text"
                                            placeholder="Masukkan unit analisis (ganjil)"
                                            icon={faMicroscope}
                                            value={form.unit_analisis_gan}
                                            onChange={handleChange}
                                        />

                                        <span className="text-gray-600 text-md font-medium text-lg pt-5">
                                            Anggota Peneliti
                                        </span>

                                        <ResearcherManager
                                            value={members.ganjil}
                                            onChange={(data) =>
                                                setMembers(prev => ({
                                                    ...prev,
                                                    ganjil: data
                                                }))
                                            }
                                        />
                                    </div>

                                    <div className="flex flex-col gap-y-2 h-fit w-full border border-gray-300 rounded-md p-5 bg-white">
                                        <span className="text-gray-600 text-md font-medium text-lg">
                                            Rancangan Semester Genap
                                        </span>

                                        <SelectInput
                                            name="target_publikasi_gen"
                                            value={form.target_publikasi_gen}
                                            onChange={handleChange}
                                            options={targetPublikasiOptions}
                                            icon={faBook}
                                            placeholder="Pilih target publikasi (genap)"
                                        />

                                        <TextInput
                                            name="rencana_judul_publikasi_gen" 
                                            type="text"
                                            placeholder="Masukkan rencana judul publikasi (genap)"
                                            icon={faPencil}
                                            value={form.rencana_judul_publikasi_gen}
                                            onChange={handleChange}
                                        />

                                        <TextInput
                                            name="metopen_gen" 
                                            type="text"
                                            placeholder="Masukkan metode penelitian yang digunakan (genap)"
                                            icon={faAtom}
                                            value={form.metopen_gen}
                                            onChange={handleChange}
                                            isTextArea={true}
                                        />

                                        <TextInput
                                            name="unit_analisis_gen" 
                                            type="text"
                                            placeholder="Masukkan unit analisis (genap)"
                                            icon={faMicroscope}
                                            value={form.unit_analisis_gen}
                                            onChange={handleChange}
                                        />

                                        <span className="text-gray-600 text-md font-medium text-lg pt-5">
                                            Anggota Peneliti
                                        </span>

                                        <ResearcherManager
                                            value={members.genap}
                                            onChange={(data) =>
                                                setMembers(prev => ({
                                                    ...prev,
                                                    genap: data
                                                }))
                                            }
                                        />
                                    </div>

                                    <div className="flex flex-col gap-y-2 h-fit w-full border border-gray-300 rounded-md p-5 bg-white col-span-2">
                                        <span className="text-gray-600 text-md font-medium text-lg">
                                            Rencana Anggaran
                                        </span>

                                        <div className="w-full grid grid-cols-3 col-span-3 gap-2">
                                            <SelectInput
                                                name="skema"
                                                value={form.skema}
                                                onChange={handleChange}
                                                options={skemaPendanaanOptions}
                                                icon={faWallet}
                                                placeholder="Pilih skema pendanaan"
                                            />

                                            <TextInput
                                                name="sumber_skema" 
                                                type="text"
                                                placeholder="Masukkan sumber skema (Pemerintah, Yayasan, dsb)"
                                                icon={faMoneyBillWave}
                                                value={form.sumber_skema}
                                                onChange={handleChange}
                                            />

                                            <TextInput
                                                name="institusi_mitra" 
                                                type="text"
                                                placeholder="Masukkan nama institusi mitra (apabila ada)"
                                                icon={faBuildingUser}
                                                value={form.institusi_mitra}
                                                onChange={handleChange}
                                            />

                                            <TextInput
                                                name="ra_data_collection" 
                                                type="number"
                                                placeholder="Masukkan rencana anggaran Data Collection"
                                                icon={faRupiahSign}
                                                value={form.ra_data_collection}
                                                onChange={handleChange}
                                            />

                                            <TextInput
                                                name="ra_biaya_publikasi" 
                                                type="number"
                                                placeholder="Masukkan rencana anggaran Biaya Publikasi"
                                                icon={faRupiahSign}
                                                value={form.ra_biaya_publikasi}
                                                onChange={handleChange}
                                            />

                                            <TextInput
                                                name="ra_insentif" 
                                                type="number"
                                                placeholder="Masukkan rencana anggaran Insentif"
                                                icon={faRupiahSign}
                                                value={form.ra_insentif}
                                                onChange={handleChange}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="w-full grid grid-cols-2 gap-2">
                                    <button onClick={() => sendData('draft')} className="bg-white hover:bg-foreground text-foreground/90 hover:text-white text-lg px-5 py-2 rounded-lg font-medium mt-1 transition-colors duration-300 ease-in-out cursor-pointer border-2 border-foreground/90">
                                        Simpan sebagai draft
                                    </button> 
                                    <button onClick={() => sendData('submit')} className="bg-foreground/90 hover:bg-foreground text-white text-lg px-5 py-2 rounded-lg font-medium mt-1 transition-colors duration-300 ease-in-out cursor-pointer">
                                        { 
                                            isEdit ? 'Update' : 'Submit'
                                        }
                                    </button>
                                </div>
                            </div>
                        </motion.div>
                    )
                }
            </AnimatePresence>
        </motion.div>
    )
}