"use client"

import Image from "next/image"
import { useState, useEffect, useRef } from "react"
import { AnimatePresence, motion } from "framer-motion"

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX, faUser, faGraduationCap, faIdCard, faEdit, faSchool } from '@fortawesome/free-solid-svg-icons'

import TextInput from "@/app/component/Inputs/TextInput"
import LoadingBar from "@/app/component/AppLoader/LoadingBar"

import { addKolaborator, updateKolaborator } from "@/app/component/Libraries/api/kolaborator"
import Button from "@/app/component/Inputs/Button"

export default function FormKolaborator({ refresh, close, data, isEdit, alertMsg, alertStatus, alertTrigger }){
    const defaultForm = {
        kolab_id: "",
        nama: "",
        nidn: "",
        prodi: "",
        institusi: "",
        avatar: "",
        uploaded_file: null
    }

    const [form, setForm] = useState(defaultForm)
    const [loadingForm, setLoadingForm] = useState(false)
    const [preview, setPreview] = useState(null);

    const MotionLoadingBar = motion.create(LoadingBar);
    const fileInputRef = useRef(null);
    const imageSrc =
        preview || 
        form.avatar || 
        "/img/user_placeholder.webp";

    useEffect(() => {
        if (isEdit && data) {
            setForm(prev => ({
                ...prev,
                ...data,
            }))
        } else {
            setForm(defaultForm)
        }
    }, [isEdit, data])

    const handleChange = (e) => {
        const { name, value } = e.target
        setForm(prev => ({
            ...prev,
            [name]: value,
        }))
    }

    const handleFileInput = (e) => {
        const file = e.target.files[0]
        if (!file) return

        if (e.target.files.length > 1) {
            alert("Only one file allowed!");
            return;
        }

        if (!file.type.startsWith("image/")) {
            alert("Only image files are allowed");
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            alert("File too large (max 5MB)");
            return;
        }

        setForm((prev) => ({
            ...prev,
            uploaded_file: file,
        }))

        const previewUrl = URL.createObjectURL(file);
        setPreview(previewUrl);
    }

    async function sendData(){
        try{
            setLoadingForm(true)
            
            const formData = new FormData()
            Object.entries(form).forEach(([key, value]) => {
                if (key === "uploaded_file") return // skip here

                if (value !== null && value !== undefined && value !== "" && value !== "-") {
                    formData.append(key, value)
                }
            })

            if (form.uploaded_file instanceof File) {
                formData.append("uploaded_file", form.uploaded_file)
            }

            const res = isEdit
                ? await updateKolaborator(formData)
                : await addKolaborator(formData)

            if (res.data.status == 'success'){ 
                alertMsg(`Sistem berhasil ${isEdit ? 'mengupdate' : 'menambahkan'} kolaborator!`)
                alertStatus('success')
            }
            else {
                alertMsg(`Sistem gagal ${isEdit ? 'mengupdate' : 'menambahkan'} kolaborator!`)
                alertStatus('danger')
            }
        }
        catch(err){
            alertMsg(`Sistem gagal ${isEdit ? 'mengupdate' : 'menambahkan'} data kolaborator dikarenakan error di sistem!`)
            alertStatus('danger')

            console.error(err)
        }
        finally{
            setTimeout(() => {
                setLoadingForm(false)
                refresh()
                close()
                alertTrigger()
            }, 300)
        }
    }

    useEffect(() => {
        return () => {
            if (preview) URL.revokeObjectURL(preview);
        };
    }, [preview]);

    return (
        <motion.div
            key="formModal"
            initial={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 will-change-auto"
        >
            <AnimatePresence mode="wait">
                { loadingForm ? 
                    (
                        <MotionLoadingBar />
                    )
                    :
                    (
                        <motion.div
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="w-2/3 bg-white p-5 rounded-xl flex flex-col gap-5"
                        >
                            <div class="flex w-full justify-between items-center">
                                <p className="font-medium text-xl">{ isEdit ? 'Update Kolaborator' : 'Tambah Kolaborator Baru' }</p>
                                <FontAwesomeIcon onClick={close} icon={faX} className="text-sm" />
                            </div>
                            <motion.div
                                key="form_section"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.2 }}
                                className="flex flex-col gap-3"
                            >
                                <div className="flex items-center gap-3">
                                    <div className="w-1/5 flex flex-col items-center justify-center gap-2">
                                        <input
                                            type="file"
                                            accept="image/*"
                                            ref={fileInputRef}
                                            onChange={handleFileInput}
                                            style={{ display: "none" }}
                                        />

                                        <div className="relative rounded-full overflow-hidden">
                                            <Image
                                                src={imageSrc}
                                                alt="avatar"
                                                width={150}
                                                height={150}
                                                className="relative aspect-square object-cover object-center"
                                                unoptimized
                                            />
                                            <div
                                                className="w-full h-full z-10 absolute inset-0 opacity-0 hover:opacity-100 bg-black/60 flex items-center justify-center hover:cursor-pointer transition-opacity duration-200 ease-in-out" 
                                                onClick={() => fileInputRef.current.click()}
                                            >
                                                <FontAwesomeIcon icon={faEdit} className="text-white text-2xl" />
                                            </div>
                                        </div>

                                        <span 
                                            className="text-xs underline decoration-dotted underline-offset-3 hover:cursor-pointer hover:text-primary text-center"
                                            onClick={() => fileInputRef.current.click()}
                                        >
                                            Ubah foto profil<br />
                                            Maks. 5MB
                                        </span>
                                    </div>

                                    <div className="w-4/5 h-fit grid grid-cols-2 gap-3">
                                        <TextInput
                                            name="nama" 
                                            type="text"
                                            placeholder="Masukkan nama kolaborator"
                                            icon={faUser}
                                            value={form.nama}
                                            onChange={handleChange}
                                            className="col-span-2"
                                        />

                                        <TextInput 
                                            name="nidn" 
                                            type="text" 
                                            placeholder="Masukkan NIDN kolaborator"
                                            icon={faIdCard}
                                            value={form.nidn}
                                            onChange={handleChange}
                                        />

                                        <TextInput 
                                            name="prodi" 
                                            type="text" 
                                            placeholder="Masukkan program studi kolaborator"
                                            icon={faGraduationCap}
                                            value={form.prodi}
                                            onChange={handleChange}
                                        />

                                        <TextInput 
                                            name="institusi" 
                                            type="text" 
                                            placeholder="Masukkan institusi asal kolaborator"
                                            icon={faSchool}
                                            value={form.institusi}
                                            onChange={handleChange}
                                        />

                                        <Button onClick={sendData} className="col-span-2">
                                            { 
                                                isEdit ? 'Update' : 'Tambahkan'
                                            }
                                        </Button>
                                    </div>
                                </div>
                            </motion.div>
                        </motion.div>
                    )
                }
            </AnimatePresence>
        </motion.div>
    )
}