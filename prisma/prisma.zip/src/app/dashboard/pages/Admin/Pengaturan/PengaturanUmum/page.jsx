"use client"

import { useEffect, useState } from "react"

import Button from "@/app/component/Inputs/Button"
import MultiKriteriaEditor from "@/app/component/Inputs/MultiKriteriaEditor"
import MultiQuestionEditor from "@/app/component/Inputs/MultiQuestionEditor"
import SelectInput from "@/app/component/Inputs/SelectInput"
import TextInput from "@/app/component/Inputs/TextInput"

import {
    fetchLPPM,
    fetchRektorat,
    fetchSettings,
    updateSettings
} from "@/app/component/Libraries/api/settings"

import {
    faFlask,
    faSchool
} from "@fortawesome/free-solid-svg-icons"

export default function PengaturanUmum(){
    const defaultForm = {
        kepala_lppm: "",
        rektor: "",
        nama_kampus: "",
        kriteria_penilaian: [],
        list_kesesuaian_tema: []
    }

    const [form, setForm] = useState(defaultForm)
    const [initialForm, setInitialForm] = useState(defaultForm)

    const [kriteriaValidation, setKriteriaValidation] = useState({
        valid: false,
        totalBobot: 0,
        hasEmptyFields: false
    })

    const [loading, setLoading] = useState(false)

    useEffect(() => {
        async function loadSettings(){
            const data = await fetchSettings()

            const mapped = {
                kepala_lppm: data.kepala_lppm || "",
                nama_kampus: data.nama_kampus || "",
                rektor: data.rektor || "",
                kriteria_penilaian: data.kriteria_penilaian || [],
                list_kesesuaian_tema: data.list_kesesuaian_tema || [],
            }

            setForm(mapped)
            setInitialForm(mapped)
        }

        loadSettings()
    }, [])

    const hasEmptyTema = form.list_kesesuaian_tema.some(item =>
        !item.question?.trim()
    )

    const handleChange = (e) => {
        const { name, value } = e.target

        setForm(prev => ({
            ...prev,
            [name]: value
        }))
    }

    const hasChanges = () => {
        const changed =
            JSON.stringify(form) !==
            JSON.stringify(initialForm)

        return (
            changed &&
            kriteriaValidation.valid &&
            !kriteriaValidation.hasEmptyFields &&
            !hasEmptyTema
        )
    }

    async function submitData(){
        try{
            setLoading(true)
            const formData = new FormData()

            Object.entries(form).forEach(([key, value]) => {
                if(
                    value !== null &&
                    value !== undefined &&
                    value !== "" &&
                    value !== "-"
                ){
                    if(typeof value === "object"){
                        formData.append(
                            key,
                            JSON.stringify(value)
                        )
                    }
                    else{
                        formData.append(key, value)
                    }
                }
            })

            const res = await updateSettings(formData)

            if(res.data.status === "success"){
                setInitialForm(form)
            }
        }
        finally{
            setLoading(false)
        }
    }

    return (
        <div className="flex flex-col gap-5">
            <div className="flex flex-col gap-y-2 w-full border border-gray-300 rounded-md p-5 bg-white">
                <span className="text-gray-600 text-lg font-medium">
                    Pengesahan dan Tanggung Jawab
                </span>

                <div className="grid grid-cols-2 gap-3">

                    <SelectInput
                        name="kepala_lppm"
                        value={form.kepala_lppm}
                        onChange={handleChange}
                        dataSource={fetchLPPM}
                        transform={(item) => ({
                            text: item.nama,
                            value: item.id
                        })}
                        icon={faFlask}
                        placeholder="Kepala LPPM saat ini"
                    />

                    <SelectInput
                        name="rektor"
                        value={form.rektor}
                        onChange={handleChange}
                        dataSource={fetchRektorat}
                        transform={(item) => ({
                            text: item.nama,
                            value: item.id
                        })}
                        icon={faFlask}
                        placeholder="Rektor saat ini"
                    />

                    <TextInput
                        name="nama_kampus"
                        value={form.nama_kampus}
                        onChange={handleChange}
                        placeholder="Masukkan nama kampus"
                        icon={faSchool}
                        className="col-span-2"
                    />

                </div>

            </div>

            <div className="flex flex-col gap-y-2 w-full border border-gray-300 rounded-md p-5 bg-white">

                <span className="text-gray-600 text-lg font-medium">
                    Sistem dan Kriteria Penilaian
                </span>

                <div className="grid grid-cols-2 gap-3">

                    <MultiKriteriaEditor
                        className="pt-3 col-span-2"
                        name="kriteria_penilaian"
                        value={form.kriteria_penilaian}
                        onChange={handleChange}
                        onValidationChange={setKriteriaValidation}
                        placeholder="Tentukan kriteria penilaian"
                    />

                    <MultiQuestionEditor
                        className="pt-3 col-span-2"
                        name="list_kesesuaian_tema"
                        value={form.list_kesesuaian_tema}
                        onChange={handleChange}
                        placeholder="Tentukan kriteria penilaian kesesuaian tema"
                    />

                </div>

            </div>

            <Button
                onClick={submitData}
                disabled={!hasChanges() || loading}
            >
                Simpan Perubahan
            </Button>

        </div>
    )
}