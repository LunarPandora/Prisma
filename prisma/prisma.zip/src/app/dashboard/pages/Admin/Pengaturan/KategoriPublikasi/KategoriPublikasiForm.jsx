"use client"

import { AnimatePresence, motion } from "framer-motion"
import { useState } from "react"

import Button from "@/app/component/Inputs/Button"
import TextInput from "@/app/component/Inputs/TextInput"
import { addPublicationCategory, updatePublicationCategory } from "@/app/component/Libraries/api/kategoripublikasi"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX } from "@fortawesome/free-solid-svg-icons"
import LoadingBar from "@/app/component/AppLoader/LoadingBar"

export default function KategoriPublikasiForm({
    close,
    refresh,

    isEdit = false,
    data = {},

    alertMsg,
    alertStatus,
    alertTrigger,
}) {
    const defaultForm = {
        nama: data.nama || "",
        peringkat: Array.isArray(data.peringkat)
            ? data.peringkat
            : [],
    }

    const [newPeringkat, setNewPeringkat] = useState("")
    const MotionLoadingBar = motion.create(LoadingBar);

    const [form, setForm] = useState(defaultForm)
    const [loading, setLoading] = useState(false)

    const [errors, setErrors] = useState({})

    function handleChange(e){
        const { name, value } = e.target

        setForm(prev => ({
            ...prev,
            [name]: value
        }))
    }

    function addPeringkat() {
        const value = newPeringkat.trim()

        if (!value) return

        if (form.peringkat.includes(value)) {
            setNewPeringkat("")
            return
        }

        setForm(prev => ({
            ...prev,
            peringkat: [...prev.peringkat, value]
        }))

        setNewPeringkat("")
    }

    function removePeringkat(index){
        setForm(prev => ({
            ...prev,
            peringkat: prev.peringkat.filter(
                (_, i) => i !== index
            )
        }))
    }

    async function submitData(){
        try{
            setLoading(true)
            const formData = new FormData()

            Object.entries(form).forEach(([key, value]) => {
                if (key === "peringkat") return

                formData.append(key, value)
            })

            formData.append(
                "pub_category_id",
                data.pub_category_id
            )

            formData.append(
                "peringkat",
                JSON.stringify(form.peringkat)
            )

            if(isEdit){
                formData.append(
                    "publication_category_id",
                    data.publication_category_id
                )
            }

            const res = isEdit
                ? await updatePublicationCategory(formData)
                : await addPublicationCategory(formData)

            if(res.data.status === "success"){
                alertMsg(
                    isEdit
                    ? "Kategori publikasi berhasil diperbarui."
                    : "Kategori publikasi berhasil ditambahkan."
                )

                alertStatus("success")

                refresh()
                close()
                alertTrigger()
            }
        }
        catch(err){
            if(err.response?.status === 422){
                setErrors(err.response.data.errors || {})
            }

            alertMsg("Terjadi kesalahan.")
            alertStatus("danger")
            alertTrigger()

            console.error(err)
        }
        finally{
            setLoading(false)
        }
    }

    return (
        <motion.div
            key="formModal"
            initial={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 will-change-auto"
        >
            <AnimatePresence mode="wait">
                { loading ?
                    (
                        <MotionLoadingBar />
                    )
                    :
                    (
                        <motion.div
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="w-1/2 bg-white p-5 rounded-xl flex flex-col gap-5"
                        >
                            <div class="flex w-full justify-between items-center">
                                <p className="font-medium text-xl">Cek Proposal</p>
                                <FontAwesomeIcon onClick={() => close('this')} icon={faX} className="text-sm" />
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                                <TextInput
                                    name="nama"
                                    placeholder="Nama kategori publikasi"
                                    value={form.nama}
                                    onChange={handleChange}
                                    error={errors.nama?.[0]}
                                    className="col-span-2"
                                />

                                <div className="flex flex-col gap-3">
                                    <span className="text-sm font-medium">
                                        Daftar Peringkat
                                    </span>

                                    <div className="flex items-end gap-2">
                                        <TextInput
                                            placeholder="Contoh: Q1"
                                            value={newPeringkat}
                                            onChange={(e) => setNewPeringkat(e.target.value)}
                                            onKeyDown={(e) => {
                                                if (e.key === "Enter") {
                                                    e.preventDefault()
                                                    addPeringkat()
                                                }
                                            }}
                                        />

                                        <Button onClick={addPeringkat} className={"h-fit"}>
                                            +
                                        </Button>
                                    </div>

                                    <div className="flex flex-wrap gap-2">

                                        {form.peringkat.map((item,index)=>(
                                            <div
                                                key={index}
                                                className="px-3 py-1 rounded-full bg-gray-100 flex items-center gap-2"
                                            >
                                                <span>{item}</span>

                                                <button
                                                    type="button"
                                                    onClick={()=>removePeringkat(index)}
                                                    className="text-red-500"
                                                >
                                                    ×
                                                </button>
                                            </div>
                                        ))}

                                    </div>
                                </div>
                            </div>

                            <div className="flex justify-end gap-3">
                                <Button
                                    variant="secondary"
                                    onClick={close}
                                >
                                    Batal
                                </Button>

                                <Button
                                    onClick={submitData}
                                    disabled={loading}
                                >
                                    {
                                        loading
                                        ? "Menyimpan..."
                                        : (
                                            isEdit
                                            ? "Simpan Perubahan"
                                            : "Tambah Kategori"
                                        )
                                    }
                                </Button>
                            </div>
                        </motion.div>
                    )
                }
            </AnimatePresence>
        </motion.div>
    )
}