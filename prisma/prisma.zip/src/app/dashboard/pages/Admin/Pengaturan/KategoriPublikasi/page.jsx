"use client"

import { useState } from "react"
import { AnimatePresence } from "framer-motion"

import Alert from "@/app/component/Alert/Alert"
import ContextMenu from "@/app/component/Context/ContextMenu"
import CustomTable from "@/app/component/Table/CustomTable"
import LoadingBar from "@/app/component/AppLoader/LoadingBar"

import { useContextMenu } from "@/app/component/Libraries/hooks/useContextMenu"
import { deletePublicationCategory, fetchPublicationCategory} from "@/app/component/Libraries/api/kategoripublikasi"
import { createKategoriPublikasiAdminMenus } from "@/app/component/Libraries/config/KategoriPublikasi/KategoriPublikasiAdminMenu"
import KategoriPublikasiForm from "./KategoriPublikasiForm"

export default function KategoriPublikasi(){
    const [refreshKey, setRefreshKey] = useState(0)

    const [addKategoriModal, setAddKategoriModal] = useState(false)
    const [editKategoriModal, setEditKategoriModal] = useState(false)
    const [removeKategoriModal, setRemoveKategoriModal] = useState(false)

    const [tempRowData, setTempRowData] = useState({})
    const [loadingForm, setLoadingForm] = useState(false)

    const [loading, setLoading] = useState(false)

    const [showAlert, setShowAlert] = useState(false)
    const [alertMsg, setAlertMsg] = useState("")
    const [alertStatus, setAlertStatus] = useState("success")

    const {
        contextMenu,
        openMenu,
        closeMenu
    } = useContextMenu()

    const menus = createKategoriPublikasiAdminMenus({
        refreshTable,
        handleAdd,
        handleEdit,
        handleRemove
    })

    function handleAdd(){
        setAddKategoriModal(true)
    }

    function handleEdit(r){
        setEditKategoriModal(true)
        setTempRowData(r)
    }

    function handleRemove(r){
        setRemoveKategoriModal(true)
        setTempRowData(r)
    }

    function refreshTable(){
        setRefreshKey(prev => prev + 1)
    }

    async function removeKategori(){
        try{
            setLoading(true)

            const res = await deletePublicationCategory(
                tempRowData.id
            )

            if(res.data.status === "success"){
                setAlertStatus("success")
                setAlertMsg(
                    "Kategori publikasi berhasil dihapus."
                )
            }
            else{
                setAlertStatus("danger")
                setAlertMsg(
                    "Gagal menghapus kategori publikasi."
                )
            }
        }
        catch(err){
            console.error(err)

            setAlertStatus("danger")
            setAlertMsg(
                "Gagal menghapus kategori publikasi."
            )
        }
        finally{
            setLoading(false)
            setRemoveKategoriModal(false)
            refreshTable()
            setShowAlert(true)
        }
    }

    return (
        <div
            className="flex flex-col gap-5"
            onContextMenu={(e) => openMenu(e)}
        >
            <CustomTable
                fetchMethod={fetchPublicationCategory}
                refreshKey={refreshKey}
                onContextRequest={(e, type, data, source) =>
                    openMenu(e, type, data, source)
                }
                columns={[
                    {
                        header: "Nama Kategori",
                        key: "nama"
                    },
                    {
                        header: "Peringkat",
                        key: "peringkat",
                        render: (value, row) => {
                            return (
                                <div className="flex flex-col gap-1">
                                    { value.join(', ') }
                                </div>
                            )
                        }
                    },
                ]}
            />

            <AnimatePresence>
                {addKategoriModal && (
                    <KategoriPublikasiForm
                        close={() => setAddKategoriModal(false)}
                        refresh={refreshTable}
                        isEdit={false}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {editKategoriModal && (
                    <KategoriPublikasiForm
                        close={() => setEditKategoriModal(false)}
                        refresh={refreshTable}
                        isEdit
                        data={tempRowData}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence mode="wait">
                {removeKategoriModal && (
                    loading
                    ? (
                        <LoadingBar />
                    )
                    : (
                        <Alert
                            alertType="warning"
                            title="Hapus kategori publikasi"
                            msg="Apakah Anda yakin ingin menghapus kategori publikasi ini?"
                            onCancel={() =>
                                setRemoveKategoriModal(false)
                            }
                            onAccept={removeKategori}
                            acceptText="Hapus"
                            isConfirmation
                        />
                    )
                )}
            </AnimatePresence>

            {showAlert && (
                <Alert
                    msg={alertMsg}
                    alertType={alertStatus}
                    onCancel={() =>
                        setShowAlert(false)
                    }
                />
            )}

            <ContextMenu
                contextMenu={contextMenu}
                closeMenu={closeMenu}
                menus={menus}
            />

        </div>
    )
}