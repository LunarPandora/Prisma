"use client"

import { useState } from "react"
import PengaturanUmum from "./PengaturanUmum/page"
import KategoriPublikasi from "./KategoriPublikasi/page"


export default function Pengaturan() {
    const tabs = [
        {
            label: "Pengaturan Umum",
            value: "general"
        },
        {
            label: "Kategori Publikasi",
            value: "publication-category"
        }
    ]

    const [activeTab, setActiveTab] = useState("general")

    return (
        <div className="flex flex-col gap-5 min-h-screen">

            <div className="flex flex-col gap-2">
                <h1 className="text-4xl font-medium">
                    Pengaturan
                </h1>

                <p className="text-lg text-gray-500 font-light">
                    Ubah konfigurasi dan pengaturan sistem LPPM disini.
                </p>
            </div>

            <div className="flex gap-2 border-b pb-3">
                {tabs.map(tab => (
                    <button
                        key={tab.value}
                        onClick={() => setActiveTab(tab.value)}
                        className={`
                            px-4 py-2 rounded-md text-sm transition-all
                            ${
                                activeTab === tab.value
                                    ? "bg-foreground text-background"
                                    : "hover:bg-gray-100"
                            }
                        `}
                    >
                        {tab.label}
                    </button>
                ))}
            </div>

            {activeTab === "general" && (
                <PengaturanUmum />
            )}

            {activeTab === "publication-category" && (
                <KategoriPublikasi />
            )}

        </div>
    )
}