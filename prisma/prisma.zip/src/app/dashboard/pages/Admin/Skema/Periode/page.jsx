"use client"

import { useState, useEffect } from "react"
import { AnimatePresence } from "framer-motion"

import Alert from "@/app/component/Alert/Alert"
import ContextMenu from "@/app/component/Context/ContextMenu"

import FormPeriode from "./PeriodeForm"

import { useUserStore } from "@/app/stores/useUserStore"
import { getModuleAccess } from "@/app/component/Libraries/utils/menu"

import { getPeriode } from "@/app/component/Libraries/api/periode"
import { createPeriodeAdminMenus } from "@/app/component/Libraries/config/Periode/PeriodeAdminMenu"
import { useContextMenu } from "@/app/component/Libraries/hooks/useContextMenu"
import CustomTable from "@/app/component/Table/CustomTable"
import { formatIndonesianDate } from "@/app/component/Libraries/utils/date"
import SelectInput from "@/app/component/Inputs/SelectInput"
import { faFlask } from "@fortawesome/free-solid-svg-icons"
import { useQueryBuilder } from "@/app/component/Libraries/hooks/useQueryBuilder"

export default function Periode({ skema, onBack }) {
    const [refreshKey, setRefreshKey] = useState(0)

    const [showAlert, setShowAlert] = useState(false)
    const [alertMsg, setAlertMsg] = useState("")
    const [alertStatus, setAlertStatus] = useState("success")

    const [editPeriodeModal, setEditPeriodeModal] = useState(false)

    const id = skema.skema_id
    const [tempRowData, setTempRowData] = useState({})

    const qb = useQueryBuilder()
    const [qs, setQs] = useState("")

    const [filter, setFilter] = useState({
        jenis_penelitian: ""
    })

    const handleFilterChange = (e) => {
        const { name, value } = e.target

        setFilter(prev => ({
            ...prev,
            [name]: value
        }))
    }

    useEffect(() => {
        qb.resetFilters()

        qb.addFilter("skema_id", id)
        qb.addFilter(
            "jenis_penelitian",
            filter.jenis_penelitian
        )

        setQs(qb.toQueryString())
    }, [id, filter.jenis_penelitian])

    const user = useUserStore(state => state.user)
    const access = getModuleAccess("periode", user?.role)

    const { contextMenu, openMenu, closeMenu } = useContextMenu()

    function refreshTable() {
        setRefreshKey(prev => prev + 1)
    }

    function handleEdit(r) {
        setEditPeriodeModal(true)
        setTempRowData(r)
    }

    const menus = createPeriodeAdminMenus({
        access,
        refreshTable,
        handleEdit,
    })

    useEffect(() => {
        refreshTable()
    }, [qs])

    return (
        <div
            className="flex flex-col gap-5 min-h-screen"
            onContextMenu={(e) => openMenu(e)}
        >
            <div className="flex items-center gap-2 text-sm text-gray-500">
                <button
                    onClick={onBack}
                    className="hover:text-black"
                >
                    Skema
                </button>
                <span>›</span>
                <span>{skema.nama_skema}</span>
                <span>›</span>
                <span className="font-medium text-black">
                    List Periode
                </span>
            </div>

            <div className="flex flex-col justify-between items-start gap-5">
                <div className="flex flex-col gap-2">
                    <h1 className="text-4xl font-medium">
                        Periode Penelitian
                    </h1>

                    <p className="text-lg text-gray-500 font-light">
                        Kelola periode penelitian dan PkM untuk skema ini.
                    </p>
                </div>

                <div className="bg-white rounded-lg p-3 w-full flex items-end gap-2">
                    <SelectInput
                        name="jenis_penelitian"
                        value={filter.jenis_penelitian}
                        icon={faFlask}
                        onChange={handleFilterChange}
                        options={[
                            {
                                text: "Penelitian",
                                value: "Penelitian"
                            },
                            {
                                text: "PkM",
                                value: "PkM"
                            }
                        ]}
                        placeholder="Jenis Penelitian"
                    />
                </div>

                <CustomTable
                    fetchMethod={getPeriode}
                    searchQuery={qs}
                    refreshKey={refreshKey}
                    className="w-full"
                    roundedStyle="rounded-lg rounded-tl-none"
                    onContextRequest={(e, type, data, source) =>
                        openMenu(e, type, data, source)
                    }
                    columns={[
                        {
                            header: "Jenis",
                            key: "jenis_penelitian",
                            render: (value) => (
                                <span
                                    className={`px-2 py-1 rounded text-sm ${
                                        value === "Penelitian"
                                            ? "bg-blue-100 text-blue-700 border border-blue-300"
                                            : "bg-green-100 text-green-700 border border-green-300"
                                    }`}
                                >
                                    {value}
                                </span>
                            )
                        },

                        {
                            header: "Nama Periode",
                            key: "nama_periode"
                        },

                        {
                            header: "Tanggal Mulai",
                            key: "tgl_mulai",
                            render: (value) => (
                                value
                                    ? formatIndonesianDate(value)
                                    : "-"
                            )
                        },

                        {
                            header: "Tanggal Selesai",
                            key: "tgl_selesai",
                            render: (value) => (
                                value
                                    ? formatIndonesianDate(value)
                                    : "-"
                            )
                        },

                        {
                            header: "Status",
                            key: "status",
                            render: (value) => {
                                const status = value?.toLowerCase()

                                if (status === "belum dibuka") {
                                    return (
                                        <span className="text-red-600 bg-red-100 border-red-500 text-sm px-2 py-1 border rounded">
                                            {value}
                                        </span>
                                    )
                                }

                                if (status === "terbuka") {
                                    return (
                                        <span className="text-blue-600 bg-blue-100 border-blue-500 text-sm px-2 py-1 border rounded">
                                            {value}
                                        </span>
                                    )
                                }

                                return (
                                    <span className="text-green-600 bg-green-100 border-green-500 text-sm px-2 py-1 border rounded">
                                        {value}
                                    </span>
                                )
                            }
                        },
                    ]}
                />
            </div>

            <AnimatePresence mode="wait">
                {editPeriodeModal && (
                    <FormPeriode
                        refresh={() => refreshTable()}
                        close={() => setEditPeriodeModal(false)}
                        isEdit={true}
                        data={tempRowData}
                        alertMsg={(msg) => setAlertMsg(msg)}
                        alertStatus={(stt) => setAlertStatus(stt)}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            {showAlert && (
                <Alert
                    msg={alertMsg}
                    onCancel={() => setShowAlert(false)}
                    alertType={alertStatus}
                />
            )}

            <ContextMenu
                contextMenu={contextMenu}
                closeMenu={closeMenu}
                menus={menus}
            />
        </div>
    )
}