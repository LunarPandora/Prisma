"use client"

import { useState } from "react"
import { AnimatePresence } from "framer-motion"

import Alert from "@/app/component/Alert/Alert"
import ContextMenu from "@/app/component/Context/ContextMenu"

import FormSkema from "./SkemaForm"

import { useUserStore } from "@/app/stores/useUserStore"
import { getModuleAccess } from "@/app/component/Libraries/utils/menu"

import { deleteSkema, getSkema } from "@/app/component/Libraries/api/skema"
import { useContextMenu } from "@/app/component/Libraries/hooks/useContextMenu"

import CustomTable from "@/app/component/Table/CustomTable"
import { createSkemaAdminMenus } from "@/app/component/Libraries/config/Skema/skemaAdminMenu"
import Periode from "./Periode/page"

export default function Skema() {
    const [selectedSkema, setSelectedSkema] = useState(null)

    if (selectedSkema) {
        return (
            <Periode
                skema={selectedSkema}
                onBack={() => setSelectedSkema(null)}
            />
        )
    }

    return (
        <SkemaView
            onSelectSkema={(row) => setSelectedSkema(row)}
        />
    )
}

function SkemaView({ onSelectSkema }){
    const [refreshKey, setRefreshKey] = useState(0)

    const [showAlert, setShowAlert] = useState(false)
    const [alertMsg, setAlertMsg] = useState("")
    const [alertStatus, setAlertStatus] = useState("success")

    const [addSkemaModal, setAddSkemaModal] = useState(false)
    const [editSkemaModal, setEditSkemaModal] = useState(false)
    const [removeSkemaModal, setRemoveSkemaModal] = useState(false)

    const [tempRowData, setTempRowData] = useState({})
    const [loadingForm, setLoadingForm] = useState(false)

    const user = useUserStore(state => state.user)
    const access = getModuleAccess("skema", user?.role)

    const { contextMenu, openMenu, closeMenu } = useContextMenu()

    const menus = createSkemaAdminMenus({
        access,
        refreshTable,
        handleAdd,
        handleEdit,
        handleDelete,
    })

    function refreshTable(){
        setRefreshKey(prev => prev + 1)
    }

    function handleAdd(){
        setAddSkemaModal(true)
    }

    function handleEdit(row){
        setTempRowData(row)
        setEditSkemaModal(true)
    }

    function handleDelete(row){
        setTempRowData(row)
        setRemoveSkemaModal(true)
    }

    async function removeSkema(){
        try{
            setLoadingForm(true)

            const formData = new FormData()
            formData.append('skema_id', tempRowData.skema_id)

            const res = await deleteSkema(formData)

            if(res.data.status === "success"){
                setAlertMsg("Sistem berhasil menghapus skema!")
                setAlertStatus("success")
            }
            else{
                setAlertMsg("Sistem gagal menghapus skema!")
                setAlertStatus("danger")
            }
        }
        catch(err){
            console.error(err)

            setAlertMsg("Sistem gagal menghapus skema dikarenakan error di sistem!")
            setAlertStatus("danger")
        }
        finally{
            setLoadingForm(false)
            refreshTable()
            setRemoveSkemaModal(false)
            setShowAlert(true)
        }
    }

    return (
        <div
            className="flex flex-col gap-5 min-h-screen"
            onContextMenu={(e) => openMenu(e)}
        >
            <div className="flex flex-col gap-5">

                <div className="flex flex-col gap-2">
                    <h1 className="text-4xl font-medium">
                        Skema Penelitian
                    </h1>

                    <p className="text-lg text-gray-500 font-light">
                        Kelola skema penelitian dan PkM yang tersedia.
                    </p>
                </div>

                <CustomTable
                    fetchMethod={getSkema}
                    refreshKey={refreshKey}
                    className="w-full"
                    roundedStyle="rounded-lg rounded-tl-none"
                    onContextRequest={(e, type, data, source) =>
                        openMenu(e, type, data, source)
                    }
                    onRowClick={(row) => {
                        onSelectSkema(row)
                    }}
                    columns={[
                        {
                            header: "Nama Skema",
                            key: "nama_skema"
                        },
                        {
                            header: "Tahun Ajaran",
                            key: "tahun_ajaran"
                        },
                        {
                            header: "Jumlah Periode",
                            key: "periode_count",
                            render: (value, row) => {
                                return (
                                    <span>
                                        {row.periode?.length ?? 0} Periode
                                    </span>
                                )
                            }
                        },
                        {
                            header: "Status",
                            key: "status",
                            render: (value) => {

                                const style = {
                                    Draft:
                                        "text-yellow-600 bg-yellow-100 border-yellow-500",
                                    Aktif:
                                        "text-blue-600 bg-blue-100 border-blue-500",
                                    Selesai:
                                        "text-green-600 bg-green-100 border-green-500",
                                }

                                return (
                                    <span
                                        className={`
                                            ${style[value]}
                                            text-sm
                                            px-2 py-1
                                            border
                                            rounded
                                        `}
                                    >
                                        {value}
                                    </span>
                                )
                            }
                        }
                    ]}
                />
            </div>

            <AnimatePresence mode="wait">
                {
                    addSkemaModal &&
                    <FormSkema
                        refresh={refreshTable}
                        close={() => setAddSkemaModal(false)}
                        isEdit={false}
                        data={{}}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                }
            </AnimatePresence>

            <AnimatePresence mode="wait">
                {
                    editSkemaModal &&
                    <FormSkema
                        refresh={refreshTable}
                        close={() => setEditSkemaModal(false)}
                        isEdit={true}
                        data={tempRowData}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                }
            </AnimatePresence>

            <AnimatePresence mode="wait">
                {
                    removeSkemaModal &&
                    <Alert
                        alertType="warning"
                        title="Hapus Skema"
                        msg="Apakah anda yakin ingin menghapus skema ini?"
                        onCancel={() => setRemoveSkemaModal(false)}
                        onAccept={removeSkema}
                        acceptText="Hapus"
                        isConfirmation={true}
                        withBackground={true}
                    />
                }
            </AnimatePresence>

            {
                showAlert &&
                <Alert
                    msg={alertMsg}
                    onCancel={() => setShowAlert(false)}
                    alertType={alertStatus}
                />
            }

            <ContextMenu
                contextMenu={contextMenu}
                closeMenu={closeMenu}
                menus={menus}
            />
        </div>
    )
}