"use client"

import { useState, useEffect } from "react"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import {
    faX,
    faBookOpen,
    faCalendar,
    faTag
} from "@fortawesome/free-solid-svg-icons"
import { AnimatePresence, motion } from "framer-motion"

import TextInput from "@/app/component/Inputs/TextInput"
import SelectInput from "@/app/component/Inputs/SelectInput"
import LoadingBar from "@/app/component/AppLoader/LoadingBar"

import { addSkema, updateSkema } from "@/app/component/Libraries/api/skema"
import { formatToPHPDate } from "@/app/component/Libraries/utils/date"

export default function FormSkema({
    refresh,
    close,
    data,
    isEdit,
    alertMsg,
    alertStatus,
    alertTrigger
}){
    const defaultForm = {
        nama_skema: "",
        tahun_ajaran: "",
        status: "Draft",
    }

    const [form, setForm] = useState(defaultForm)
    const [loadingForm, setLoadingForm] = useState(false)

    const MotionLoadingBar = motion.create(LoadingBar)

    const statusOptions = [
        {
            text: "Draft",
            value: "Draft"
        },
        {
            text: "Aktif",
            value: "Aktif"
        },
        {
            text: "Selesai",
            value: "Selesai"
        }
    ]

    useEffect(() => {
        if(isEdit && data){
            setForm(prev => ({
                ...prev,
                ...data
            }))
        }
        else{
            setForm(defaultForm)
        }
    }, [isEdit, data])

    const handleChange = (e) => {
        const { name, value } = e.target

        setForm(prev => ({
            ...prev,
            [name]: value
        }))
    }

    async function sendData(){
        try{
            setLoadingForm(true)

            const formData = new FormData()

            Object.entries(form).forEach(([key, value]) => {

                if(key === "tgl_mulai" || key === "tgl_selesai"){
                    value = value ? formatToPHPDate(value) : ""
                }

                formData.append(key, value)
            })

            if(isEdit){
                formData.append('skema_id', data.skema_id)
            }

            const res = isEdit
                ? await updateSkema(formData)
                : await addSkema(formData)

            if(res.data.status === "success"){
                alertMsg(
                    `Sistem berhasil ${
                        isEdit ? "mengupdate" : "menambahkan"
                    } data skema!`
                )

                alertStatus("success")
            }
            else{
                alertMsg(
                    `Sistem gagal ${
                        isEdit ? "mengupdate" : "menambahkan"
                    } data skema!`
                )

                alertStatus("danger")
            }
        }
        catch(err){
            console.error(err)

            alertMsg(
                `Sistem gagal ${
                    isEdit ? "mengupdate" : "menambahkan"
                } data skema dikarenakan error di sistem!`
            )

            alertStatus("danger")
        }
        finally{
            setTimeout(() => {
                setLoadingForm(false)
                refresh()
                close()
                alertTrigger()
            }, 300)
        }
    }

    return (
        <motion.div
            key="formModal"
            initial={{
                opacity: 0,
                scale: 1.05,
                filter: "blur(3px)"
            }}
            animate={{
                opacity: 1,
                scale: 1,
                filter: "blur(0)"
            }}
            exit={{
                opacity: 0,
                scale: 1.05,
                filter: "blur(3px)"
            }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 will-change-auto"
        >
            <AnimatePresence mode="wait">
                {
                    loadingForm
                    ?
                    (
                        <MotionLoadingBar />
                    )
                    :
                    (
                        <motion.div
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="w-1/2 bg-white p-5 rounded-xl flex flex-col gap-5"
                        >
                            <div className="flex w-full justify-between items-center">
                                <p className="font-medium text-xl">
                                    {
                                        isEdit
                                        ? "Update Skema"
                                        : "Tambah Skema Baru"
                                    }
                                </p>

                                <FontAwesomeIcon
                                    onClick={close}
                                    icon={faX}
                                    className="text-sm cursor-pointer"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-2">

                                <TextInput
                                    name="nama_skema"
                                    type="text"
                                    placeholder="Masukkan nama skema"
                                    icon={faBookOpen}
                                    value={form.nama_skema}
                                    onChange={handleChange}
                                    className="col-span-2"
                                />

                                <TextInput
                                    name="tahun_ajaran"
                                    type="text"
                                    placeholder="Masukkan tahun ajaran (Cth: 2026/2067)"
                                    icon={faCalendar}
                                    value={form.tahun_ajaran}
                                    onChange={handleChange}
                                />

                                <SelectInput
                                    name="status"
                                    value={form.status}
                                    onChange={handleChange}
                                    options={statusOptions}
                                    icon={faTag}
                                    placeholder="Pilih status skema"
                                />

                                <button
                                    onClick={sendData}
                                    className="bg-foreground/90 hover:bg-foreground text-white text-lg px-5 py-2 rounded-lg font-medium mt-1 transition-colors duration-300 ease-in-out cursor-pointer col-span-2"
                                >
                                    {
                                        isEdit
                                        ? "Update"
                                        : "Tambahkan"
                                    }
                                </button>

                            </div>
                        </motion.div>
                    )
                }
            </AnimatePresence>
        </motion.div>
    )
}