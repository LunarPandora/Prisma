"use client"

import { useState, useEffect } from "react"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX, faTable, faGraduationCap } from '@fortawesome/free-solid-svg-icons'
import { AnimatePresence, motion } from "framer-motion"

import TextInput from "@/app/component/Inputs/TextInput"
import SelectInput from "@/app/component/Inputs/SelectInput"
import LoadingBar from "@/app/component/AppLoader/LoadingBar"

import { addProdi, updateProdi } from "@/app/component/Libraries/api/prodi"
import { fetchUsers } from "@/app/component/Libraries/api/users"
import MultiQuestionEditor from "@/app/component/Inputs/MultiQuestionEditor"

export default function FormProdi({ refresh, close, data, isEdit, alertMsg, alertStatus, alertTrigger }){
    const defaultForm = {
        prodi_id: "",
        nama_prodi: "",
        kaprodi_id: "",
    }

    const [form, setForm] = useState(defaultForm)

    const [loadingForm, setLoadingForm] = useState(false)
    const MotionLoadingBar = motion.create(LoadingBar);

    useEffect(() => {
        if (isEdit && data) {
            setForm(prev => ({
                ...prev,
                ...data,
            }))
        } else {
            setForm(defaultForm)
        }
    }, [isEdit, data])

    const handleChange = (e) => {
        const { name, value } = e.target
        setForm(prev => ({
            ...prev,
            [name]: value,
        }))
    }

    async function sendData(){
        try{
            setLoadingForm(true)

            const formData = new FormData()
            Object.entries(form).forEach(([key, value]) => {
                if (value !== null && value !== undefined && value !== "" && value !== "-") {
                    if (typeof value === "object") {
                        formData.append(key, JSON.stringify(value))
                    }
                    else{
                        formData.append(key, value)
                    }
                }
            })

            const res = isEdit
                ? await updateProdi(formData)
                : await addProdi(formData)

            if (res.data.status == 'success'){ 
                alertMsg(`Sistem berhasil ${isEdit ? 'mengupdate' : 'menambahkan'} data prodi!`)
                alertStatus('success')
            }
            else {
                alertMsg(`Sistem gagal ${isEdit ? 'mengupdate' : 'menambahkan'} data prodi!`)
                alertStatus('danger')
            }
        }
        catch(err){
            alertMsg(`Sistem gagal ${isEdit ? 'mengupdate' : 'menambahkan'} data prodi dikarenakan error di sistem!`)
            alertStatus('danger')

            console.error(err)
        }
        finally{
            setTimeout(() => {
                setLoadingForm(false)
                refresh()
                close()
                alertTrigger()
            }, 300)
        }
    }

    return (
        <motion.div
            key="formModal"
            initial={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 will-change-auto"
        >
             <AnimatePresence mode="wait">
                { loadingForm ?
                    (
                        <MotionLoadingBar />
                    )
                    :
                    (
                        <motion.div
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="w-1/2 bg-white p-5 rounded-xl flex flex-col gap-5"
                        >
                            <div class="flex w-full justify-between items-center">
                                <p className="font-medium text-xl">{ isEdit ? 'Update Prodi' : 'Tambah Prodi Baru' }</p>
                                <FontAwesomeIcon onClick={close} icon={faX} className="text-sm" />
                            </div>

                            <div
                                key="form"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.2 }}
                                className="grid grid-cols-2 gap-2"
                            >
                                <TextInput
                                    name="nama_prodi" 
                                    type="text"
                                    placeholder="Masukkan nama prodi"
                                    icon={faTable}
                                    value={form.nama_prodi}
                                    onChange={handleChange}
                                    className="col-span-2"
                                />

                                <SelectInput
                                    name="kaprodi_id"
                                    value={form.kaprodi_id}
                                    onChange={handleChange}
                                    dataSource={fetchUsers}
                                    transform={(item) => ({
                                        text: item.nama,
                                        value: item.id
                                    })}
                                    icon={faGraduationCap}
                                    placeholder="Pilih kepala prodi"
                                    classSpan="col-span-2"
                                />

                                <button onClick={sendData} className="bg-foreground/90 hover:bg-foreground text-white text-lg px-5 py-2 rounded-lg font-medium mt-1 transition-colors duration-300 ease-in-out cursor-pointer col-span-2">
                                    { 
                                        isEdit ? 'Update' : 'Tambahkan'
                                    }
                                </button>
                            </div>
                        </motion.div>
                    )
                }
            </AnimatePresence>
        </motion.div>
    )
}