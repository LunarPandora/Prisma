"use client"

import Image from "next/image"
import { useEffect, useState } from "react"
import { AnimatePresence } from "framer-motion"

import { useUserStore } from "@/app/stores/useUserStore"
import { getModuleAccess } from "@/app/component/Libraries/utils/menu"

import CustomTable from "@/app/component/Table/CustomTable"
import ContextMenu from "@/app/component/Context/ContextMenu"
import Alert from "@/app/component/Alert/Alert"
import TextTag from "@/app/component/Tags/TextTag"

import { useContextMenu } from "@/app/component/Libraries/hooks/useContextMenu"
import { useQueryBuilder } from "@/app/component/Libraries/hooks/useQueryBuilder"
import { formatIndonesianDate } from "@/app/component/Libraries/utils/date"

import {
    getDana,
    approveClaimDana,
    confirmClaimDana,
    requestPengembalianDana,
    confirmPengembalianDana,
} from "@/app/component/Libraries/api/dana"

import { createDanaAdminMenus } from "@/app/component/Libraries/config/Dana/DanaAdminMenu"

/*
 * mode: "claim" | "pengembalian"
 */
export default function MonitoringDanaAdmin({ mode = "claim", skema, onBack }) {

    const qb = useQueryBuilder()
    const { contextMenu, openMenu, closeMenu } = useContextMenu()

    const [refreshKey, setRefreshKey] = useState(0)
    const [tempRow, setTempRow] = useState(null)

    const [showConfirmAlert, setShowConfirmAlert] = useState(false)
    const [confirmConfig, setConfirmConfig] = useState({
        title: "",
        msg: "",
        onAccept: null,
    })

    const [showAlert, setShowAlert] = useState(false)
    const [alertMsg, setAlertMsg] = useState('')
    const [alertStatus, setAlertStatus] = useState('success')

    const user = useUserStore(state => state.user)
    const access = getModuleAccess("admindana", user?.role) ||
        getModuleAccess("adminmonitoringpengajuan", user?.role)

    useEffect(() => {
        qb.addFilter("mode", mode)
        if (skema?.skema_id) qb.addFilter("skema_id", skema.skema_id)
    }, [mode, skema])

    const menus = createDanaAdminMenus({
        mode,
        access,
        refreshTable,
        handleApproveClaim,
        handleConfirmClaim,
        handleRequestPengembalian,
        handleConfirmPengembalian,
    })

    function refreshTable() {
        setRefreshKey(prev => prev + 1)
    }

    function showConfirm(title, msg, onAccept) {
        setConfirmConfig({ title, msg, onAccept })
        setShowConfirmAlert(true)
    }

    function showResult(res, successMsg, failMsg) {
        if (res.data?.status === "success") {
            setAlertMsg(successMsg)
            setAlertStatus("success")
        } else {
            setAlertMsg(res.data?.message || failMsg)
            setAlertStatus("error")
        }
        setShowAlert(true)
        refreshTable()
    }

    async function runAction(api, row, successMsg, failMsg) {
        try {
            const formData = new FormData()
            formData.append("laporan_id", row.laporan_id)
            const res = await api(formData)
            showResult(res, successMsg, failMsg)
        } catch (err) {
            console.error(err)
            setAlertMsg(failMsg)
            setAlertStatus("error")
            setShowAlert(true)
        } finally {
            setShowConfirmAlert(false)
        }
    }

    function handleApproveClaim(r) {
        setTempRow(r)
        showConfirm(
            "Approve Claim Dana",
            "Peneliti akan diminta mengunggah bukti transfer. Lanjutkan?",
            () => runAction(
                approveClaimDana, r,
                "Claim dana berhasil diapprove.",
                "Gagal approve claim dana."
            )
        )
    }

    function handleConfirmClaim(r) {
        setTempRow(r)
        showConfirm(
            "Konfirmasi Claim Dana",
            "Konfirmasi bahwa transfer telah diterima. Laporan akan lanjut ke tahap berikutnya.",
            () => runAction(
                confirmClaimDana, r,
                "Claim dana berhasil dikonfirmasi.",
                "Gagal konfirmasi claim dana."
            )
        )
    }

    function handleRequestPengembalian(r) {
        setTempRow(r)
        showConfirm(
            "Minta Pengembalian Dana",
            "Peneliti akan diminta mengunggah bukti pengembalian. Lanjutkan?",
            () => runAction(
                requestPengembalianDana, r,
                "Permintaan pengembalian berhasil dikirim.",
                "Gagal meminta pengembalian dana."
            )
        )
    }

    function handleConfirmPengembalian(r) {
        setTempRow(r)
        showConfirm(
            "Konfirmasi Pengembalian Dana",
            "Konfirmasi bahwa pengembalian telah diterima. Laporan akan lanjut ke tahap Diseminasi.",
            () => runAction(
                confirmPengembalianDana, r,
                "Pengembalian dana berhasil dikonfirmasi.",
                "Gagal konfirmasi pengembalian dana."
            )
        )
    }

    const isPengembalian = mode === "pengembalian"

    return (
        <div
            className="flex flex-col gap-5 min-h-screen"
            onContextMenu={(e) => openMenu(e)}
        >
            <div className="flex flex-col justify-between items-start gap-5">

                <div className="flex items-center gap-2 text-sm text-gray-500">
                    <button onClick={onBack} className="hover:text-black">
                        Monitoring Progress
                    </button>
                    <span>›</span>
                    <span>{skema?.nama_skema}</span>
                    <span>›</span>
                    <span className="font-medium text-black">
                        {isPengembalian ? "Pengembalian Dana" : "Claim Dana"}
                    </span>
                </div>

                <div className="flex flex-col gap-2">
                    <h1 className="text-4xl font-medium">
                        {isPengembalian ? "Pengembalian Dana" : "Claim Dana"}
                    </h1>
                    <p className="text-lg text-gray-500 font-light">
                        {isPengembalian
                            ? "Kelola pengembalian dana dari peneliti PkM."
                            : "Kelola claim pembiayaan penelitian dari peneliti."
                        }
                    </p>
                </div>

                <CustomTable
                    fetchMethod={getDana}
                    searchQuery={qb.toQueryString()}
                    refreshKey={refreshKey}
                    className="w-full"
                    onContextRequest={(e, type, data, source) =>
                        openMenu(e, type, data, source)
                    }
                    columns={[
                        {
                            header: "Judul",
                            key: "judul_penelitian",
                            width: "25%",
                            render: (value, row) => (
                                <div className="flex items-center gap-2">
                                    <TextTag
                                        color={row.semester === "Ganjil" ? "#C4161C" : "#0197CA"}
                                        size="text-xs"
                                    >
                                        {row.semester}
                                    </TextTag>
                                    <p className="text-sm line-clamp-2">{value}</p>
                                </div>
                            )
                        },
                        {
                            header: "Ketua",
                            key: "ketua",
                            render: (value, row) => (
                                <div className="flex items-center gap-2 text-xs">
                                    {row.proposal?.user?.avatar_url &&
                                        <Image
                                            src={row.proposal.user.avatar_url}
                                            alt={row.proposal.user.nama}
                                            width={25}
                                            height={25}
                                            className="rounded-full"
                                            unoptimized
                                        />
                                    }
                                    <span>{row.proposal?.user?.nama}</span>
                                </div>
                            )
                        },
                        {
                            header: "Tahap",
                            key: "periode",
                            render: (value) => value?.nama_periode || "-"
                        },
                        {
                            header: "Status",
                            key: isPengembalian
                                ? "pengembalian_dana_status"
                                : "claim_dana_status",
                            render: (value) => {

                                if (!value) {
                                    return (
                                        <span className="text-sm italic text-gray-500">
                                            Belum diproses
                                        </span>
                                    )
                                }

                                const style = {
                                    'Menunggu bukti transfer': 'text-yellow-600 bg-yellow-100 border-yellow-500',
                                    'Menunggu konfirmasi admin': 'text-blue-600 bg-blue-100 border-blue-500',
                                    'Menunggu Pengembalian Dana': 'text-yellow-600 bg-yellow-100 border-yellow-500',
                                    'Selesai': 'text-green-600 bg-green-100 border-green-500',
                                }[value] || 'text-gray-600 bg-gray-100 border-gray-600'

                                return (
                                    <span className={`${style} text-xs px-2 py-1 border rounded`}>
                                        {value}
                                    </span>
                                )
                            }
                        },
                        {
                            header: "Bukti Transfer",
                            key: "dokumen",
                            render: (value) => {

                                const jenis = isPengembalian
                                    ? "Bukti Transfer Pengembalian"
                                    : "Bukti Transfer Claim"

                                const doc = (value || []).find(
                                    d => d.jenis_dokumen === jenis
                                )

                                if (!doc?.currentVersion?.drive_file_url) {
                                    return (
                                        <span className="text-sm italic text-gray-500">
                                            Belum diupload
                                        </span>
                                    )
                                }

                                return (
                                    <a
                                        href={doc.currentVersion.drive_file_url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-sm text-blue-600 hover:underline"
                                    >
                                        Lihat bukti
                                    </a>
                                )
                            }
                        },
                    ]}
                />

            </div>

            <AnimatePresence>
                {showConfirmAlert && (
                    <Alert
                        alertType="warning"
                        title={confirmConfig.title}
                        msg={confirmConfig.msg}
                        onCancel={() => setShowConfirmAlert(false)}
                        onAccept={confirmConfig.onAccept}
                        acceptText="Konfirmasi"
                        isConfirmation={true}
                        withBackground={true}
                    />
                )}
            </AnimatePresence>

            {showAlert &&
                <Alert
                    msg={alertMsg}
                    onCancel={() => setShowAlert(false)}
                    alertType={alertStatus}
                />
            }

            <ContextMenu
                contextMenu={contextMenu}
                closeMenu={closeMenu}
                menus={menus}
            />
        </div>
    )
}
