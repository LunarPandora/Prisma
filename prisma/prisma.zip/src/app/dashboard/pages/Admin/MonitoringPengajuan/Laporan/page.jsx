export default function Laporan(){
    return (
        <div>laporan</div>
    )
}