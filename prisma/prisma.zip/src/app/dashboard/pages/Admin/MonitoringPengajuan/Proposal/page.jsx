import Image from "next/image";
import { useEffect, useState } from "react";
import { faCheck, faFile, faQuestion, faX } from "@fortawesome/free-solid-svg-icons";
import { useUserStore } from "@/app/stores/useUserStore";

import { getModuleAccess } from "@/app/component/Libraries/utils/menu";

import { getProposal } from "@/app/component/Libraries/api/proposal";
import { useQueryBuilder } from "@/app/component/Libraries/hooks/useQueryBuilder";

import CustomTable from "@/app/component/Table/CustomTable";
import { formatIndonesianDate } from "@/app/component/Libraries/utils/date";
import TextInput from "@/app/component/Inputs/TextInput";
import { useContextMenu } from "@/app/component/Libraries/hooks/useContextMenu";
import ContextMenu from "@/app/component/Context/ContextMenu";
import { createProposalAdminMenus } from "@/app/component/Libraries/config/Proposal/proposalAdminMenu";
import { AnimatePresence } from "framer-motion";
import FormPenugasanReviewer from "./PenugasanReviewerForm";
import Alert from "@/app/component/Alert/Alert";
import FormPenolakanPengajuan from "./PenolakanPengajuanForm";
import FormProposalViewAdmin from "./ProposalViewForm";
import TextTag from "@/app/component/Tags/TextTag";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import FormHasilReview from "./HasilReviewForm";
import PengumumanSkPanel from "./PengumumanSkPanel";

export default function Proposal({ skema, onBack }){
    const defaultForm = {
        search: "",
    }

    const qb = useQueryBuilder()
    const [qs, setQs] = useState('')

    const { contextMenu, openMenu, closeMenu } = useContextMenu()
    const [form, setForm] = useState(defaultForm)

    const [refreshKey, setRefreshKey] = useState(0)
    const [showProposalViewModal, setShowProposalViewModal] = useState(false)
    const [showHasilReviewModal, setShowHasilReviewModal] = useState(false)
    const [addPenugasanModal, setAddPenugasanModal] = useState(false)
    const [removeProposalModal, setRemoveProposalModal] = useState(false)
    const [tempRowData, setTempRowData] = useState({})

    const [showAlert, setShowAlert] = useState(false)
    const [alertMsg, setAlertMsg] = useState('')
    const [alertStatus, setAlertStatus] = useState('success')
    const [loadingForm, setLoadingForm] = useState(false)

    const tabs = [
        {
            label: "Pengajuan",
            value: "PENERIMAAN_PROPOSAL"
        },
        {
            label: "Seleksi",
            value: "SELEKSI_PROPOSAL"
        },
        {
            label: "Pengumuman",
            value: "PENGUMUMAN_SK"
        }
    ]

    const [activeTab, setActiveTab] =
        useState("PENERIMAAN_PROPOSAL")

    const user = useUserStore(state => state.user)
    const access = getModuleAccess("adminmonitoringprogress", user?.role)

    const statusStyles = {
        'menunggu penugasan reviewer': 'text-blue-600 bg-blue-100 border-blue-500',
        'menunggu review': 'text-yellow-600 bg-yellow-100 border-yellow-500',
        'dalam pengerjaan': 'text-purple-600 bg-purple-100 border-purple-500',
        'ditolak': 'text-red-600 bg-red-100 border-red-500',
        default: 'text-gray-600 bg-gray-100 border-gray-600'
    }

    const statusReviewStyles = {
        'belum direview': {icon: faX, color: 'text-red-600'},
        'telah direview': {icon: faCheck, color: 'text-green-600'},
        default: {icon: faQuestion, color: 'text-blue-600'}
    }

    const menus = createProposalAdminMenus({
        user,
        access,
        refreshTable,
        handleShow,
        handleTolak,
        handleCheckReview,
    })

    function handleShow(r){
        setShowProposalViewModal(true)
        setTempRowData(r)
    }

    function handleCheckReview(r){
        setShowHasilReviewModal(true)
        setTempRowData(r)
    }
    
    function handlePenugasan(r){
        setAddPenugasanModal(true)
        setTempRowData(r)
    }

    function handleTolak(r){
        setRemoveProposalModal(true)
        setTempRowData(r)
    }

    function refreshTable() {
        setRefreshKey(prev => prev + 1)
    }

    function closeAllModal(){
        setAddPenugasanModal(false)
        setShowProposalViewModal(false)
        setRemoveProposalModal(false)
    }

    const handleChange = (e, type) => {
        const { name, value } = e.target

        setForm(prev => ({
            ...prev,
            [name]: value,
        }))

        switch(type){
            case "search":
                qb.setSearch(value)
                break

            case "filter":
                qb.addFilter(name, value)
                break
        }

        setQs(qb.toQueryString())
    }

    useEffect(() => {
        qb.addFilter("kode_periode", activeTab)
        setQs(qb.toQueryString())
    }, [activeTab])

    return (
        <div 
            className="flex flex-col gap-5 min-h-screen"
            onContextMenu={(e) => openMenu(e)}
        >
            <div className="flex flex-col justify-between items-start gap-5">
                <div className="flex items-center gap-2 text-sm text-gray-500">
                    <button
                        onClick={onBack}
                        className="hover:text-black"
                    >
                        Monitoring Progress
                    </button>
                    <span>›</span>
                    <span>{skema.nama_skema}</span>
                    <span>›</span>
                    <span className="font-medium text-black">
                        Monitoring Progress Proposal
                    </span>
                </div>

                <div className="flex flex-col gap-2">
                    <h1 className="text-4xl font-medium">Monitoring Progress Proposal</h1>
                    <p className="text-lg text-gray-500 font-light">Cek progress pengajuan proposal dari dosen disini.</p>
                </div>

                <div className="bg-white rounded-lg p-3 w-full flex items-end gap-2">
                    <div className="w-1/4">
                        <TextInput
                            name="search" 
                            type="text"
                            placeholder="Cari dosen, judul penelitian, dsb..."
                            icon={faFile}
                            value={form.search}
                            onChange={(e) => handleChange(e, 'search')}
                        />
                    </div>
                </div>

                <div className="flex gap-2 bg-white p-2 rounded-lg shadow border w-fit">
                    {tabs.map(tab => (
                        <button
                            key={tab.value}
                            onClick={() => setActiveTab(tab.value)}
                            className={`
                                px-4 py-2 rounded-md text-sm transition-all
                                ${
                                    activeTab === tab.value
                                        ? "bg-foreground text-background"
                                        : "hover:bg-gray-100"
                                }
                            `}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>

                {
                    activeTab === "PENGUMUMAN_SK" &&
                    <PengumumanSkPanel
                        skema={skema}
                        refreshTable={refreshTable}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                }

                <CustomTable
                    fetchMethod={getProposal}
                    searchQuery={qs}
                    refreshKey={refreshKey}
                    className="w-full"
                    roundedStyle="rounded-lg rounded-tl-none"
                    onContextRequest={(e, type, data, source) => openMenu(e, type, data, source)}
                    columns={[  
                        { 
                            header: "Rencana Judul",
                            key: "judul", 
                            width: "20%",
                            render: (value, row) => {
                                return (
                                    <div className="flex flex-col gap-1">
                                        <div className="flex items-center gap-2">
                                            <TextTag color="#C4161C" size="text-xs">Ganjil</TextTag>
                                            <div className="relative w-full">
                                                <p className="text-sm line-clamp-1 peer">{ row.rencana_judul_publikasi_gan }</p>

                                                <span className="absolute opacity-0 top-5 w-fit text-xs bg-white drop-shadow-sm border border-gray-300 px-2 py-1 rounded-lg z-10 transition-all duration-200 ease-in-out translate-y-8 peer-hover:opacity-100 peer-hover:translate-y-0">
                                                    <p className="w-full">{ row.rencana_judul_publikasi_gan }</p>
                                                </span>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <TextTag color="#0197CA" size="text-xs">Genap</TextTag>
                                            <div className="relative w-full">
                                                <p className="text-sm line-clamp-1 peer">{ row.rencana_judul_publikasi_gen }</p>

                                                <span className="absolute opacity-0 top-5 w-fit text-xs bg-white drop-shadow-sm border border-gray-300 px-2 py-1 rounded-lg z-10 transition-all duration-200 ease-in-out translate-y-8 peer-hover:opacity-100 peer-hover:translate-y-0">
                                                    <p className="w-full">{ row.rencana_judul_publikasi_gen }</p>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                )
                            }
                        },
                        { header: "Tgl Pengajuan", key: "tgl_pengajuan", render: (value) => { return formatIndonesianDate(value) } },
                        {
                            header: "Ketua Peneliti", 
                            key: "nama",
                            width: "15%",
                            render: (value, row) => {
                                return (
                                    <span className="relative w-full">
                                        <div className="flex items-center gap-2 text-xs peer">
                                            <Image
                                                src={`${row.dosen.avatar_url}`}
                                                alt={row.dosen.nama}
                                                width={25}
                                                height={25}
                                                className="relative rounded-full peer"
                                                unoptimized
                                            />
                                            <p className="peer truncate">{row.dosen.nama}</p>
                                        </div>
                                        
                                        <span className="absolute -top-7 bg-white shadow-lg opacity-0 peer-hover:opacity-100 rounded-md text-black text-xs px-2 py-1 transition-opacity duration-200 ease-in-out text-nowrap">{row.dosen.nama}</span>
                                    </span>
                                )
                            }
                        },
                        {
                            header: "Reviewer", 
                            key: "nama",
                            width: "20%",
                            render: (value, row) => {
                                if(row.penugasan.length > 0){
                                    return (
                                        <div className="grid grid-cols-1 gap-1">
                                            {
                                                row.penugasan.map((p, i) => {
                                                    const isActive = p.status_review.toLowerCase()
                                                    const style = statusReviewStyles[isActive] || statusReviewStyles.default

                                                    return ( 
                                                        <span className="relative" key={i}>
                                                            <div className="flex items-center gap-2 text-xs peer">
                                                                <Image
                                                                    src={`${p.reviewer?.avatar_url}`}
                                                                    alt={p.reviewer?.nama}
                                                                    width={25}
                                                                    height={25}
                                                                    className="relative rounded-full peer"
                                                                    unoptimized
                                                                />
                                                                <p className="peer truncate">{p.reviewer?.nama}</p>

                                                                <FontAwesomeIcon icon={style.icon} className={`${style.color} text-xs`} />
                                                            </div>
                                                        
                                                            <span className="absolute -top-7 bg-white shadow-lg opacity-0 peer-hover:opacity-100 rounded-md text-black text-xs px-2 py-1 transition-opacity duration-200 ease-in-out">{p.reviewer?.nama}</span>
                                                        </span>
                                                    )
                                                })
                                            }
                                        </div>
                                    )
                                }
                                else{
                                    return (
                                        <span className="text-sm italic text-gray-500">Belum ada reviewer yang ditugaskan.</span>
                                    )
                                }
                            }
                        },
                        { 
                            header: "Status", 
                            key: "status",
                            render: (value, row) => {
                                const isActive = value.toLowerCase()
                                const style = statusStyles[isActive] || statusStyles.default
        
                                return (
                                    <span className={`${style} text-xs text-nowrap px-2 py-1 border rounded`}>
                                        { value }
                                    </span>
                                )
                            }
                        },
                    ]}
                />
            </div>

            <AnimatePresence>
                {showProposalViewModal && (
                    <FormProposalViewAdmin
                        close={(x) => x == 'all' ? closeAllModal() : setShowProposalViewModal(false)}
                        data={tempRowData}
                        triggerPenugasan={(d) => handlePenugasan(d)}
                        triggerTolak={(d) => handleTolak(d)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {showHasilReviewModal && (
                    <FormHasilReview
                        refresh={() => refreshTable()}
                        close={(x) => x == 'all' ? closeAllModal() : setShowHasilReviewModal(false)}
                        data={tempRowData}
                        triggerTolak={(d) => handleTolak(d)}
                        alertMsg={(msg) => setAlertMsg(msg)}
                        alertStatus={(stt) => setAlertStatus(stt)}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {addPenugasanModal && (
                    <FormPenugasanReviewer
                        refresh={() => refreshTable()}
                        close={(x) => x == 'all' ? closeAllModal() : setAddPenugasanModal(false)}
                        data={tempRowData}
                        alertMsg={(msg) => setAlertMsg(msg)}
                        alertStatus={(stt) => setAlertStatus(stt)}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {removeProposalModal && 
                    <FormPenolakanPengajuan
                        refresh={() => refreshTable()}
                        close={(x) => x == 'all' ? closeAllModal() : setRemoveProposalModal(false)}
                        data={tempRowData}
                        alertMsg={(msg) => setAlertMsg(msg)}
                        alertStatus={(stt) => setAlertStatus(stt)}
                        alertTrigger={() => setShowAlert(true)}
                    />
                }
            </AnimatePresence>

            { showAlert && 
                <Alert
                    msg={alertMsg} 
                    onCancel={() => setShowAlert(false)} 
                    alertType={alertStatus}
                /> 
            }

            <ContextMenu
                contextMenu={contextMenu}
                closeMenu={closeMenu}
                menus={menus}
            />
        </div>
    )
}