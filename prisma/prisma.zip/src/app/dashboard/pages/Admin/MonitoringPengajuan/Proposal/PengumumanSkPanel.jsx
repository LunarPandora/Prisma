"use client"

import { useEffect, useRef, useState } from "react"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import {
    faDownload,
    faFileWord,
    faFilePdf,
    faSpinner,
    faUpload,
} from "@fortawesome/free-solid-svg-icons"

import Button from "@/app/component/Inputs/Button"
import SelectInput from "@/app/component/Inputs/SelectInput"

import {
    fetchPengumumanSk,
    generatePengumumanSk,
    uploadPengumumanSk,
} from "@/app/component/Libraries/api/proposal"

import {
    isValidPDF,
    isPDFExceedSizeLimit,
} from "@/app/component/Libraries/utils/pdfPreview"

const jenisOptions = [
    {
        text: "Penelitian",
        value: "Penelitian",
    },
    {
        text: "PkM",
        value: "PkM",
    },
]

export default function PengumumanSkPanel({
    skema,
    refreshTable,

    alertMsg,
    alertStatus,
    alertTrigger,
}) {
    const [jenis, setJenis] = useState("Penelitian")

    const [periode, setPeriode] = useState(null)
    const [dokumen, setDokumen] = useState([])

    const [loadingGenerate, setLoadingGenerate] = useState(false)
    const [loadingUpload, setLoadingUpload] = useState(false)

    const fileInputRef = useRef(null)

    const pengumuman = dokumen.find(
        (d) => d.jenis_dokumen === "Pengumuman SK"
    )

    const skResmi = dokumen.find(
        (d) => d.jenis_dokumen === "SK Resmi"
    )

    async function loadData() {
        try {
            const res = await fetchPengumumanSk(
                `skema_id=${skema.skema_id}&jenis_penelitian=${jenis}`
            )

            if (res.data.status === "success") {
                setPeriode(res.data.data.periode)
                setDokumen(res.data.data.dokumen || [])
            }
        }
        catch (err) {
            console.error(err)
        }
    }

    useEffect(() => {
        loadData()
    }, [jenis])

    async function handleGenerate() {
        try {
            setLoadingGenerate(true)

            const formData = new FormData()
            formData.append("skema_id", skema.skema_id)
            formData.append("jenis_penelitian", jenis)

            const res = await generatePengumumanSk(formData)

            if (res.data.status === "success") {
                alertMsg("Pengumuman SK berhasil digenerate.")
                alertStatus("success")
            } else {
                alertMsg(res.data.message || "Gagal generate Pengumuman SK.")
                alertStatus("error")
            }
        }
        catch (err) {
            console.error(err)

            alertMsg("Gagal generate Pengumuman SK.")
            alertStatus("error")
        }
        finally {
            setLoadingGenerate(false)
            alertTrigger()
            loadData()
        }
    }

    async function handleUpload(e) {
        const file = e.target.files[0]

        if (!file) return

        if (!isValidPDF(file)) {
            alertMsg("Hanya file PDF yang diperbolehkan!")
            alertStatus("error")
            alertTrigger()
            return
        }

        if (isPDFExceedSizeLimit(file)) {
            alertMsg("Ukuran file melebihi batas 10MB!")
            alertStatus("error")
            alertTrigger()
            return
        }

        try {
            setLoadingUpload(true)

            const formData = new FormData()
            formData.append("skema_id", skema.skema_id)
            formData.append("jenis_penelitian", jenis)
            formData.append("uploaded_file", file)

            const res = await uploadPengumumanSk(formData)

            if (res.data.status === "success") {
                alertMsg(
                    "SK resmi berhasil diupload. "
                    + "Periode penelitian semester ganjil telah dibuka."
                )
                alertStatus("success")
            } else {
                alertMsg(res.data.message || "Gagal mengupload SK.")
                alertStatus("error")
            }
        }
        catch (err) {
            console.error(err)

            alertMsg("Gagal mengupload SK.")
            alertStatus("error")
        }
        finally {
            setLoadingUpload(false)
            alertTrigger()

            if (fileInputRef.current) {
                fileInputRef.current.value = ""
            }

            loadData()
            refreshTable()
        }
    }

    return (
        <div className="flex flex-col gap-y-3 w-full border border-gray-300 rounded-md p-5 bg-white">

            <div className="flex justify-between items-center gap-3">

                <div className="flex flex-col">
                    <span className="text-gray-600 text-lg font-medium">
                        Pengumuman SK
                    </span>

                    <span className="text-sm text-gray-500 font-light">
                        Generate pengumuman hasil seleksi, lalu upload SK
                        resmi untuk membuka periode penelitian.
                        {periode &&
                            ` Status periode: ${periode.status}.`
                        }
                    </span>
                </div>

                <div className="w-48">
                    <SelectInput
                        value={jenis}
                        onChange={(e) => setJenis(e.target.value)}
                        options={jenisOptions}
                        placeholder="Jenis"
                    />
                </div>

            </div>

            <div className="flex flex-wrap items-center gap-3">

                <Button
                    onClick={handleGenerate}
                    disabled={loadingGenerate}
                >
                    <FontAwesomeIcon
                        icon={loadingGenerate ? faSpinner : faFileWord}
                        className={`mr-2 ${loadingGenerate ? "animate-spin" : ""}`}
                    />
                    Generate Pengumuman SK
                </Button>

                {pengumuman?.file_url &&
                    <a
                        href={pengumuman.file_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-sm text-blue-600 hover:underline"
                    >
                        <FontAwesomeIcon icon={faDownload} />
                        {pengumuman.nama_file}
                    </a>
                }

            </div>

            <div className="flex flex-wrap items-center gap-3">

                <input
                    type="file"
                    accept="application/pdf"
                    ref={fileInputRef}
                    onChange={handleUpload}
                    className="hidden"
                />

                <Button
                    onClick={() => fileInputRef.current?.click()}
                    disabled={loadingUpload}
                >
                    <FontAwesomeIcon
                        icon={loadingUpload ? faSpinner : faUpload}
                        className={`mr-2 ${loadingUpload ? "animate-spin" : ""}`}
                    />
                    Upload SK Resmi (PDF)
                </Button>

                {skResmi?.file_url &&
                    <a
                        href={skResmi.file_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-sm text-blue-600 hover:underline"
                    >
                        <FontAwesomeIcon icon={faFilePdf} />
                        {skResmi.nama_file}
                    </a>
                }

            </div>

        </div>
    )
}
