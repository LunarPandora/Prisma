"use client"

import Image from "next/image"
import { useEffect, useState } from "react"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX, faUser } from '@fortawesome/free-solid-svg-icons'
import { AnimatePresence, motion } from "framer-motion"

import LoadingBar from "@/app/component/AppLoader/LoadingBar"

import { useUserStore } from "@/app/stores/useUserStore";
import SelectInputMulti from "@/app/component/Inputs/SelectInputMulti"
import { fetchReviewer } from "@/app/component/Libraries/api/reviewer"
import UserTag from "@/app/component/Tags/UserTag"
import { assignReviewer, confirmAssignment } from "@/app/component/Libraries/api/penugasan"
import Button from "@/app/component/Inputs/Button"

export default function FormPenugasanReviewer({ refresh, close, alertMsg, alertStatus, alertTrigger, data }){
    const [selected, setSelected] = useState([])
    const [initialSelected, setInitialSelected] = useState([])

    const [loadingForm, setLoadingForm] = useState(false)

    const user = useUserStore(state => state.user)
    const MotionLoadingBar = motion.create(LoadingBar);

    const addToSelection = (x) => {
        setSelected(prev => [...prev, x])
    }

    const removeFromSelection = (id) => {
        setSelected(prev => prev.filter(item => item.reviewer_id !== id))
    }

    async function setReviewer(){
        try{
            setLoadingForm(true)

            const formData = new FormData()
            let reviewers = []

            selected.map((val, i) => {
                reviewers.push(val.reviewer_id)
            })

            formData.append('proposal_id', data.proposal_id)

            /*
            |--------------------------------------------------------------------------
            | Diseminasi (Laporan) support: send morph fields when caller
            | passed reviewable_type / reviewable_id (e.g. Diseminasi page).
            |--------------------------------------------------------------------------
            */

            if (data.reviewable_type) {
                formData.append('reviewable_type', data.reviewable_type)
                formData.append('reviewable_id', data.reviewable_id)
            }

            reviewers.forEach(id => formData.append('reviewer_id[]', id))

            const res = await assignReviewer(formData)

            if (res.data.status == 'success'){ 
                alertMsg(`Sistem berhasil menyimpan draft reviewer untuk proposal!`)
                alertStatus('success')
            }
            else {
                alertMsg(`Sistem gagal menyimpan draft reviewer untuk proposal!`)
                alertStatus('danger')
            }
        }
        catch(err){
            alertMsg(`Sistem gagal menyimpan draft reviewer untuk proposal dikarenakan error di sistem!`)
            alertStatus('danger')

            console.error(err)
        }
        finally{
            setTimeout(() => {
                setLoadingForm(false)
                refresh()
                close('all')
                alertTrigger()
            }, 300)
        }
    }

    async function confirmPenugasan(){
        try{
            setLoadingForm(true)

            const formData = new FormData()
            formData.append('proposal_id', data.proposal_id)
            const res = await confirmAssignment(formData)

            if (res.data.status == 'success'){ 
                alertMsg(`Sistem berhasil menugaskan reviewer untuk proposal!`)
                alertStatus('success')
            }
            else {
                alertMsg(`Sistem gagal menugaskan reviewer untuk proposal!`)
                alertStatus('danger')
            }
        }
        catch(err){
            alertMsg(`Sistem gagal menugaskan reviewer untuk proposal dikarenakan error di sistem!`)
            alertStatus('danger')

            console.error(err)
        }
        finally{
            setTimeout(() => {
                setLoadingForm(false)
                refresh()
                close('all')
                alertTrigger()
            }, 300)
        }
    }

    useEffect(() => {
        if (!data?.penugasan) return

        const reviewers = data.penugasan.map(val => ({
            reviewer_id: val.reviewer.id,
            nama: val.reviewer.nama,
            avatar: val.reviewer.avatar_url
        }))

        setSelected(reviewers)
        setInitialSelected(reviewers)
    }, [data])

    const hasChanges = () => {
        const current = selected.map(i => i.reviewer_id).sort()
        const initial = initialSelected.map(i => i.reviewer_id).sort()

        if (current.length !== initial.length) return true

        return current.some((val, i) => val !== initial[i])
    }

    return (
        <motion.div
            key="formModal"
            initial={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 will-change-auto"
        >
             <AnimatePresence mode="wait">
                { loadingForm ?
                    (
                        <MotionLoadingBar />
                    )
                    :
                    (
                        <motion.div
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="w-1/2 bg-white p-5 rounded-xl flex flex-col gap-5"
                        >
                            <div class="flex w-full justify-between items-center">
                                <p className="font-medium text-xl">Penugasan Reviewer</p>
                                <FontAwesomeIcon onClick={() => close('this')} icon={faX} className="text-sm" />
                            </div>

                            <div
                                key="form_penugasan"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.2 }}
                                className="flex flex-col gap-3"
                            >
                                <div className="flex flex-col gap-3">
                                    <div className="w-full grid grid-cols-1 gap-x-2 gap-y-4 h-fit">
                                        <SelectInputMulti
                                            icon={faUser}
                                            dataSource={fetchReviewer}
                                            placeholder="Pilih reviewer yang ingin ditugaskan"
                                            selectedValues={selected.map(i => i.reviewer_id)}
                                            transform={(item) => ({
                                                text: item.nama,
                                                value: item.reviewer_id
                                            })}
                                            onSelect={({ mapped, raw }) => {
                                                if(selected.find((item) => item.reviewer_id == raw.reviewer_id)){
                                                    removeFromSelection(raw.reviewer_id)
                                                }
                                                else{
                                                    addToSelection(raw)
                                                }
                                            }}
                                            before={(raw) => (
                                                <Image
                                                    src={`${raw.avatar}`}
                                                    width={20}
                                                    height={20}
                                                    className="relative rounded-full"
                                                    alt={raw.nama || ""}
                                                    unoptimized
                                                />
                                            )}
                                        />
                                        <div className="flex gap-2 items-center">
                                            { 
                                                selected.map((val, i) => (
                                                    <UserTag 
                                                        img={val.avatar}
                                                        name={val.nama}
                                                        onRemove={() => removeFromSelection(val.reviewer_id)} 
                                                        key={val.reviewer_id}
                                                        readOnly={true}
                                                    />
                                                )) 
                                            }
                                        </div>
                                    </div>
                                </div>

                                <div className="w-full grid grid-cols-3 gap-2">
                                    <Button onClick={() => close('this')} variant="secondary">
                                        Kembali
                                    </Button> 
                                    <Button onClick={() => setReviewer()} variant="secondary" disabled={!hasChanges()}>
                                        Simpan sebagai draft
                                    </Button> 
                                    <Button onClick={() => confirmPenugasan()}>
                                        Submit penugasan
                                    </Button>
                                </div>
                            </div>
                        </motion.div>
                    )
                }
            </AnimatePresence>
        </motion.div>
    )
}