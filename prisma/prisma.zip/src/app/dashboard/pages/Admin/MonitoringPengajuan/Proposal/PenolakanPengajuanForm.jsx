"use client"

import Image from "next/image"
import { useEffect, useState } from "react"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX, faUser, faEdit } from '@fortawesome/free-solid-svg-icons'
import { AnimatePresence, motion } from "framer-motion"

import LoadingBar from "@/app/component/AppLoader/LoadingBar"

import { useUserStore } from "@/app/stores/useUserStore";
import SelectInputMulti from "@/app/component/Inputs/SelectInputMulti"
import { fetchReviewer } from "@/app/component/Libraries/api/reviewer"
import UserTag from "@/app/component/Tags/UserTag"
import { assignReviewer, confirmAssignment } from "@/app/component/Libraries/api/penugasan"
import { deleteProposal } from "@/app/component/Libraries/api/proposal"
import TextInput from "@/app/component/Inputs/TextInput"

export default function FormPenolakanPengajuan({ refresh, close, alertMsg, alertStatus, alertTrigger, data }){
    const defaultForm = {
        catatan: ""
    }

    const [form, setForm] = useState(defaultForm)
    const [loadingForm, setLoadingForm] = useState(false)

    const user = useUserStore(state => state.user)
    const MotionLoadingBar = motion.create(LoadingBar);

    const handleChange = (e) => {
        const { name, value } = e.target
        setForm(prev => ({
            ...prev,
            [name]: value,
        }))
    }

    async function rejectPengajuan(){
        try{
            setLoadingForm(true)

            const formData = new FormData()
            formData.append('proposal_id', data.proposal_id)

            Object.entries(form).forEach(([key, value]) => {
                if (value !== null && value !== undefined && value !== "" && value !== "-") {
                    formData.append(key, value)
                }
            })

            const res = await deleteProposal(formData)

            if (res.data.status == 'success'){ 
                alertMsg(`Sistem berhasil menolak pengajuan proposal!`)
                alertStatus('success')
            }
            else {
                alertMsg(`Sistem gagal menolak pengajuan proposal!`)
                alertStatus('danger')
            }
        }
        catch(err){
            alertMsg(`Sistem gagal menolak pengajuan proposal dikarenakan error di sistem!`)
            alertStatus('danger')

            console.error(err)
        }
        finally{
            setTimeout(() => {
                setLoadingForm(false)
                refresh()
                close('all')
                alertTrigger()
            }, 300)
        }
    }

    return (
        <motion.div
            key="formModal"
            initial={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 will-change-auto"
        >
             <AnimatePresence mode="wait">
                { loadingForm ?
                    (
                        <MotionLoadingBar />
                    )
                    :
                    (
                        <motion.div
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="w-1/2 bg-white p-5 rounded-xl flex flex-col gap-5"
                        >
                            <div class="flex w-full justify-between items-center">
                                <p className="font-medium text-xl">Penolakan Proposal</p>
                                <FontAwesomeIcon onClick={() => close('this')} icon={faX} className="text-sm" />
                            </div>

                            <div
                                key="form_penugasan"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.2 }}
                                className="flex flex-col gap-3"
                            >
                                <div className="flex flex-col gap-3">
                                    <div className="w-full grid grid-cols-1 gap-x-2 gap-y-4 h-fit">
                                        <TextInput
                                            name="catatan" 
                                            type="text"
                                            placeholder="Jelaskan alasan penolakan"
                                            icon={faEdit}
                                            value={form.catatan}
                                            onChange={handleChange}
                                        />
                                    </div>
                                </div>

                                <div className="w-full grid grid-cols-2 gap-2">
                                    <button onClick={() => close('this')} className="bg-white hover:bg-foreground text-foreground/90 hover:text-white text-lg px-5 py-2 rounded-lg font-medium mt-1 transition-colors duration-300 ease-in-out cursor-pointer border-2 border-foreground/80">
                                        Kembali
                                    </button> 
                                    <button onClick={() => rejectPengajuan()} className="bg-foreground/90 hover:bg-foreground text-white text-lg px-5 py-2 rounded-lg font-medium mt-1 transition-colors duration-300 ease-in-out cursor-pointer">
                                        Submit penolakan
                                    </button>
                                </div>
                            </div>
                        </motion.div>
                    )
                }
            </AnimatePresence>
        </motion.div>
    )
}