"use client"

import Image from "next/image"
import { useEffect, useState } from "react"
import { AnimatePresence } from "framer-motion"

import { useUserStore } from "@/app/stores/useUserStore"
import { getModuleAccess } from "@/app/component/Libraries/utils/menu"

import CustomTable from "@/app/component/Table/CustomTable"
import ContextMenu from "@/app/component/Context/ContextMenu"
import Alert from "@/app/component/Alert/Alert"
import TextTag from "@/app/component/Tags/TextTag"
import Button from "@/app/component/Inputs/Button"

import { useContextMenu } from "@/app/component/Libraries/hooks/useContextMenu"
import { useQueryBuilder } from "@/app/component/Libraries/hooks/useQueryBuilder"
import { formatIndonesianDate } from "@/app/component/Libraries/utils/date"

import {
    getDiseminasi,
    approveDiseminasi,
} from "@/app/component/Libraries/api/diseminasi"

import FormPenugasanReviewer from "../Proposal/PenugasanReviewerForm"
import { createDiseminasiAdminMenus } from "@/app/component/Libraries/config/Diseminasi/DiseminasiAdminMenu"

export default function MonitoringDiseminasiAdmin({ skema, onBack }) {

    const qb = useQueryBuilder()
    const { contextMenu, openMenu, closeMenu } = useContextMenu()

    const [refreshKey, setRefreshKey] = useState(0)
    const [tempRowData, setTempRowData] = useState(null)

    const [showAssignModal, setShowAssignModal] = useState(false)
    const [showApproveModal, setShowApproveModal] = useState(false)

    const [showAlert, setShowAlert] = useState(false)
    const [alertMsg, setAlertMsg] = useState('')
    const [alertStatus, setAlertStatus] = useState('success')

    const user = useUserStore(state => state.user)
    const access = getModuleAccess("admindiseminasi", user?.role) ||
        getModuleAccess("adminmonitoringpengajuan", user?.role)

    useEffect(() => {
        if (skema?.skema_id) {
            qb.addFilter("skema_id", skema.skema_id)
        }
    }, [skema])

    const menus = createDiseminasiAdminMenus({
        user,
        access,
        refreshTable,
        handleAssign,
        handleApprove,
    })

    function handleAssign(r) {
        // FormPenugasanReviewer expects an object shaped like a proposal;
        // here we adapt it so the same form works for laporan/diseminasi.
        setTempRowData({
            ...r,
            reviewable_type: 'App\\Models\\Laporan',
            reviewable_id: r.laporan_id,
            existing_reviewers: r.penugasan.map(p => p.reviewer).filter(Boolean),
        })

        setShowAssignModal(true)
    }

    function handleApprove(r) {
        setTempRowData(r)
        setShowApproveModal(true)
    }

    async function confirmApprove() {
        try {
            const formData = new FormData()
            formData.append("laporan_id", tempRowData.laporan_id)

            const res = await approveDiseminasi(formData)

            if (res.data.status === "success") {
                setAlertMsg("Diseminasi berhasil di-approve.")
                setAlertStatus("success")
            } else {
                setAlertMsg(res.data.message || "Gagal approve diseminasi.")
                setAlertStatus("error")
            }
        }
        catch (err) {
            console.error(err)
            setAlertMsg("Gagal approve diseminasi.")
            setAlertStatus("error")
        }
        finally {
            setShowApproveModal(false)
            setShowAlert(true)
            refreshTable()
        }
    }

    function refreshTable() {
        setRefreshKey(prev => prev + 1)
    }

    return (
        <div
            className="flex flex-col gap-5 min-h-screen"
            onContextMenu={(e) => openMenu(e)}
        >
            <div className="flex flex-col justify-between items-start gap-5">

                <div className="flex items-center gap-2 text-sm text-gray-500">
                    <button onClick={onBack} className="hover:text-black">
                        Monitoring Progress
                    </button>
                    <span>›</span>
                    <span>{skema?.nama_skema}</span>
                    <span>›</span>
                    <span className="font-medium text-black">
                        Diseminasi
                    </span>
                </div>

                <div className="flex flex-col gap-2">
                    <h1 className="text-4xl font-medium">Diseminasi</h1>
                    <p className="text-lg text-gray-500 font-light">
                        Review publikasi hasil penelitian pada tahap diseminasi.
                    </p>
                </div>

                <CustomTable
                    fetchMethod={getDiseminasi}
                    searchQuery={qb.toQueryString()}
                    refreshKey={refreshKey}
                    className="w-full"
                    roundedStyle="rounded-lg"
                    onContextRequest={(e, type, data, source) =>
                        openMenu(e, type, data, source)
                    }
                    columns={[
                        {
                            header: "Judul Penelitian",
                            key: "judul_penelitian",
                            width: "25%",
                            render: (value, row) => (
                                <div className="flex items-center gap-2">
                                    <TextTag
                                        color={row.semester === "Ganjil" ? "#C4161C" : "#0197CA"}
                                        size="text-xs"
                                    >
                                        {row.semester}
                                    </TextTag>

                                    <p className="text-sm line-clamp-2">{value}</p>
                                </div>
                            )
                        },
                        {
                            header: "Ketua",
                            key: "ketua",
                            render: (value, row) => (
                                <div className="flex items-center gap-2 text-xs">
                                    {row.ketua?.avatar &&
                                        <Image
                                            src={row.ketua.avatar}
                                            alt={row.ketua.nama}
                                            width={25}
                                            height={25}
                                            className="rounded-full"
                                            unoptimized
                                        />
                                    }
                                    <span>{row.ketua?.nama}</span>
                                </div>
                            )
                        },
                        {
                            header: "Target Publikasi",
                            key: "target_publikasi",
                        },
                        {
                            header: "Tgl Submit",
                            key: "tgl_submit",
                            render: (value) => value
                                ? formatIndonesianDate(value)
                                : "-"
                        },
                        {
                            header: "Reviewer",
                            key: "penugasan",
                            width: "20%",
                            render: (value) => {
                                if (!value?.length) {
                                    return (
                                        <span className="text-sm italic text-gray-500">
                                            Belum ditugaskan
                                        </span>
                                    )
                                }

                                return (
                                    <div className="grid grid-cols-1 gap-1">
                                        {value.map((p, i) => (
                                            <div
                                                key={i}
                                                className="flex items-center gap-2 text-xs"
                                            >
                                                <span className={
                                                    p.status_review === "Telah direview"
                                                        ? "text-green-600"
                                                        : "text-yellow-600"
                                                }>
                                                    ●
                                                </span>
                                                <span className="truncate">
                                                    {p.reviewer?.nama || "-"}
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                )
                            }
                        },
                        {
                            header: "Luaran",
                            key: "luaran",
                            render: (value) => (
                                <div className="flex flex-col gap-1 text-xs">
                                    {value.link_laporan_akhir &&
                                        <a
                                            href={value.link_laporan_akhir}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-blue-600 hover:underline"
                                        >
                                            Laporan Akhir
                                        </a>
                                    }
                                    {value.link_publikasi &&
                                        <a
                                            href={value.link_publikasi}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-blue-600 hover:underline"
                                        >
                                            Publikasi
                                        </a>
                                    }
                                </div>
                            )
                        },
                    ]}
                />

            </div>

            <AnimatePresence>
                {showAssignModal && (
                    <FormPenugasanReviewer
                        data={tempRowData}
                        close={() => setShowAssignModal(false)}
                        refresh={refreshTable}
                        alertMsg={setAlertMsg}
                        alertStatus={setAlertStatus}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {showApproveModal && (
                    <Alert
                        alertType="warning"
                        title="Approve Diseminasi"
                        msg="Apakah anda yakin ingin approve diseminasi ini? Laporan akan dilanjutkan ke tahap berikutnya."
                        onCancel={() => setShowApproveModal(false)}
                        onAccept={confirmApprove}
                        acceptText="Approve"
                        isConfirmation={true}
                        withBackground={true}
                    />
                )}
            </AnimatePresence>

            {showAlert &&
                <Alert
                    msg={alertMsg}
                    onCancel={() => setShowAlert(false)}
                    alertType={alertStatus}
                />
            }

            <ContextMenu
                contextMenu={contextMenu}
                closeMenu={closeMenu}
                menus={menus}
            />
        </div>
    )
}
