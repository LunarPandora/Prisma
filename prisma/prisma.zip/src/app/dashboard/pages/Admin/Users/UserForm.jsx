"use client"

import Image from "next/image"
import { useState, useEffect, useRef } from "react"
import { AnimatePresence, motion } from "framer-motion"

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faX, faUser, faEnvelope, faLock, faMarsAndVenus, faUserGear, faUserCheck, faSpinner, faGraduationCap, faIdCard, faEdit } from '@fortawesome/free-solid-svg-icons'

import TextInput from "@/app/component/Inputs/TextInput"
import SelectInput from "@/app/component/Inputs/SelectInput"
import LoadingBar from "@/app/component/AppLoader/LoadingBar"

import { fetchProdi } from "@/app/component/Libraries/api/prodi"
import { addUsers, updateUsers } from "@/app/component/Libraries/api/users"
import { accStatusOptions, genderOptions, roleOptions } from "@/app/component/Libraries/options/selections"

export default function FormUser({ refresh, close, data, isEdit, alertMsg, alertStatus, alertTrigger }){
    const defaultForm = {
        nama: "",
        email: "",
        password: "",
        gender: "-",
        status: "-",
        role: "-",
        dosen_id: "",
        prodi_id: "",
        nidn: "",
        avatar: "",
        uploaded_file: null
    }

    const [form, setForm] = useState(defaultForm)
    const [prodiOptions, setProdiOptions] = useState([])
    const [loadingForm, setLoadingForm] = useState(true)
    const [preview, setPreview] = useState(null);

    const MotionLoadingBar = motion.create(LoadingBar);
    const fileInputRef = useRef(null);
    const imageSrc =
        preview || 
        form.avatar || 
        "/img/user_placeholder.webp";

    useEffect(() => {
        fetchProdi().then(data => {
            let temp_data = []
            data.map((val) => {
                temp_data.push({
                    text: val.nama_prodi,
                    value: val.prodi_id
                })
            })

            setProdiOptions(temp_data)
            setLoadingForm(false)
        })
    }, [])

    useEffect(() => {
        if (isEdit && data) {
            setForm(prev => ({
                ...prev,
                ...data,
                password: "12345678",
            }))
        } else {
            setForm(defaultForm)
        }
    }, [isEdit, data])

    const handleChange = (e) => {
        const { name, value } = e.target
        setForm(prev => ({
            ...prev,
            [name]: value,
        }))
    }

    const handleFileInput = (e) => {
        const file = e.target.files[0]
        if (!file) return

        if (e.target.files.length > 1) {
            alert("Only one file allowed!");
            return;
        }

        if (!file.type.startsWith("image/")) {
            alert("Only image files are allowed");
            return;
        }

        if (file.size > 5 * 1024 * 1024) {
            alert("File too large (max 5MB)");
            return;
        }

        setForm((prev) => ({
            ...prev,
            uploaded_file: file,
        }))

        const previewUrl = URL.createObjectURL(file);
        setPreview(previewUrl);
    }

    async function sendData(){
        try{
            setLoadingForm(true)
            
            const formData = new FormData()
            Object.entries(form).forEach(([key, value]) => {
                if (key === "uploaded_file") return // skip here

                if (value !== null && value !== undefined && value !== "" && value !== "-") {
                    formData.append(key, value)
                }
            })

            if (form.uploaded_file instanceof File) {
                formData.append("uploaded_file", form.uploaded_file)
            }

            const res = isEdit
                ? await updateUsers(formData)
                : await addUsers(formData)

            if (res.data.status == 'success'){ 
                alertMsg(`Sistem berhasil ${isEdit ? 'mengupdate' : 'menambahkan'} user!`)
                alertStatus('success')
            }
            else {
                alertMsg(`Sistem gagal ${isEdit ? 'mengupdate' : 'menambahkan'} user!`)
                alertStatus('danger')
            }
        }
        catch(err){
            alertMsg(`Sistem gagal ${isEdit ? 'mengupdate' : 'menambahkan'} data user dikarenakan error di sistem!`)
            alertStatus('danger')

            console.error(err)
        }
        finally{
            setTimeout(() => {
                setLoadingForm(false)
                refresh()
                close()
                alertTrigger()
            }, 300)
        }
    }

    useEffect(() => {
        return () => {
            if (preview) URL.revokeObjectURL(preview);
        };
    }, [preview]);

    return (
        <motion.div
            key="formModal"
            initial={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0)" }}
            exit={{ opacity: 0, scale: 1.05, filter: "blur(3px)" }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 will-change-auto"
        >
            <AnimatePresence mode="wait">
                { loadingForm ? 
                    (
                        <MotionLoadingBar />
                    )
                    :
                    (
                        <motion.div
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            transition={{ duration: 0.2 }}
                            className="w-1/2 bg-white p-5 rounded-xl flex flex-col gap-5"
                        >
                            <div class="flex w-full justify-between items-center">
                                <p className="font-medium text-xl">{ isEdit ? 'Update Pengguna' : 'Tambah Pengguna Baru' }</p>
                                <FontAwesomeIcon onClick={close} icon={faX} className="text-sm" />
                            </div>
                            <motion.div
                                key="form_section"
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                transition={{ duration: 0.2 }}
                                className="flex flex-col gap-3"
                            >
                                <div className="flex gap-3">
                                    <div className="w-1/5 flex flex-col items-center justify-center gap-2">
                                        <input
                                            type="file"
                                            accept="image/*"
                                            ref={fileInputRef}
                                            onChange={handleFileInput}
                                            style={{ display: "none" }}
                                        />

                                        <div className="relative rounded-full overflow-hidden">
                                            <Image
                                                src={imageSrc}
                                                alt="avatar"
                                                width={150}
                                                height={150}
                                                className="relative aspect-square object-cover object-center"
                                                unoptimized
                                            />
                                            <div
                                                className="w-full h-full z-10 absolute inset-0 opacity-0 hover:opacity-100 bg-black/60 flex items-center justify-center hover:cursor-pointer transition-opacity duration-200 ease-in-out" 
                                                onClick={() => fileInputRef.current.click()}
                                            >
                                                <FontAwesomeIcon icon={faEdit} className="text-white text-2xl" />
                                            </div>
                                        </div>

                                        <span 
                                            className="text-xs underline decoration-dotted underline-offset-3 hover:cursor-pointer hover:text-primary text-center"
                                            onClick={() => fileInputRef.current.click()}
                                        >
                                            Ubah foto profil<br />
                                            Maks. 5MB
                                        </span>
                                    </div>

                                    <div className="w-4/5 grid grid-cols-2 gap-2">
                                        <TextInput
                                            name="nama" 
                                            type="text"
                                            placeholder="Masukkan nama pengguna"
                                            icon={faUser}
                                            value={form.nama}
                                            onChange={handleChange}
                                        />

                                        <TextInput 
                                            name="email" 
                                            type="email" 
                                            placeholder="Masukkan email pengguna" 
                                            icon={faEnvelope}
                                            value={form.email}
                                            onChange={handleChange}
                                        />
 
                                        <TextInput
                                            name="password" 
                                            type="password" 
                                            placeholder="Masukkan password pengguna"
                                            icon={faLock}
                                            value={form.password}
                                            disabled={isEdit ? true : false}
                                            onChange={handleChange}
                                        />

                                        <SelectInput
                                            name="gender"
                                            value={form.gender}
                                            onChange={handleChange}
                                            options={genderOptions}
                                            icon={faMarsAndVenus}
                                            placeholder="Pilih gender pengguna"
                                        />

                                        <SelectInput
                                            name="role"
                                            value={form.role}
                                            onChange={handleChange}
                                            options={roleOptions}
                                            icon={faUserGear}
                                            placeholder="Pilih role pengguna"
                                        />

                                        <SelectInput
                                            name="status" 
                                            value={form.status}
                                            onChange={handleChange}
                                            options={accStatusOptions}
                                            icon={faUserCheck}
                                            placeholder="Pilih status pengguna"
                                        />
                                        
                                        <TextInput 
                                            name="nidn" 
                                            type="text" 
                                            placeholder="Masukkan NIDN" 
                                            icon={faIdCard}
                                            value={form.nidn}
                                            onChange={handleChange}
                                        />

                                        <AnimatePresence> 
                                            <>
                                                { (form.role == 'Dosen') &&
                                                    <motion.div
                                                        key="dosenProdi"
                                                        initial={{ opacity: 0 }}
                                                        animate={{ opacity: 1 }}
                                                        exit={{ opacity: 0 }}
                                                        transition={{ duration: 0.2 }}
                                                    >
                                                        <SelectInput
                                                            name="prodi_id" 
                                                            value={form.prodi_id}
                                                            onChange={handleChange}
                                                            options={prodiOptions}
                                                            icon={faGraduationCap}
                                                            placeholder="Pilih prodi"
                                                        />
                                                    </motion.div>
                                                }
                                            </>
                                        </AnimatePresence>
                                    </div>
                                </div>
                                
                                <button onClick={sendData} className="bg-foreground/90 hover:bg-foreground text-white text-lg px-5 py-2 rounded-lg font-medium mt-1 transition-colors duration-300 ease-in-out cursor-pointer col-span-2">
                                    { 
                                        isEdit ? 'Update' : 'Tambahkan'
                                    }
                                </button>
                            </motion.div>
                        </motion.div>
                    )
                }
            </AnimatePresence>
        </motion.div>
    )
}