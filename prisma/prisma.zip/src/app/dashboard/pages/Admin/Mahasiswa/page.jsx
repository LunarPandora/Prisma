"use client"

import Image from "next/image"
import { useState } from "react"
import { AnimatePresence } from "framer-motion"

import Alert from "@/app/component/Alert/Alert"
import CustomTable from "@/app/component/Table/CustomTable"
import LoadingBar from "@/app/component/AppLoader/LoadingBar"
import ContextMenu from "@/app/component/Context/ContextMenu"

import { createMahasiswaAdminMenus } from "@/app/component/Libraries/config/Mahasiswa/MahasiswaAdminMenu"
import { deleteMahasiswa, fetchMahasiswa } from "@/app/component/Libraries/api/mahasiswa"
import { useContextMenu } from "@/app/component/Libraries/hooks/useContextMenu"
import { getModuleAccess } from "@/app/component/Libraries/utils/menu"
import { useUserStore } from "@/app/stores/useUserStore"

import FormMahasiswa from "./MahasiswaForm"
import { formatIndonesianDate } from "@/app/component/Libraries/utils/date"

export default function Mahasiswa(){
    const [refreshKey, setRefreshKey] = useState(0)
    const [addMahasiswaModal, setAddMahasiswaModal] = useState(false)
    const [editMahasiswaModal, setEditMahasiswaModal] = useState(false)
    const [removeMahasiswaModal, setRemoveMahasiswaModal] = useState(false)
    const [tempRowData, setTempRowData] = useState({})

    const [showAlert, setShowAlert] = useState(false)
    const [alertMsg, setAlertMsg] = useState('')
    const [alertStatus, setAlertStatus] = useState('success')
    const [loadingForm, setLoadingForm] = useState(false)

    const user = useUserStore(state => state.user)
    const access = getModuleAccess("users", user?.role)

    const { contextMenu, openMenu, closeMenu } = useContextMenu()
    const menus = createMahasiswaAdminMenus({
        user,
        access,
        refreshTable,
        handleAdd,
        handleEdit,
        handleRemove
    })

    function handleAdd(){
        setAddMahasiswaModal(true)
    }

    function handleEdit(r){
        setEditMahasiswaModal(true)
        setTempRowData(r)
    }

    function handleRemove(r){
        setRemoveMahasiswaModal(true)
        setTempRowData(r)
    }

    async function removeMahasiswa(){
        try{
            setLoadingForm(true)
            const res = await deleteMahasiswa(tempRowData.mhswa_id)
            setLoadingForm(false)

            if (res.data.status == 'success'){ 
                setAlertMsg('Sistem berhasil menghapus data mahasiswa!')
                setAlertStatus('success')
            }
            else {
                setAlertMsg('Sistem gagal menghapus data mahasiswa!')
                setAlertStatus('danger')
            }
        }
        catch(err){
            setAlertMsg('Sistem gagal menghapus data mahasiswa!')
            setAlertStatus('danger')

            console.error(err)
        }
        finally{
            refreshTable()
            setRemoveMahasiswaModal(false)
            setShowAlert(true)
        }
    }

    function refreshTable() {
        setRefreshKey(prev => prev + 1)
    }

    return (
        <div 
            className="flex flex-col gap-5 min-h-screen"
            onContextMenu={(e) => openMenu(e)}
        >
            <div className="flex justify-between items-start">
                <div className="flex flex-col gap-2">
                    <h1 className="text-4xl font-medium">Daftar Mahasiswa</h1>
                    <p className="text-lg text-gray-500 font-light">Berikut daftar mahasiswa yang terdaftar dalam sistem.</p>
                </div>
            </div>

            <CustomTable
                fetchMethod={fetchMahasiswa}
                refreshKey={refreshKey}
                onContextRequest={(e, type, data, source) => openMenu(e, type, data, source)}
                columns={[
                    {
                        header: "Nama", 
                        key: "nama",
                        render: (value, row) => {
                            return (
                                <span className="flex items-center gap-2">
                                    <Image
                                        src={`${row.avatar}`}
                                        width={25}
                                        height={25}
                                        className="relative rounded-full"
                                        unoptimized
                                    />
                                    {value}
                                </span>
                            )
                        }
                    },
                    { header: "NIM", key: "nim" },
                    { header: "Prodi", key: "nama_prodi" },
                    { header: "Tgl Ditambahkan", key: "created_at", render: (value) => { return formatIndonesianDate(value) } },
                ]}
            />

            <AnimatePresence>
                {addMahasiswaModal && (
                    <FormMahasiswa
                        refresh={() => refreshTable()}
                        close={() => setAddMahasiswaModal(false)}
                        isEdit={false}
                        alertMsg={(msg) => setAlertMsg(msg)}
                        alertStatus={(stt) => setAlertStatus(stt)}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>

            <AnimatePresence>
                {editMahasiswaModal && (
                    <FormMahasiswa
                        refresh={() => refreshTable()}
                        close={() => setEditMahasiswaModal(false)}
                        isEdit={true}
                        data={tempRowData}
                        alertMsg={(msg) => setAlertMsg(msg)}
                        alertStatus={(stt) => setAlertStatus(stt)}
                        alertTrigger={() => setShowAlert(true)}
                    />
                )}
            </AnimatePresence>            

            <AnimatePresence mode="wait">
                {removeMahasiswaModal && (
                    loadingForm ? 
                    (
                        <LoadingBar />
                    )
                    :
                    (
                        <Alert 
                            alertType="warning"
                            title="Hapus data mahasiswa"
                            msg="Apakah anda yakin ingin menghapus data mahasiswa ini?" 
                            onCancel={() => setRemoveMahasiswaModal(false)} 
                            onAccept={() => removeMahasiswa()} 
                            acceptText="Hapus"
                            isConfirmation={true}
                        />
                    )
                )}
            </AnimatePresence>

            { showAlert && 
                <Alert 
                    msg={alertMsg} 
                    onCancel={() => setShowAlert(false)} 
                    alertType={alertStatus}
                /> 
            }

            <ContextMenu
                contextMenu={contextMenu}
                closeMenu={closeMenu}
                menus={menus}
            />
        </div>
    )
}