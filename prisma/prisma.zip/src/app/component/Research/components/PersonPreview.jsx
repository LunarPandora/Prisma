"use client"

export default function PersonPreview({
    person,
    onConfirm,
    onCancel
}) {

    if(!person) return null

    return (
        <div className="flex flex-col gap-4">

            <div className="flex items-center gap-4">

                <img
                    src={
                        person.avatar ||
                        "/default-avatar.png"
                    }
                    alt={person.nama}
                    className="
                        w-16 h-16
                        rounded-full
                        object-cover
                        border
                    "
                />

                <div>

                    <p className="font-semibold">
                        {person.nama}
                    </p>

                    <p className="text-sm text-gray-500">
                        {person.type}
                    </p>

                </div>

            </div>

            <div className="flex justify-end gap-2">

                <button
                    type="button"
                    onClick={onCancel}
                    className="
                        px-4 py-2
                        border rounded-md
                    "
                >
                    Bukan Orang Ini
                </button>

                <button
                    type="button"
                    onClick={onConfirm}
                    className="
                        px-4 py-2
                        rounded-md
                        bg-foreground
                        text-white
                    "
                >
                    Ya, Tambahkan
                </button>

            </div>

        </div>
    )
}