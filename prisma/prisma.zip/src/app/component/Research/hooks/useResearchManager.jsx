"use client"

export default function useResearcherManager({
    value,
    onChange
}) {

    const addResearcher = (item, type) => {

        let researcherId

        if(type === "Dosen"){
            researcherId = item.user_id
        }
        else if(type === "Mahasiswa"){
            researcherId = item.mhswa_id
        }
        else if(type === "Kolaborator"){
            researcherId = item.kolab_id
        }

        const exists = value.some(
            member =>
                member.id === researcherId
        )

        if(exists){
            return false
        }

        onChange([
            ...value,
            {
                id: researcherId,
                type,

                nama: item.nama,
                avatar: item.avatar,

                institusi: item.institusi ?? null,
                prodi: item.prodi ?? null,

                ttjp: "",
                locked: false
            }
        ])

        return true
    }

    const removeResearcher = (id) => {

        const target =
            value.find(item => item.id === id)

        if(target?.locked){
            return
        }

        onChange(
            value.filter(item => item.id !== id)
        )
    }

    const moveUp = (index) => {

        if(index <= 1) return

        const arr = [...value]

        ;[
            arr[index - 1],
            arr[index]
        ] = [
            arr[index],
            arr[index - 1]
        ]

        onChange(arr)
    }

    const moveDown = (index) => {

        if(index === 0) return
        if(index === value.length - 1) return

        const arr = [...value]

        ;[
            arr[index + 1],
            arr[index]
        ] = [
            arr[index],
            arr[index + 1]
        ]

        onChange(arr)
    }

    const updateTTJP = (id, val) => {

        onChange(
            value.map(item =>
                item.id === id
                    ? {
                        ...item,
                        ttjp: val
                    }
                    : item
            )
        )
    }

    return {
        addResearcher,
        removeResearcher,
        moveUp,
        moveDown,
        updateTTJP
    }
}