import ContextMenuRoot from "./ContextMenuRoot"

const normalizeMenu = (menu) => {
    if (!menu || menu.length === 0) return []
    return menu
}

export default function ContextMenuRenderer({
    menu,
    contextData,
    onClose
}) {
    const menus = normalizeMenu(menu)

    const visibleGroups = menus
        .filter(group => {
            if (typeof group.hidden === "function") {
                return !group.hidden(contextData)
            }
            return !group.hidden
        })
        .filter(group => group.items.length > 0)

    return visibleGroups.map((group, gi) => (
        <div key={gi}>
            {group.items.map((item, i) => {
                return (
                    <ContextMenuRoot
                        key={i}
                        icon={item.icon}
                        iconColor={item.iconColor}
                        textColor={item.textColor}
                        enabled={item.enabled}
                        danger={item.danger}
                        contextData={contextData}
                        onClicked={() => {
                            item.action(contextData)
                            onClose?.()
                        }}
                    >
                        {item.text}
                    </ContextMenuRoot>
                ) 
            })}
            {gi !== visibleGroups.length - 1 && (
                <div className="border-t my-1 border-gray-200" />
            )}
        </div>
    ))
}