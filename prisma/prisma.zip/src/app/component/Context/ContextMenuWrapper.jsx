import { AnimatePresence } from "framer-motion"
import ContextWindow from "./ContextWindow"
import ContextMenuRenderer from "./ContextMenuRenderer"

export default function ContextMenuWrapper({
    contextMenu,
    setContextMenu,
    menus
}) {
    if (!contextMenu) return null

    const menu = menus[contextMenu.type] || []

    return (
        <AnimatePresence>
            {contextMenu && (
                <ContextWindow
                    position={{ x: contextMenu.x, y: contextMenu.y }}
                    onClose={() => setContextMenu(null)}
                >
                    <ContextMenuRenderer
                        menu={menu}
                        contextData={contextMenu.data}
                        onClose={() => setContextMenu(null)}
                    />
                </ContextWindow>
            )}
        </AnimatePresence>
    )
}