import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function ContextMenuRoot({
    onClicked,
    icon = null,
    iconColor = "text-gray-600",
    textColor = "text-gray-600",
    enabled = true,
    danger = false,
    contextData = null,
    children
}) {
    // ✅ support function-based enabled
    const isEnabled =
        typeof enabled === "function"
            ? enabled(contextData)
            : enabled;

    // ✅ auto danger styling
    const finalIconColor = !isEnabled
        ? "text-gray-400"
        : danger
        ? "text-red-500"
        : iconColor;

    const finalTextColor = !isEnabled
        ? "text-gray-400"
        : danger
        ? "text-red-500"
        : textColor;

    return (
        <div
            className={`
                w-full flex items-center gap-2 px-2 py-2
                transition-colors duration-200 ease-in-out
                ${isEnabled ? "hover:bg-gray-200 cursor-pointer" : "opacity-50 cursor-not-allowed"}
            `}
            onClick={() => {
                if (!isEnabled) return;
                onClicked?.();
            }}
        >
            {icon && typeof icon !== "string" && (
                <FontAwesomeIcon icon={icon} className={finalIconColor} />
            )}
            <p className={`text-sm ${finalTextColor}`}>
                {children}
            </p>
        </div>
    );
}