import { api } from "../utils/api"

export const updatePeriode = (formData) => {
  return api.post("/periode/update", formData)
}

export const getPeriode = (query = "") => {
  return api.get(`/periode?${query}`)
}

export const fetchPeriode = async () => {
  const res = await api.get('/periode/fetch')
  return res.data
}

export const fetchAllPeriode = async () => {
  const res = await api.get('/periode/fetch/all')
  return res.data
}

export const fetchPenerimaanProposal = async () => {
    const res = await api.get('/periode/fetch-penerimaan-proposal')
    return res.data
}