import { api } from "../utils/api"

export const getDiseminasi = (query = '') => {
  return api.get(`/diseminasi?${query}`)
}

export const approveDiseminasi = (formData) => {
  return api.post("/diseminasi/approve", formData)
}
