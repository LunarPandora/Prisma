import { api } from "../utils/api"

export const getLaporan = (query = '') => {
  return api.get(`/laporan?${query}`)
}

export const updateLaporan = (formData) => {
  return api.post("/laporan/update", formData)
}

export const uploadDokumenLaporan = (formData) => {
  return api.post("/laporan/upload-dokumen", formData)
}

export const finishLaporan = (formData) => {
  return api.post("/laporan/finish", formData)
}

export const generateLaporanAkhir = (formData) => {
  return api.post("/laporan/generate-laporan-akhir", formData)
}

export const submitPublikasi = (formData) => {
  return api.post("/laporan/publikasi", formData)
}
