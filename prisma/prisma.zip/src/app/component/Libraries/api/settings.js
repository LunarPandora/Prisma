import { api } from "../utils/api"

export const fetchSettings = async () => {
  const res = await api.get('/settings')
  return res.data.data
}

export const updateSettings = (formData) => {
  return api.post("/settings/update", formData)
}

export const fetchLPPM = async () => {
  const res = await api.get('/settings/fetch-lppm')
  return res.data.data
}

export const fetchRektorat = async () => {
  const res = await api.get('/settings/fetch-rektorat')
  return res.data.data
}