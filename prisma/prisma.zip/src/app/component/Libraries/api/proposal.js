import { api } from "../utils/api"

export const addHalamanPengesahan = (formData) => {
  return api.post("/proposal/draft/add", formData)
}

export const updateHalamanPengesahan = (formData) => {
  return api.post("/proposal/draft/update", formData)
}

export const getGeneratedTemplate = (formData) => {
  return api.post("/proposal/upload/prepare", formData)
}

export const uploadProposal = (formData) => {
  return api.post("/proposal/upload/store", formData)
}

export const updateProposal = (formData) => {
  return api.post("/proposal/update", formData)
}

export const deleteProposal = (formData) => {
  return api.post("/proposal/delete", formData)
}

export const getProposal = (query = '') => {
  return api.get(`/proposal?${query}`)
}

export const fetchPengumumanSk = (query = '') => {
  return api.get(`/proposal/sk/fetch?${query}`)
}

export const generatePengumumanSk = (formData) => {
  return api.post("/proposal/sk/generate", formData)
}

export const uploadPengumumanSk = (formData) => {
  return api.post("/proposal/sk/upload", formData)
}
