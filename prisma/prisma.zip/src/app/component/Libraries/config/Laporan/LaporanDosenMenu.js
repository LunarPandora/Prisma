import { faRefresh, faEdit, faTrashCan, faPlus, faUpload, faFlagCheckered, faBullhorn, faMoneyBillWave, faBookOpen } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createLaporanDosenMenus = ({
    user,
    access,
    refreshTable,
    handleViewLogbook,
    handleUploadDokumen,
    handleFinish,
    handlePublikasi,
    handleUploadClaimProof,
    handleUploadPengembalianProof,
    handleSitasi,
    // handleRemove
}) => ({
    main: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
            ]
        )
    ],

    row: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh })
            ]
        ),
        group(
            [
                item("Cek Logbook", handleViewLogbook, {
                    icon: faEdit,
                    enabled: (r) =>
                        access.update &&
                        ["PROSES_PENELITIAN_GANJIL", "PROSES_PENELITIAN_GENAP",
                         "PROSES_PKM_GANJIL", "PROSES_PKM_GENAP"].includes(r.kode_periode)
                }),
                item("Upload Revisi Laporan", handleUploadDokumen, {
                    icon: faUpload,
                    enabled: (r) =>
                        access.update &&
                        ["PROSES_PENELITIAN_GANJIL", "PROSES_PENELITIAN_GENAP",
                         "PROSES_PKM_GANJIL", "PROSES_PKM_GENAP"].includes(r.kode_periode)
                }),
                item("Selesaikan Laporan", handleFinish, {
                    icon: faFlagCheckered,
                    enabled: (r) =>
                        access.update &&
                        ["PROSES_PENELITIAN_GANJIL", "PROSES_PENELITIAN_GENAP",
                         "PROSES_PKM_GANJIL", "PROSES_PKM_GENAP"].includes(r.kode_periode)
                }),
                item("Publikasi", handlePublikasi, {
                    icon: faBullhorn,
                    enabled: (r) =>
                        access.update &&
                        ["PUBLIKASI_GANJIL", "PUBLIKASI_GENAP"].includes(r.kode_periode)
                }),
                item("Upload Bukti Claim Dana", handleUploadClaimProof, {
                    icon: faMoneyBillWave,
                    enabled: (r) =>
                        access.update &&
                        ["CLAIM_DANA_GANJIL", "CLAIM_DANA_GENAP"].includes(r.kode_periode) &&
                        r.detail?.claim_dana_status === "Menunggu bukti transfer"
                }),
                item("Upload Bukti Pengembalian Dana", handleUploadPengembalianProof, {
                    icon: faMoneyBillWave,
                    enabled: (r) =>
                        access.update &&
                        ["PENGEMBALIAN_DANA_GANJIL", "PENGEMBALIAN_DANA_GENAP"].includes(r.kode_periode) &&
                        r.detail?.pengembalian_dana_status === "Menunggu Pengembalian Dana"
                }),
                item("Kelola Sitasi", handleSitasi, {
                    icon: faBookOpen,
                    enabled: (r) =>
                        access.update &&
                        ["LUARAN_PENELITIAN", "LUARAN_PKM"].includes(r.kode_periode)
                }),
            ]
        )
    ]
})