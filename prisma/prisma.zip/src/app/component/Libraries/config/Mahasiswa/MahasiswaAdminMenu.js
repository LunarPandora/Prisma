import { faRefresh, faEdit, faTrashCan, faPlus } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createMahasiswaAdminMenus = ({
    user,
    access,
    refreshTable,
    handleAdd,
    handleEdit,
    handleRemove
}) => ({
    main: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
                item("Tambahkan mahasiswa baru", handleAdd, { 
                    icon: faPlus,
                    enabled: access.create 
                })
            ]
        )
    ],

    row: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh })
            ]
        ),
        group(
            [
                item("Edit mahasiswa", handleEdit, {
                    icon: faEdit,
                    enabled: access.update
                }),
                item("Hapus mahasiswa", handleRemove, {
                    icon: faTrashCan,
                    enabled: access.delete,
                    danger: true
                })
            ]
        )
    ]
})