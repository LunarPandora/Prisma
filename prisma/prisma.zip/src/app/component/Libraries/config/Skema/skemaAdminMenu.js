import { faRefresh, faEdit, faTrashCan, faPlus } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createSkemaAdminMenus = ({
    access,
    refreshTable,
    handleAdd,
    handleEdit,
    handleDelete
}) => (
    {
    main: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
                item("Buat skema pengajuan baru", () => handleAdd(true), { 
                    icon: faPlus,
                    enabled: access.create 
                })
            ]
        )
    ],

    row: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh })
            ]
        ),
        group(
            [
                item("Edit skema pengajuan", handleEdit, {
                    icon: faEdit,
                    enabled: access.update
                }),
                item("Hapus skema pengajuan", handleDelete, {
                    icon: faTrashCan,
                    enabled: access.delete,
                    danger: true
                })
            ]
        )
    ]
})