import { faRefresh, faUserPlus, faCheck } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createDiseminasiAdminMenus = ({
    user,
    access,
    refreshTable,
    handleAssign,
    handleApprove,
}) => ({
    main: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
            ]
        )
    ],

    row: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh })
            ]
        ),
        group(
            [
                item("Tugaskan Reviewer", handleAssign, {
                    icon: faUserPlus,
                    enabled: access?.update
                }),
                item("Approve Diseminasi", handleApprove, {
                    icon: faCheck,
                    enabled: (r) =>
                        access?.update &&
                        r.penugasan?.length > 0 &&
                        r.penugasan.every(p => p.status_review === "Telah direview")
                }),
            ]
        )
    ]
})
