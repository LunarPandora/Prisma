import { faRefresh, faEdit, faTrashCan, faPlus, faEye, faFileUpload } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createProposalDosenMenus = ({
    user,
    access,
    refreshTable,
    handleView,
    handleAddG,
    handleEditG,
    handleRemoveG,
    handleUpload
}) => (
    {
    main: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
                item("Ajukan proposal", handleAddG, { 
                    icon: faPlus,
                })
            ]
        )
    ],

    row: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh })
            ]
        ),
        group(
            [
                item("Edit proposal", handleEditG, {
                    icon: faEdit,
                    enabled: (r) => r.status === "Draft"
                }),
                item("Hapus proposal", handleRemoveG, {
                    icon: faTrashCan,
                    enabled: (r) => r.status === "Draft",
                    danger: true
                })
            ],
            {
                hidden: (r) => r.status !== "Draft"
            }
        ),
        group(
            [
                item("Upload proposal", handleUpload, {
                    icon: faFileUpload,
                    enabled: (r) => r.status === "Menunggu proposal untuk diupload"
                }),
                item("Hapus proposal", handleRemoveG, {
                    icon: faTrashCan,
                    enabled: (r) => r.status === "Menunggu proposal untuk diupload",
                    danger: true
                })
            ],
            {
                hidden: (r) => r.status !== "Menunggu proposal untuk diupload"
            }
        ),
        group(
            [
                item("Cek proposal", handleView, {
                    icon: faEye,
                    enabled: (r) => r.status === "Menunggu penugasan reviewer"
                }),
            ],
            {
                hidden: (r) => r.status !== "Menunggu penugasan reviewer"
            }
        )        
    ]
})