import { faRefresh, faEdit, faTrashCan, faUserPlus, faEye, faFile } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createProposalAdminMenus = ({
    user,
    access,
    refreshTable,
    handleShow,
    handlePenugasan,
    handleTolak,
    handleCheckReview
}) => (
    {
    main: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
            ],
        )
    ],

    row: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh })
            ]
        ),
        group(
            [
                // item("Tugaskan reviewer", handlePenugasan, {
                //     icon: faUserPlus,
                //     enabled: (r) => access.update && r.status === "Menunggu penugasan reviewer"
                // }),
                item("Cek pengajuan", handleShow, {
                    icon: faEye,
                    enabled: (r) => access.read && r.status === "Menunggu penugasan reviewer"
                }),
                item("Tolak pengajuan", handleTolak, {
                    icon: faTrashCan,
                    enabled: (r) => access.delete && r.status === "Menunggu penugasan reviewer",
                    danger: true
                })
            ],
            {
                hidden: (r) => r.status !== "Menunggu penugasan reviewer"
            }
        ),
        group(
            [
                item("Cek progress review", handleCheckReview, {
                    icon: faFile,
                    enabled: (r) => access.update && r.status === "Menunggu review"
                }),
            ],
            {
                hidden: (r) => r.status !== "Menunggu review"
            }
        ),
    ]
})