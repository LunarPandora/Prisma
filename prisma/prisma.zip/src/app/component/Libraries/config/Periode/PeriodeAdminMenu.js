import { faRefresh, faEdit, faTrashCan, faPlus } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createPeriodeAdminMenus = ({
    access,
    refreshTable,
    handleEdit,
}) => (
    {
    main: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
            ]
        )
    ],

    row: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh })
            ]
        ),
        group(
            [
                item("Edit periode pengajuan", handleEdit, {
                    icon: faEdit,
                    enabled: access.update
                }),
            ]
        )
    ]
})