import { faRefresh, faEdit, faTrashCan, faUserPlus, faEye, faClipboardList } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createReviewReviewerMenus = ({
    user,
    access,
    refreshTable,
    handleShow,
    handlePenugasan,
    handleTolak
}) => (
    {
    main: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
            ],
        )
    ],

    row: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh })
            ]
        ),
        group(
            [
                item("Mulai penilaian", handleShow, {
                    icon: faClipboardList,
                    enabled: (r) => access.create && r.status === "Belum direview"
                }),
                // item("Cek pengajuan", handleShow, {
                //     icon: faEye,
                //     enabled: (r) => access.read && r.status === "Menunggu penugasan reviewer"
                // }),
                // item("Tolak pengajuan", handleTolak, {
                //     icon: faTrashCan,
                //     enabled: (r) => access.delete && r.status === "Menunggu penugasan reviewer",
                //     danger: true
                // })
            ],
            {
                hidden: (r) => r.status !== "Belum direview"
            }
        )
    ]
})