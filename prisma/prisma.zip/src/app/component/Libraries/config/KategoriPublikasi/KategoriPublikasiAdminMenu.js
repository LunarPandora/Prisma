import { faRefresh, faEdit, faTrashCan, faPlus } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createKategoriPublikasiAdminMenus = ({
    refreshTable,
    handleAdd,
    handleEdit,
    handleRemove
}) => (
    {
    main: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
            ],
        ),
        group(
            [
                item("Tambahkan kategori publikasi", handleAdd, {
                    icon: faPlus,
                }),
            ]
        )
    ],

    row: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh })
            ]
        ),
        group(
            [
                item("Tambahkan kategori publikasi", handleAdd, {
                    icon: faPlus,
                }),
                item("Edit kategori publikasi", handleEdit, {
                    icon: faEdit,
                }),
                item("Hapus kategori publikasi", handleRemove, {
                    icon: faTrashCan,
                    danger: true
                }),
            ]
        )
    ]
})