import { faRefresh, } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createMonitoringProgressAdminMenus = ({
    user,
    access,
    refreshTable,
}) => ({
    main: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
            ]
        )
    ],

    row: [
        group(
            [
                item("Refresh Tabel", refreshTable, { icon: faRefresh })
            ]
        ),
    ]
})