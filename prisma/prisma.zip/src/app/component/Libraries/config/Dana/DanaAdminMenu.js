import { faRefresh, faCheck, faPaperPlane, faMoneyBillWave } from "@fortawesome/free-solid-svg-icons"
import { group, item } from "@/app/component/Libraries/utils/contextMenuBuilder"

export const createDanaAdminMenus = ({
    mode,
    access,
    refreshTable,
    handleApproveClaim,
    handleConfirmClaim,
    handleRequestPengembalian,
    handleConfirmPengembalian,
}) => {

    const claimGroup = group(
        [
            item("Approve Claim Dana", handleApproveClaim, {
                icon: faCheck,
                enabled: (r) =>
                    access?.update &&
                    !r.claim_dana_status
            }),
            item("Konfirmasi Bukti Transfer", handleConfirmClaim, {
                icon: faMoneyBillWave,
                enabled: (r) =>
                    access?.update &&
                    r.claim_dana_status === "Menunggu konfirmasi admin"
            }),
        ]
    )

    const pengembalianGroup = group(
        [
            item("Minta Pengembalian Dana", handleRequestPengembalian, {
                icon: faPaperPlane,
                enabled: (r) =>
                    access?.update &&
                    !r.pengembalian_dana_status
            }),
            item("Konfirmasi Pengembalian", handleConfirmPengembalian, {
                icon: faMoneyBillWave,
                enabled: (r) =>
                    access?.update &&
                    r.pengembalian_dana_status === "Menunggu konfirmasi admin"
            }),
        ]
    )

    return {
        main: [
            group([
                item("Refresh Tabel", refreshTable, { icon: faRefresh }),
            ])
        ],
        row: [
            group([item("Refresh Tabel", refreshTable, { icon: faRefresh })]),
            mode === "pengembalian" ? pengembalianGroup : claimGroup,
        ]
    }
}
