import { faUsersGear, faCalendarAlt, faChartLine, faGraduationCap, faGear, faHandshake, faSchool, faFlask, faFolder } from '@fortawesome/free-solid-svg-icons'

import Users from "@/app/dashboard/pages/Admin/Users/page"
import Periode from "@/app/dashboard/pages/Admin/Skema/Periode/page"
import MonitoringProgress from '../../../dashboard/pages/Dosen/MonitoringPengajuan/Proposal/page'
import Mahasiswa from '@/app/dashboard/pages/Admin/Mahasiswa/page'
import Pengaturan from '@/app/dashboard/pages/Admin/Pengaturan/page'
import Kolaborator from '@/app/dashboard/pages/Admin/Kolaborator/page'
import Prodi from '@/app/dashboard/pages/Admin/Prodi/page'
import ListPengajuanReviewer from '@/app/dashboard/pages/Reviewer/Review/page'
import Skema from '@/app/dashboard/pages/Admin/Skema/page'
import MonitoringPengajuan from '@/app/dashboard/pages/Admin/MonitoringPengajuan/page'
import DosenMonitoringPengajuan from '@/app/dashboard/pages/Dosen/MonitoringPengajuan/page'
import AdminMonitoringPengajuan from '@/app/dashboard/pages/Admin/MonitoringPengajuan/page'
import ProfilDosen from '@/app/dashboard/pages/Dosen/Profil/page'

// === Available Roles ===
// Admin
// Rektorat
// Kepala LPPM
// Dosen
// Reviewer

export const dashboardModules = [
  {
    key: "skema",
    icon: faFlask,
    component: Skema,
    label: "Skema Penelitian",
    roles: [
			{
				name: "Admin",
				access: {
					create: true,
					read: true,
					update: true,
					delete: true
				}
			},
    ]
  },
  {
    key: "users",
    icon: faUsersGear,
    component: Users,
    label: "Daftar Pengguna",
    roles: [
			{
				name: "Admin",
				access: {
					create: true,
					read: true,
					update: true,
					delete: true
				}
			},        
    ]
  },
  {
    key: "mahasiswa",
    icon: faGraduationCap,
    component: Mahasiswa,
    label: "Daftar Mahasiswa",
    roles: [
			{
				name: "Admin",
				access: {
					create: true,
					read: true,
					update: true,
					delete: true
				}
			},        
    ]
  },
  {
    key: "kolaborator",
    icon: faHandshake,
    component: Kolaborator,
    label: "Daftar Kolaborator",
    roles: [
			{
				name: "Admin",
				access: {
					create: true,
					read: true,
					update: true,
					delete: true
				}
			},        
    ]
  },
  {
    key: "prodi",
    icon: faSchool,
    component: Prodi,
    label: "Daftar Prodi",
    roles: [
			{
				name: "Admin",
				access: {
					create: true,
					read: true,
					update: true,
					delete: true
				}
			},        
    ]
  },
  {
    key: "adminmonitoringprogress",
    icon: faChartLine,
    component: AdminMonitoringPengajuan,
    label: "Monitoring Progress",
    roles: [
			{
				name: "Admin",
				access: {
					create: false,
					read: true,
					update: true,
					delete: true
				}
			},
    ]
  },
  {
    key: "pengaturan",
    icon: faGear,
    component: Pengaturan,
    label: "Pengaturan",
    roles: [
			{
				name: "Admin",
				access: {
					create: false,
					read: true,
					update: true,
					delete: true
				}
			},
    ]
  },

// ==========================================================
//   Dosen
// ==========================================================

  {
    key: "dosenmonitoringprogress",
    icon: faChartLine,
    component: DosenMonitoringPengajuan,
    label: "Monitor Progress",
    roles: [
      {
				name: "Dosen",
				access: {
					create: true,
					read: true,
					update: true,
					delete: true
				}
			},
    ]
  },
  {
    key: "profildosen",
    icon: faGraduationCap,
    component: ProfilDosen,
    label: "Profil",
    roles: [
      {
				name: "Dosen",
				access: {
					create: true,
					read: true,
					update: true,
					delete: true
				}
			},
    ]
  },

// ==========================================================
//   Reviewer
// ==========================================================

  {
    key: "reviewproposal",
    icon: faChartLine,
    component: ListPengajuanReviewer,
    label: "Monitor Progress Review",
    roles: [
      {
				name: "Reviewer",
				access: {
					create: true,
					read: true,
					update: true,
					delete: true
				}
			},
    ]
  },
]
  
export function getModuleAccess(moduleKey, role) {
  const module = dashboardModules.find(m => m.key === moduleKey)

  if (!module || !role) {
    return {
      create: false,
      read: false,
      update: false,
      delete: false
    }
  }

  const roleConfig = module.roles.find(r => r.name === role)

  return {
    create: roleConfig?.access?.create ?? false,
    read: roleConfig?.access?.read ?? false,
    update: roleConfig?.access?.update ?? false,
    delete: roleConfig?.access?.delete ?? false
  }
}