import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"

export default function TextInput({ icon, tag, className, isTextArea = false, ...props }){
    return (
        <div className={`w-full relative ${className}`}>
            <span className="text-gray-500 text-xs">
                { tag ? tag : props.placeholder }
            </span>

            <div className={`
                w-full flex flex-col justify-center border-[0.5px] rounded-lg p-3 mt-1 gap-2 transition-all duration-300 ease-in-out

                ${isTextArea ? 'h-fit' : ''}
                
                ${props.disabled
                    ? 'bg-gray-100 border-gray-200 cursor-not-allowed opacity-70'
                    : 'border-gray-300 focus-within:border-black focus-within:outline-4 outline-transparent focus-within:outline-black/20 cursor-pointer'
                }
            `}>
                <div className={`flex w-full gap-2 ${isTextArea ? 'items-stretch' : 'items-center'}`}>
                    { icon &&
                        <FontAwesomeIcon icon={icon} className="text-gray-500 text-md" />
                    }

                    {!isTextArea ? 
                        <input 
                            className="w-full text-sm focus:outline-none disabled:cursor-not-allowed" 
                            {...props}
                        />
                        :
                        <textarea 
                            className="w-full text-sm focus:outline-none h-full max-h-16 disabled:cursor-not-allowed"
                            {...props}
                        ></textarea>
                    }
                </div>
            </div>
        </div>
        
    )
}