"use client"

import { useEffect } from "react"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import {
    faPlus,
    faTrash,
    faGripLines
} from "@fortawesome/free-solid-svg-icons"

export default function MultiKriteriaEditor({
    name,
    value = [],
    onChange,
    onValidationChange,
    tag,
    placeholder,
    className
}) {

    /*
    |--------------------------------------------------------------------------
    | Add Row
    |--------------------------------------------------------------------------
    */

    const addRow = () => {
        const updated = [
            ...value,
            {
                kriteria: "",
                indikator_penilaian: "",
                bobot: ""
            }
        ]

        triggerChange(updated)
    }

    /*
    |--------------------------------------------------------------------------
    | Remove Row
    |--------------------------------------------------------------------------
    */

    const removeRow = (index) => {
        const updated = value.filter((_, i) => i !== index)

        triggerChange(updated)
    }

    /*
    |--------------------------------------------------------------------------
    | Update Field
    |--------------------------------------------------------------------------
    */

    const updateField = (index, field, fieldValue) => {
        const updated = value.map((item, i) =>
            i === index
                ? {
                    ...item,
                    [field]: fieldValue
                }
                : item
        )

        triggerChange(updated)
    }

    /*
    |--------------------------------------------------------------------------
    | Trigger Parent Change
    |--------------------------------------------------------------------------
    */

    const triggerChange = (updated) => {
        onChange({
            target: {
                name,
                value: updated
            }
        })
    }

    /*
    |--------------------------------------------------------------------------
    | Initial Row
    |--------------------------------------------------------------------------
    */

    useEffect(() => {
        if (value.length === 0) {
            triggerChange([
                {
                    kriteria: "",
                    indikator_penilaian: "",
                    bobot: ""
                }
            ])
        }
    }, [])

    const totalBobot = value.reduce(
        (sum, item) => sum + (Number(item.bobot) || 0),
        0
    )

    const isValid = totalBobot === 100

    const hasEmptyFields = value.some((item) => {
        return (
            !item.kriteria?.trim() ||
            !item.indikator_penilaian?.trim() ||
            item.bobot === "" ||
            item.bobot === null ||
            item.bobot === undefined
        )
    })

    useEffect(() => {
        if (onValidationChange) {
            onValidationChange({
                valid: isValid,
                totalBobot,
                hasEmptyFields
            })
        }
    }, [value])

    return (
        <div className={`flex flex-col gap-2 w-full ${className}`}>
            <span className="text-gray-500 text-xs">
                {tag ? tag : placeholder}
            </span>

            <div className="grid grid-cols-2 gap-3">
                {value.map((item, index) => (
                    <div
                        key={index}
                        className="
                            border border-gray-200
                            rounded-xl
                            p-3
                            flex flex-col gap-3
                            bg-white
                        "
                    >
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <FontAwesomeIcon
                                    icon={faGripLines}
                                    className="text-gray-400 text-sm"
                                />

                                <p className="text-sm font-medium">
                                    Kriteria #{index + 1}
                                </p>
                            </div>

                            <button
                                type="button"
                                onClick={() => removeRow(index)}
                                className="
                                    w-8 h-8
                                    rounded-lg
                                    hover:bg-red-50
                                    transition-all
                                "
                            >
                                <FontAwesomeIcon
                                    icon={faTrash}
                                    className="text-red-500 text-sm"
                                />
                            </button>
                        </div>

                        <input
                            type="text"
                            value={item.kriteria}
                            onChange={(e) =>
                                updateField(
                                    index,
                                    "kriteria",
                                    e.target.value
                                )
                            }
                            placeholder="Nama kriteria"
                            className="
                                w-full
                                border border-gray-200
                                rounded-lg
                                px-3 py-2
                                text-sm
                                outline-none
                            "
                        />

                        <textarea
                            value={item.indikator_penilaian}
                            onChange={(e) =>
                                updateField(
                                    index,
                                    "indikator_penilaian",
                                    e.target.value
                                )
                            }
                            placeholder="Indikator penilaian"
                            className="
                                w-full
                                border border-gray-200
                                rounded-lg
                                px-3 py-2
                                text-sm
                                outline-none
                                resize-none
                                min-h-[80px]
                            "
                        />

                        <input
                            type="number"
                            value={item.bobot}
                            onChange={(e) =>
                                updateField(
                                    index,
                                    "bobot",
                                    e.target.value
                                )
                            }
                            placeholder="Bobot"
                            className="
                                w-full
                                border border-gray-200
                                rounded-lg
                                px-3 py-2
                                text-sm
                                outline-none
                            "
                        />
                    </div>
                ))}
            </div>

            <p
                className={`
                    text-sm font-medium
                    ${
                        totalBobot === 100
                            ? "text-green-600"
                            : "text-red-500"
                    }
                `}
            >
                Total Bobot: {
                    value.reduce(
                        (sum, item) => sum + (Number(item.bobot) || 0),
                        0
                    )
                } / 100
            </p>

            {
                totalBobot !== 100 &&
                <p className="text-sm text-red-500">
                    Total bobot harus tepat 100
                </p>
            }

            {
                hasEmptyFields &&
                <p className="text-sm text-red-500">
                    Semua field kriteria wajib diisi
                </p>
            }

            <button
                type="button"
                onClick={addRow}
                className="
                    px-4 py-2
                    rounded-xl
                    bg-gray-100
                    hover:bg-gray-200
                    transition-all
                    text-sm
                    font-medium
                    flex items-center gap-2
                    w-fit
                "
            >
                <FontAwesomeIcon icon={faPlus} />
                Tambah Kriteria Penilaian
            </button>
        </div>
    )
}