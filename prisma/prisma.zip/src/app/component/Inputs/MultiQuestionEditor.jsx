"use client"

import { useEffect } from "react"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import {
    faPlus,
    faTrash,
    faGripLines
} from "@fortawesome/free-solid-svg-icons"

export default function MultiQuestionEditor({
    name,
    value = [],
    onChange,
    tag,
    placeholder,
    className
}) {

    const addQuestion = () => {
        const updated = [
            ...value,
            { question: "" }
        ]

        onChange({
            target: {
                name,
                value: updated
            }
        })
    }

    const removeQuestion = (index) => {
        const updated = value.filter((_, i) => i !== index)

        onChange({
            target: {
                name,
                value: updated
            }
        })
    }

    const updateQuestion = (index, question) => {
        const updated = value.map((item, i) =>
            i === index
                ? {
                    ...item,
                    question
                }
                : item
        )

        onChange({
            target: {
                name,
                value: updated
            }
        })
    }

    useEffect(() => {
        if (value.length === 0) {
            onChange({
                target: {
                    name,
                    value: [{ question: "" }]
                }
            })
        }
    }, [])

    return (
        <div className={`flex flex-col gap-2 w-full ${className}`}>
            <span className="text-gray-500 text-xs">
                { tag ? tag : placeholder }
            </span>
            <div className="flex flex-col gap-2">
                {value.map((item, index) => (
                    <div
                        key={index}
                        className="
                            flex items-center gap-2
                            border border-gray-200
                            rounded-xl
                            px-3 py-2
                            bg-white
                        "
                    >
                        <FontAwesomeIcon
                            icon={faGripLines}
                            className="text-gray-400 text-sm"
                        />

                        <input
                            type="text"
                            value={item.question}
                            onChange={(e) =>
                                updateQuestion(
                                    index,
                                    e.target.value
                                )
                            }
                            placeholder={`Pertanyaan ${index + 1}`}
                            className="
                                flex-1
                                outline-none
                                bg-transparent
                                text-sm
                            "
                        />

                        <button
                            type="button"
                            onClick={() => removeQuestion(index)}
                            className="
                                w-8 h-8
                                rounded-lg
                                hover:bg-red-50
                                transition-all
                            "
                        >
                            <FontAwesomeIcon
                                icon={faTrash}
                                className="text-red-500 text-sm"
                            />
                        </button>
                    </div>
                ))}
            </div>

            <div className="flex gap-2">
                <button
                    type="button"
                    onClick={addQuestion}
                    className="
                        px-4 py-2
                        rounded-xl
                        bg-gray-100
                        hover:bg-gray-200
                        transition-all
                        text-sm
                        font-medium
                        flex items-center gap-2
                    "
                >
                    <FontAwesomeIcon icon={faPlus} />
                    Tambah Kriteria Penilaian
                </button>
            </div>
        </div>
    )
}