"use client"

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { motion } from "framer-motion"
import clsx from "clsx"

export default function Button({
    icon,
    children,
    variant = "primary", // primary | danger | secondary
    disabled = false,
    className,
    fontSize,
    ...props
}) {

    const baseStyle = `
        text-lg px-5 py-2 rounded-lg font-medium
        transition-colors duration-300 ease-in-out
        flex items-center justify-center gap-2
    `

    const variants = {
        primary: `
            bg-foreground/90 hover:bg-foreground text-white
        `,
        danger: `
            bg-red-700 hover:bg-red-900 text-white
        `,
        secondary: `
            bg-white hover:bg-foreground text-foreground/90 hover:text-white
            border-2 border-foreground/80
        `
    }

    const disabledStyle = `
        bg-gray-200 text-gray-400
        cursor-not-allowed
    `

    return (
        <motion.button
            {...props}
            disabled={disabled}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className={clsx(
                baseStyle,
                disabled ? disabledStyle : variants[variant],
                className
            )}
        >
            {icon && (
                <FontAwesomeIcon icon={icon} className="text-sm fa-fw" />
            )}

            {children && (
                <p className={fontSize}>{children}</p>
            )}
        </motion.button>
    )
}